/*
	parser.c
*/

//#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "stypes.h"

#include "parser.h"
//#include "usart.h"

TOKEN_ST token;

void parser_init()
{
	token.head = token.tail = 0;
}

void token_put(char *tok)
{
	token.head = ++token.head % MAX_TOKEN_QUEUE;
	strcpy(token.tok[token.head], tok);
}

char *token_get()
{
	char *ret_val = NULL;
	if(token.head != token.tail)
	{
		token.tail = ++token.tail % MAX_TOKEN_QUEUE;
		ret_val = token.tok[token.tail];
	}

	return ret_val;
}

int parsing(char *text)
{
	int iz;

    char buf[MAX_TOKEN_SIZE];
	int	 buf_idx;
    size_t len;	
	int	 tok_num = 0;
//	char str[50];

	len = strlen(text);

//for(iz=0; iz<len; iz++) USART2_putchar(text[iz]);

	//token ã��
	buf_idx = 0;
	for(iz=0; iz<len; iz++)
	{
	    if( !isspace(text[iz]))
		{
 			buf[buf_idx++] = text[iz];
 		}
		else //��ū�� �߻��ϸ�
		{
			if(buf_idx)
			{
				tok_num++;
				buf[buf_idx] = 0; //���� null �߰�
				token_put(buf);	  //ã�� ��ū ����
				buf_idx = 0;	  //index �ʱ�ȭ
//USART2_puts(buf);
			}
		}
	}
/*
	if(buf_idx)
	{
		tok_num++;
		buf[buf_idx] = 0;
		token_put(buf);	  //������ ��ū ����
	}
*/
	return tok_num;
}
/* end of file */

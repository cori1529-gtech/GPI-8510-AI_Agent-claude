/*
	var.h
*/


#ifndef	__VAR_H___
#define	__VAR_H___

#include "type.h"
#include "stypes.h"

#define	SEND_BAICHUL	1
#define	SEND_SETVALUE	2
#define	SEND_STATUS		3
#define	SMS_RECEIVED	59


extern volatile int  gxiAdcFlag;		// ad conversion end flag
extern volatile long gxlRawAdc;			// raw adc value
extern volatile long gxlSpanAdc;		// gxlRawAdc - v_zero
extern volatile long gxlFactoredAdc;	// gxlRawAdc * gnfFactor
extern volatile long gxlCountAdc;		// internal weight counter
extern volatile long gxlPreAdc;			// previous gxlFactoredAdc  : prev_adc1
extern volatile long gxlRawWeight;		// raw_span weight - not compensation
extern volatile long gxlWeight;			// net weight
extern volatile long gxlGrossWeight;	// gross weight
extern volatile long gxlWeight_2;			// net weight
extern volatile long gxlGrossWeight_2;	// gross weight


extern u8 rotation;

extern  volatile u8  Weight_flag; // 1 // ���� ���� a/d �� ���� ok

extern signed long v_adc1_buf,raw_data,diff1,diff2,diff21,v_i_value;
extern s32	diff3,
	over_weight,
	zero_range,
	tare_range,
	limit,
	prev_adc1;


//<<<<<<<<< main.c
extern s16 Adc_Counter;

extern unsigned char	working_flag;		/* working between start and stop */
extern unsigned char	working_flag_2;		/* working between start and stop */



extern unsigned long  One_Weight;
extern unsigned long  Two_Weight;
extern unsigned long  Three_Weight;
extern unsigned long  Four_Weight;
extern unsigned long  Five_Weight;
extern unsigned long  Six_Weight;

extern	struct jangbi_info jangbi;

//>>>>>>>>>>>>> main.c

//<<<<<< adc.c 


extern u8 One_Weight_Error_Counter;
extern u8 Two_Weight_Error_Counter;
extern u8 Three_Weight_Error_Counter;
extern u8 Four_Weight_Error_Counter;
extern u8 Five_Weight_Error_Counter;
extern u8 Six_Weight_Error_Counter;
			
extern volatile u8 One_Weight_Ok;
extern volatile u8 Two_Weight_Ok;  
extern volatile u8 Three_Weight_Ok;
extern volatile u8 Four_Weight_Ok;
extern volatile u8 Five_Weight_Ok;
extern volatile u8 Six_Weight_Ok;



//<<<<<< adc.c >>>>>>>>>>>>>>>>>>>

//<<<<<<<<<<<<< tcpip_send 
extern u8 mon_One_Weight_Ok;
extern u8 mon_Two_Weight_Ok;
extern u8 mon_Three_Weight_Ok;
extern u8 mon_Four_Weight_Ok;
extern u8 mon_Five_Weight_Ok;
extern u8 mon_Six_Weight_Ok;

extern long	mon_gxlGrossWeight;

extern unsigned long  mon_One_Weight;
extern unsigned long  mon_Two_Weight;
extern unsigned long  mon_Three_Weight;
extern unsigned long  mon_Four_Weight;
extern unsigned long  mon_Five_Weight;
extern unsigned long  mon_Six_Weight;

extern volatile long	mon_raw_adc;

// tcpip_send >>>>>>>>>>>>>>>>>>>>>>>>>>>>

//<<<<<<<<< set.c
extern unsigned long gxhWeightBackup ;      
extern unsigned long gxhFilter;            
extern unsigned long gxhMotionBand;        
extern unsigned long gxhEndDelay;           
extern unsigned long gxhMyAddress ;         
extern unsigned long gxhBaudRate;           
extern unsigned long gxuPulseSetWeigh;      
extern unsigned long gxuOutputErrorWeigh;    
extern unsigned long gxuOutputHighErrorWeigh;   
extern signed long gplCompensationWeight; 
extern signed long gplCompensationWeight2;


extern unsigned long gxwStatusSendInterval;	//�������� ���� �ð�(��)
extern unsigned long  gnlLcCompensation;	// �ε弿 �׾��� �� ���� ON/OFF

extern long temp_weight; 
  
extern signed long gnlDailyTotal;
extern volatile signed long gnlPreDailyTotal[7];
extern unsigned int gnuDay;
extern int			giToday;


extern signed long gnlDailyTotal2;
extern volatile signed long gnlPreDailyTotal2[7];
extern unsigned int gnuDay2;
extern int		  giToday2;
 





extern unsigned char Reg_Tel[20];
extern unsigned char Sms_Time[10];
 
extern unsigned char Sms_Time_First[4];
extern unsigned char Sms_Time_Second[4];
extern unsigned char Sms_Time_Third[4];
extern long gnlDisplay;

extern long	gnlSerialNo; 	//��� �ø��� ��ȣ
extern long	gnlMyAddress;	//��� ID(��巹��)
extern long	gnlHenhouseNo;	//��� ��ȣ
extern long	gnlUseLTE;		//LTE ��뿩�� (0:���׺�, 1:LTE)

//>>>>>>>>>>>>> set.c



//<<<<<<<<<<<<< tcpip_send.c
extern volatile unsigned long gnlTick;

// tcpip_send.c >>>>>>>>>>>>>>>

//<<<<<<<<<<<<< lcd.h
extern unsigned int  POINT_COLOR;
extern unsigned int  BACK_COLOR;
// lcd.h >>>>>>>>>>>>>>>>>>>>>>

extern u32 rtc_year, rtc_month, rtc_date, rtc_hour, rtc_min, rtc_sec;
extern int	gbGetCdmaTime;

extern unsigned long	cdma_interval_timer_ms;

//<<<<<<<<<<<<<< periodic event
extern int gbSecEvent;
extern int gbMinEvent;
extern int gbHourEvent;
extern int gbDayEvent;
// periodic event >>>>>>>>>>>>>

//<<<<<<<<<<<<<< websms
extern int	giWebSMSConnection;
extern int	giWebSMSPreConnection;
extern int gbWebSMSConnection;
// websms >>>>>>>>>>>>>>>>>>>>

//<<<<<<<<<<<<<< usart.c
extern unsigned char	RxBuffer2_sms[];
extern unsigned int		RxCounter2_sms;
extern unsigned char	Usart3_sms_received_flag;	//sms ������ 1
extern char sms_receiving_flag;	//# �� �����ϴ� sms �޴����̸� 
// usart.c >>>>>>>>>>>>>>>>>>>>

#endif	//__VAR_H___

/* end of file */

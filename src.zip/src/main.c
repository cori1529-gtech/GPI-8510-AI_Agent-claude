/*
	main.c

	optimization level 2

�����Է�
span factor	����Ϸ�	
 @#RFAC=12341@
 @#ZIGBEE=000195000000F4EA,$RFAC=12345@
���繫��	���α׷� ����
@#RWEIGHT=12345@
@#ZIGBEE=000195000000F4EA,$RWEIGHT=12345@
����	���α׷� ����
@#RZERO=12345@
@#ZIGBEE=000195000000F4EA,$RZERO=12345@
	
	
���⹫�԰��	"���������¹��� 
  ���⹫�԰�� �ٽ��ѹ�����"	1. �ڵ��� ���ÿ��� ǥ��	06�� 28��
�ε弿�����	�������	1.���α׷� ����	06�� 30��

	ver 2.0 (2017.7.5)
	  1. test, set ��� �� �޴� �ٽ� ǥ��
	  2. set_mode() ���� real weight ���� �״� �� ���� (str[50] -> str[150] ����)
	  3. ����Ű ��� ������ Ȯ�� (0, 5)
	  4. ���� ������Ʈ
	  

	1.9 (2017.6.26)
	  1. check l/c 6ea
  	  2. L/C 6 EA #no
	     #2 #4 #6
		 #1 #3 #5


	1.8 (2017.3.2)
	  1. gbHourEvent �߰�
	  2. LCD_restart() �߰�
	  

	1.7 (2016.7.26)
	 1. adc "-1" ������ ��
		- mon_ ���� �߰�
	 2. ��¥ �Ѿ�� ���� (�ð� �о���°� Ȯ���Ұ�. 212)	
	 3. "-" ���� ǥ���ϱ�


1.6 (2016.7.4)
1.5b1
������ ������  �������Ը� unsigned -> signed�� 
���������� ������  �������Ը� unsigned -> signed�� 
gnlTick �� TIMER2���� RTC�� �ű�
������ �� �Ѵ��� ���� �´��� �� ����(���������� �����ϰ�)
get_weight() �Լ� �߰�
���繫��	���������� ����	  -������ ǥ��


	- �� ������ �ʾ����� �� ��å �����.
	- ��ü�溸 - ���ⷮ�� ���ų�, �۰ų�
	- ���׺�� ���ư��� �͵� �����

	2016.5.2
	 - ����ǥ�� ������ ���������� ����

	2016.4.27
	 - IWDG_SetReload(0xFFFF);	//26214.4 ms

	2016.4.4
	 - 

#define	MONITORING_SERVER_IP	"112.217.212.250"
#define	MONITORING_SERVER_PORT	8391


//#RES_MODEMLONE01034431529@(26 BYTE)// CDMA RESET
//#REG_TELEPHONE01034431529@(26 BYTE)// ���ⷮ ������ ��ȭ��ȣ��� 
//#DEL_TELEPHONE01034431529@(26 BYTE)// ��ϵ� ��ȭ��ȣ ����
//#AUT_SENDINGTIME_SMS_1234@(26 BYTE)// DATA �����ϴ� �ð� ���(�ڵ�����)
//#MAN_SENDINGTI01034431529@(26 BYTE)// SMS �� ���� DATA ���� 
//#REMOTE_PROGRAM_UPLOADING@(26 BYTE)// ���� �߿��� �������� 
//#IP=123.123.123.123:12345@(26 BYTE)	// �߿��� ������Ʈ IP ���� 


Program Size: Code=46164 RO-data=48172 RW-data=1260 ZI-data=22844  
Program Size: Code=37784 RO-data=38552 RW-data=784 ZI-data=29384  

��������	���������� 1�ð��� 1���� �����Ѵ�.
��� �����	��� ����� ������ 1�ð��� 1���� ���������� �Բ� �����Ѵ�.
��������	���� ���۽� ���������� �����Ѵ�.
		������ �߷��� 10�п� 1���� �����Ѵ�.  (WORKING_SEND_INTERVAL)
		���� ����� ���ⷮ�� �������, ����ð��� �����Ѵ�.
ī���Ͱ�	ī���Ϳ� ������ �����͸� 1�а������� �����Ѵ�.
�˶���	�˶��� �����ϴ� ��� �����Ѵ�.
�Ƴ��αװ�	������ �Ƴ��α� �����͸� 1�а������� �����Ѵ�.
��Ű�	������ ��� �����͸� 1�а������� �����Ѵ�.


	2015.4.29
	 1. 16x16, 24x24 ��Ʈ ����Լ� �߰�	(��Ʈ ������ �� 10 kb)
	   1-1. void lcd70_show_string_mode_24x24(unsigned int x,unsigned int y,const unsigned char *p,unsigned int size,unsigned int mode)
	   1-2. void lcd70_show_char_mode_24x24(unsigned int x,unsigned int y,unsigned int num,unsigned int size,unsigned int mode)
	 2. �۲� �����
       2-1. ���η� �ѱ��ھ� BMP�� �ۼ�. �׸��� �̿�. �ܻ� ��Ʈ������ ����.
       2-2. TOTAL IMAGE CONVERTER �� RAW NO HEADER �� ����
       2-3. FED �� �о ������� ����, DOSBOX �̿�.
       2-4. PG4UW�� �о Straigth HEX �������� ����
       2-5. DESYEDIT �� �о 0x00, �������� ��ȯ (��ũ�� �̿�)
       2-6. �迭�� ���� ǥ��
       2-7. ��

		USART  ��� 
		COM1(CN3) : ���Ǻ��� RS-232
		COM2(CN12,CN13) : ���Ǻ��� RS-485
		COM3(CN18) : CDMA
		COM4(CN14) : jigbee

		Predefine ���� 
		100pin
		STM32F103VCT6(512KB, 64KB) :  USE_STDPERIPH_DRIVER, STM32F10X_HD
		STM32F105VCT6(512KB, 64KB) :  USE_STDPERIPH_DRIVER, STM32F10X_CL
		STM32F107VBT6(256KB, 64KB) :  USE_STDPERIPH_DRIVER, STM32F10X_CL
		STM32F107VCT6(256KB, 64KB) :  USE_STDPERIPH_DRIVER, STM32F10X_CL
		STM32F107VBT6(128KB, 32KB) :  USE_STDPERIPH_DRIVER, STM32F10X_CL
		
		144pin
		STM32F103ZET6(512KB, 64KB) :  USE_STDPERIPH_DRIVER, STM32F10X_HD
*/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"	



#include "stm32f10x.h"
#include "stm32f10x_lib.h"
#include "stm32f10x_it.h"
#include "stm32f10x_iwdg.h"
#include "cortexm3_macro.h"
#include "hw_config.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_systick.h"


#include "stm32f10x_lib.h"
#include "stm32f10x_it.h"
#include "stm32f10x_rcc.h"




#include "def.h"
#include "Sflash.h"
#include "adc.h"
#include "buzzer.h"
#include "cal.h"
#include "global.h"
#include "i2c_ee.h"
#include "key.h"
#include "lcd.h"
#include "lcd70.h"
#include "led.h"
#include "main.h"
#include "rs485.h"
#include "rtc.h"
#include "var.h"
#include "sms.h"
#include "spi.h"
#include "tcpip_send.h"
#include "timer.h"
#include "usart.h"
#include "type.h"

#include "debug.h"


#define  MAX_ERROR_COUNTER  7

#define NORMAL_DISPLAY  1
#define STATUS_DISPLAY  2

#define	INPUT_ONE	if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_7) == 0x00)     
#define INPUT_TWO   if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_8) == 0x00)     
#define	INPUT_THREE if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_12) == 0x00)   //��������   

//#define	RS422ON		GPIO_SetBits(GPIOA, GPIO_Pin_4)
//#define	RS422OFF	GPIO_ResetBits(GPIOA, GPIO_Pin_4)


volatile int	giCdmaReturn;	//2015.8.17
char			gszCdmaReturn[100];	//2015.8.17

char str[100];



//<<<<<<<<<<<<<<<<<< local variable




u8 Once_flag=0;
u8 Once_flag_First=0;
u8 Once_flag_Second=0;
u8 Once_flag_Third=0;

u8 Error_Counter=0;

u8	baichul_start_flag = 0;
u8	baichul_end_flag = 0;		    /* determine done */


u8 Error_Counter2=0;

u8	baichul_start_flag2 = 0;
u8	baichul_end_flag2 = 0;		    /* determine done */




u8	  ek_flag1 = 0;	/* second external key flag */

u8	  ek_flag1_HighCount = 0,	/* second external key flag */
	    ek_flag1_LowCount  = 0;	/* second external key flag */

u8 byNewStart=0;
u8 stop_flag=0;
long	lPulseRef = 0;
u8	  ek_flag2 = 0;	/* second external key flag */
u8	  ek_flag2_HighCount = 0,	/* second external key flag */
	    ek_flag2_LowCount  = 0;	/* second external key flag */
u8 byNewStart2=0;
u8 stop_flag2=0;
long	lPulseRef2 = 0;





s32    Start_Weight;
s32    Stop_Weight;
s32    TodayTotalref;
s32    TodayTotalref_result;

s32    Start_Weight2;
s32    Stop_Weight2;
s32    TodayTotalref2;
s32    TodayTotalref_result2;





u8  sign_flag=0; // 1: minus   0: plus

long    lDay_Ref_Weight=0;
long	 lPulseMaxHold = 0;
u8     	lPulseMaxHoldCount = 0;

long    lRefWeigh = 0;
//long    lRefWeigh2 = 0;

long    lDay_Ref_Weight2=0;
long	 lPulseMaxHold2 = 0;
u8     	lPulseMaxHoldCount2 = 0;

long    lRefWeigh2 = 0;



char once_flag=0;

char gtech_tel[] ="01034431529";

#define ApplicationAddress 0x8000000  // normal program execution address
typedef  void (*pFunction)(void);
pFunction Jump_To_Application;
u32 JumpAddress;

/*
long    NoiseSeconds = 0;    //Ver1.10 noise time setting (2001.12.27)
int     NoiseCount = 0;      //Ver1.10 relay start (2001.12.27)
long	NoiseWeightBack = 0; //Ver1.10 back weight - weight (2001.12.27)
long	NoiseWeight = 0;     //Ver1.10 (2001.12.27)
int		NoiseError = 0;      //Ver1.10 not stop (8 sec) (2001.12.27)
int     NoiseFactor = 0;     //Ver1.10 8 sec (2001.12.27)
long	NoiseWeightGo =0;    //Ver1.10  (2001.12.27)
int     NoiseLast = 0;       //Ver1.10 gnlLossLimit/1.02 (2001.12.27)
*/

//char Nongjang_Sms_Hour;
//char Nongjang_Sms_Minute;
//char Nongjang_tel[] ="01034431529";

//EXTI_InitTypeDef EXTI_InitStructure;
//ErrorStatus HSEStartUpStatus;
//ErrorStatus HSEStartUpStatus;

char CdmaSendQueue_tmp[256];
int	 CdmaSendQueue_index = 0;

char RxCdmaTokenQ_tmp[256];
int	 RxCdmaTokenQ_index = 0;

float Real_Weight;
int	  poweron_flag = 1;


// local variable >>>>>>>>>>>>>>>>>>>




//volatile u8	ghPowerOnResetStatus = 'R';	//status sendd power on reset=R, else G

//extern const struct bin  gimp_image;
extern const struct lamp  start_lamp;
extern const struct lamp  stop_lamp;


//void __MSR_MSP(u32 TopOfMainStack);

void zigbee_setting(void);
int	 RTC_time_display(void);
void logo(void);
void mode_check(void);
void Adc_Power_Off_On(void);
void Data_Clear(void); // data clear
void test_set(void);
void Data_Send_Sms(char *tel_number);
void Get_Weight(void);
void SMS_PROCESS(void);
//void Initiaize_eeprom(void);
int	isCdmaSendQueueEmpty();
int CdmaSendQueue_puts(char *txt);
int CdmaSendQueue_gets();

void modem_power_reset(void);	//LTE MODEM reset and power on/off

void sms_process(char *msg);

void zero_func(void);
void zero_func2(void);//silo 2 zero function

//GPI-8510

void  Silo_1_Led_Operation();
void  Silo_2_Led_Operation();
void  Error_1_Led_Operation();
void  Error_2_Led_Operation();
void  Silo_1_Weight_Display();
void  Silo_2_Weight_Display();


//GPI-8510



void welcome(void)
{
	//usart1_transmit_string("Hello, World! GPI-8310\r\n");


	  USART3_puts("Cdma_Power_On();");
	// STM32F105, 107 ������ PLL������ �ణ Ʋ����. 
	// ���Ŀ� PLL���� ��Ʈ���� �����ؾ� �Ѵ�.
//	usart1_transmit_string("HSE(High Speed External clock signal) Enable\r\n");
//	usart1_transmit_string("HCLK(SYSCLK) = 8MHz, PCLK2 = HCLK, PCLK1 = HCLK/2, ADCCLK = PCLK2/2\r\n");
//	usart1_transmit_string("PLLCLK = 8MHz / 1 * 9 = 72MHz, USBCLK = PLLCLK / 2 = 48MHz\r\n\r\n");
}


volatile u8 INVERSE;
volatile unsigned char   HAN_CODE;
volatile unsigned char   FONT_SIZE;             
volatile unsigned char   FONT_STYLE;
                         
volatile u16 xcharacter;
volatile u16 ycharacter;
volatile u16 xgraphic;
volatile u16 ygraphic;
volatile u16 cur_x;
volatile u16 cur_y;
volatile u16 xch;		//character x
volatile u16 ych;		//character y
volatile u16 xgr;		//graphic x
volatile u16 ygr;		//graphic y
volatile u16 xcur;		//cursor x
volatile u16 ycur;		//cursor y

volatile int cx, cy; 	//2014.8.27
volatile u8 LCX, LCY;
volatile u8 LCDPAGE;
u8		net_sign     = 0;
//u8 cal_selection;

void cal_display(void);

//void Delay_us(vu32 nCount);
// #include "stm32f10x_systick.h"


void Silo_1_Getweight(void);
void Silo_2_Getweight(void);
void SendtoPc(void);  // 

	u8 sign =0;      // for silo1
	u8 sign_2 =0;   // for silo2

u8  min_rotate=0;
u8  min_buffer=0;
u8 Rtc_Seconds;
u8 HT1381_year,HT1381_month,HT1381_date,HT1381_hour,HT1381_minute,HT1381_second; 


void Date_Time_Display(void);
char Loadcell_Error1=0,Loadcell_Error2=0;
long lPulseWeigh=0;
long lPulseWeigh2=0;

BOOL	bPulse = 0;
BOOL	bPulse2 = 0;
int  Error_Sec_Counter=0;
BOOL Output_Low_Error = 0;
BOOL Output_High_Error = 0;

int  Error_Sec_Counter2=0;
BOOL Output_Low_Error2 = 0;
BOOL Output_High_Error2 = 0;
long lOutput=0;
//char start_sign_flag=0;
 char start_sign_flag=0; // ���۽� ���繫�� ���� - �� 1, 
 char start_sign_flag_2=0; // ���۽� ���繫�� ���� - �� 1, 
	



//long gxuPulseSetWeigh=20;

#define STX 0X02
#define ETX 0X03

void Show_ToalOutput(void); // �Ѵ������ⷮ ǥ���ϱ� 
void Initial_Display(void);
void set_ip(void);  // VER 2.6 
void set_port(void);


void Phone_Sms_Processing(void);
char szMsg[15];
char szResponse[15];
char sT0[256];

s32  Output_total=0; //ver 2.6
s32  Output_total2=0; //ver 2.6 ,silo 2�� 

long UpperError_Weight=0; // 

char lte_restart_flag1=0,lte_restart_flag2=0,lte_restart_flag3=0,lte_restart_flag4=0;


	#define FIRST_INPUT_OFF_CONFIRM_COUNT       30
	#define SECOND_INPUT_OFF_CONFIRM_COUNT   30

int main(void)
{
//	long main_loop = 0;
//	long get_weight_oop = 0;
	
	int	test_sended_time = 100;
	int	poweron_date_set_counter = 2; //(4-1)��

	char sT0[256];
	char ch;
	int  iz, jz, kz;
	u32 i;
	u32 Making_zero_timer=0;
	u8 Current_Display = NORMAL_DISPLAY;
	long temp_buff;
	long temp_buff_1;
	long temp_buff_final;
	signed long which_day_feeding=0; 
	long sum;
	//signed long  v_i_value;
//	u8 sign =0;      // for silo1
//	u8 sign_2 =0;   // for silo2
	
	u32   FLASH_ID = 0;
	
	int _2MinEvent;
	long key_pressed_counter;
	char keycode_8510;
	
__disable_irq();
    bsp_init_rcc();	     //hw.comfig_c , clock configuration   , OUTPUT i
	  bsp_init_interrupt();
__enable_irq();

   bsp_key_gpio_init(); //including relay ,lcd(128 *64) and so on	

//////	buzzer_init();
/////	register_timer_function(timer2ServiceFunction, timer2_event);
//	register_rtc_function(rtcServiceFunction, rtc_event);


	 USARTx_Initial(); // usart initialize
   USART1_puts("Cdma_Power_On();");
	 Cdma_Power_On();
	 Delay_ms(100);
	 cdma_send_cmd("AT$LGTRESET", 11);	//2016.6.10 when main softreset
	 Delay_ms(100);
 	 Cdma_Power_Off();
	 Delay_ms(1000);

 
   USART1_puts("I2C_EE_Init();");
	 I2C_EE_Init();	//EEPROM port �ʱ�ȭ
	 Delay_ms(100);
	 
//	 mode_check();
	 
	 //write_factors();

   USART1_puts("read_factors();");
	 Delay_ms(100);
	 FSMC_DISABLE;
	 read_factors();  // FSMC�� disable ��Ű�� ������ eeprom read, write �� ���� ���� 
	 lcd_initial();
   lcd_clear();

	 
	//mode_check();	
		
		sprintf(str, "v_capacity : %d", v_capacity);	USART1_puts(str);
		sprintf(str, "v_division : %d", v_division);	USART1_puts(str);
		sprintf(str, "v_zero : %d", v_zero);	USART1_puts(str);
	  sprintf(str, "gnfFactor : %f", gnfFactor);	USART1_puts(str);
 
	 
	  sprintf(str, "v_capacity_2 : %d", v_capacity_2);	USART1_puts(str);
		sprintf(str, "v_division_2 : %d", v_division_2);	USART1_puts(str);
		sprintf(str, "v_zero_2 : %d", v_zero_2);	USART1_puts(str);
	  sprintf(str, "gnfFactor_2 : %f", gnfFactor_2);	USART1_puts(str);
    sprintf(str, "gnlMyAddress : %d", gnlMyAddress);	USART1_puts(str);
	
 //gnlMyAddress
 
	 //20171130
	 /*****************************RTC TEST*****************************************/
	

 Feeding_Counter1=0; //���ⷮ ����ֱ� Ÿ�̸�
 Feeding_Counter2=0; //���ⷮ ����ֱ� Ÿ�̸�



 USART1_puts("RTC TEST ");Delay_ms(2000);


	//#define  Data_Write      Rtc_Write()
	//#define  Data_Read      Rtc_Write()
	
	
	#define	 RTC_CLOCK_HIGH   GPIO_SetBits(GPIOB, GPIO_Pin_5)
  #define	 RTC_CLOCK_LOW  	GPIO_ResetBits(GPIOB, GPIO_Pin_5)
  #define	 RTC_RESET_HIGH   GPIO_SetBits(GPIOB, GPIO_Pin_9)
  #define	 RTC_RESET_LOW  	GPIO_ResetBits(GPIOB, GPIO_Pin_9)
  #define	 RTC_DATA_HIGH   GPIO_SetBits(GPIOB, GPIO_Pin_8)
  #define	 RTC_DATA_LOW  	GPIO_ResetBits(GPIOB, GPIO_Pin_8)
	
	
#define GetSecond 0x81   
#define GetMinute 0x83   
#define GetHour   0x85   
#define GetDate   0x87   
#define GetMonth  0x89   
#define GetDay    0x8b   
#define GetYear   0x8d   
#define GetTime   0x0bf   
#define WP        0x8e   
#define CH        0x80   
   
#define SetSecond 0x80   
#define SetMinute 0x82   
#define SetHour   0x84   
#define SetDate   0x86   
#define SetMonth  0x88   
#define SetDay    0x8a   
#define SetYear   0x8c   
#define SetTime   0x0be   

    Clock_Pin_Init();// RTC initialization
    Delay(500); 
  	bsp_init_timer2();
    RTC_Configuration();  /* RTC Configuration */
		key_init();
   
	 Cdma_Power_On();
   USART1_puts("RS422ON;");
	 
	 Gpi8510_Relay_On(ERROR); // ������ȣ
	// Delay_ms(3000); 
	
	//// mode_check();
	
	
	 RS422ON;	
	 Delay_ms(500); // request from Mr park
	
  
	 USART2_puts("This is RS485 Serial test !!!"); // Delay_ms(1000);
	 USART2_puts("This is RS485 Serial test !!!"); // Delay_ms(1000);
	
	
	 USART3_puts("RS422ON;");
   RS422OFF;
   USART1_puts("bsp_lcd70_init();");
   lcd_initial();
   lcd_clear();

   //All_Relay_Off();




 GLCD_string (0,0 ,"   GPI-8510     ");
 GLCD_string (0,2 ,"MULTI -PURPOSE");
 GLCD_string (0,4 ,"FEED &FEEDING");
 GLCD_string (0,6 ,"  CONTROLLER  ");
 Delay_ms(3000);
 lcd_clear();
 
 GLCD_string (0,2 ,"   VERSION   ");
 //GLCD_string (0,4 ,"   VER 1.01  ");
//GLCD_string (0,4 ,"   VER 1.1  ");// 2017�� 12�� 20�� �ڸ��� ����
//GLCD_string (0,4 ,"   VER 2.0C  ");// 2018 �� 5�� 9�� , �����Ʈ�ѷ�, �̴��� ��Ű���,  RS 422 ���α׷� ����
 // GLCD_string (0,4 ,"   VER 2.5  ");// 2018 �� 6�� 26�� , �����Ʈ�ѷ�, �̴��� ��Ű���,  RS 422 ���α׷� ����
 // GLCD_string (0,4 ,"   VER 2.61 ");  // 2021��  5�� 25�� , �����Ʈ�ѷ�, �̴��� ��Ű���,  RS 422 ���α׷� ����
 
 //GLCD_string (0,4 ,"   VER 2.90 ");  // 2022�� 3�� 30��, ADC CS5555 
// GLCD_string (0,4 ,"   VER 3.10 ");  //   2024�� 7�� 5��, 
 
 GLCD_string (0,4 ,"   VER 3.80 ");  //   2025�� 6�� 30��, 
 
 
 
 Delay_ms(3000);
 lcd_clear();

//if(!gnlCdmaUse) // ��ȭ�� ���� �ȵǾ�����
{	
 for(i=0;i<2;i++)
 Date_Time_Display(); // RTC TIME display 
 
      HT1381_year=Gettimebuf[6];
			HT1381_month=Gettimebuf[4];
			HT1381_date=Gettimebuf[3];
			HT1381_hour=Gettimebuf[2];
			HT1381_minute=Gettimebuf[1];
			HT1381_second=Gettimebuf[0];
}		
 
 
 
 
 
 
 	/******************* systick configuration, this configu must be declared here 1!***********************************************/
	    
    SysTick_CLKSourceConfig(9000000);
    SysTick_SetReload(90);// 90/9MHZ =  100 khz > a/d clock (50 k hz) 
  	SysTick_SetReload(590);// 590/9MHZ =  15.24  khz > a/d clock (7.62  k hz) 
		SysTick_SetReload(60);// 90/9MHZ =  100 khz > a/d clock (50 k hz) 
  	
		SysTick_CounterCmd(SysTick_Counter_Enable);	//Enable the SysTick Counter
		SysTick_ITConfig(ENABLE);
  
  // ads 1251 sampling 
	//  speed                        clk   
	//  20                           7.68 khz
	//  50                           19.2 khz
	// 100                           38.4 khz

 /******************* systick configuration***********************************************/

  Ten_Mili_Counter=0;
  Silo1_led_Off();
  Silo2_led_Off();
  Silo1_Error_led_Off();
  Silo2_Error_led_Off();
	
	
	adc_initial();     // ADS1251
	INIT_CS5555(); // CS5555 �ʱ�ȭ
	//adc_test();
	
	
	
	
	
	/*********** ADS 1251  ���� CS5555���� ?******************/
	
  // GLCD_string(2,6, "adc ?");
//	GLCD_string (0,2 ,"   adc ?");
   temp_buff = RDDATA_ads1251(); // � ad �����Ͱ� ���Ǿ����� �Ǵ��ϴ� �Լ�
/*

if(which_adc==1) // ���� ��ġ�� adc �� cs5555 �̸�		
{
   //lcd_clear(); 	
   GLCD_string(0,6, "CS5555"); Delay_ms(3000);
}

*/
	/*********** ADS 1251  ���� CS5555���� ?******************/
	mode_check();
	lcd_initial();
  lcd_clear();

	lcd_normal();

 v_adc_org  = (long)((float)v_zero * gnfFactor);  // calibration�� ������ ��� 
 v_ei_multiply_factor = 10;
 
 Usart3_SMS_flag = 0;
 Delay_ms(500);
 gnlDisplay=1;

 if(gnlDisplay)
	{
		sprintf(sT0, "Get_Weight() before");
	//	lcd70_show_string_mode(10, 280, (const unsigned char *)sT0, 20, 0);
	}	
	/*
	Reg_Tel[11] = 0;
	if(gnlDisplay)
	{
		sprintf(sT0, "TEL=%s", Reg_Tel);
		//lcd70_show_string_mode(470, 230, (const unsigned char *)sT0, 20, 0);
		//lcd70_show_string_mode(200, 100,"Data sendig to user_First!!", 16, 0);
		
		//lcd70_show_string_mode(300, 330, (const unsigned char *)sT0, 20, 0);
		//lcd70_show_string_mode(300, 300, "Data sendig to user_First!!", 16, 0);
	}	
*/
/****
	Data_Send_Sms(Reg_Tel); //��ϵ� ��ȣ�� ���� ������ ������ 
	Delay_ms(1000);
	Data_Send_Sms(gtech_tel);// ����ȣ���� ������ 
***/

	//CdmaSendQueue init
	CdmaSendQueue_qhead = CdmaSendQueue_qtail = 0;
	for(iz=0; iz<MAX_CDMA_QUEUE_BUFFER; iz++)
	{
		for(jz=0; jz<256; jz++)
		{
			CdmaSendQueue[iz][jz] = NULL;
		}
	}

	RxCdmaQ_qhead = RxCdmaQ_qtail = 0;
	for(iz=0; iz<RXCDMAQ_SIZE; iz++)
	{
		RxCdmaQ[iz] = NULL;
	}

	RxCdmaTokenQ_qhead = RxCdmaTokenQ_qtail = 0;

	bachul_send_timer_ms = 0;	//������ ���� ���� Ÿ�̸�
	cdma_response_waiting_flag = 0;	//cdma ������ ��ٸ��� ����
	cdma_response_wait_timer_ms = 0;	//cdma ���� ��ٸ��� Ÿ�̸�
	giCdmaStopEnabled = 0;	//cdma �� ������ stop ������ �ؾ� �ϴ°� �÷���
	
	
	
	
	

/**********************************************************************
sprintf(sT0, "tel=%s,rssi= %d",  jangbi.cdma.telno, jangbi.cdma.rssi);
send_sms("01091954072", sT0);
***********************************************************************/

DEBUG_puts("do  MAIN LOOP");

gnlUseLTE=1;


		for(iz=0;iz<3;iz++)
		{
			//add 2015.1.22
			DEBUG_puts("kwak won ho");
			cdma_send_cmd("AT$LGTDELRM=*", strlen("AT$LGTDELRM=*"));
			delay_ms(100);
		}
		
DEBUG_puts("get_cdma_info_WAIT(CDMA_GET_TELNO)");	
		
lcd_clear();
		
    if(gnlLanguage==1) // korean 
		{	
		   GLCD_string (0,0 ,"��ø�");
    GLCD_string (0,2 ,"��ٷ� �ּ���");
    GLCD_string (0,4 ,"����ʱ�ȭ��...");
  	
    }
		
	  else
	{
    GLCD_string (0,0 ,"PLEASE WAIT ....");
    GLCD_string (0,2 ,"TELEPHONE CHECK.");
    GLCD_string (0,4 ,"SEVER TESTING..");
  }		
		
	//Delay_ms(3000);
	 for(i=0;i<30;i++)
	  {

			if(which_adc==1) 
			{
				temp_buff =read_filtered_adc_CS5555_1();
				temp_buff_1 =read_filtered_adc_CS5555_2();
			}
		 else
		 { 
		  temp_buff = read_filtered_adc();
      temp_buff_1 = read_filtered_adc_1();
	   }
		delay_ms(100);
		 sprintf(str, "adc_valew: %d", temp_buff);	USART1_puts(str);
		
	  }		
//0413		
		
		
	//	Silo_1_Getweight();//
	

if(which_adc==1) 
{		
if ((read_filtered_adc_CS5555_1()< 10L) || (read_filtered_adc_CS5555_1() > 380000L))
{	
	  lcd_clear();
		 if(gnlLanguage==1) 
		 {	 
		  GLCD_string (0,0 ,"���Լ��� ����!!");
		  GLCD_string (0,4 ,"���Լ�����");
		  GLCD_string (0,6 ,"������ �ּ���!");
		  Gpi8510_Relay_Off(ERROR);
		 }
		 else
     {	 
		  GLCD_string (0,0 ,"LOAD CELL ERROR!");
		  GLCD_string (0,4 ,"CHECK");
		  GLCD_string (0,6 ,"LOAD CELL !");
		  Gpi8510_Relay_Off(ERROR);
		 }
	  return;
	
	}
}
else
{		
if ((read_filtered_adc() < 10L) || (read_filtered_adc() > 380000L))
{	
	  lcd_clear();
		 if(gnlLanguage==1) 
		 {	 
		  GLCD_string (0,0 ,"���Լ��� ����!!");
		  GLCD_string (0,4 ,"���Լ�����");
		  GLCD_string (0,6 ,"������ �ּ���!");
		  Gpi8510_Relay_Off(ERROR);
		 }
		 else
     {	 
		  GLCD_string (0,0 ,"LOAD CELL ERROR!");
		  GLCD_string (0,4 ,"CHECK");
		  GLCD_string (0,6 ,"LOAD CELL !");
		  Gpi8510_Relay_Off(ERROR);
		 }
	  return;
	
	}
}	
	
	
		
	lcd_clear();

	if(gnlCdmaUse) // ��ȭ�� ���� �Ǿ�����
 {
		for(i=0;i<100;i++)
		{	
			
    if(which_adc==1) 
			{
				temp_buff =read_filtered_adc_CS5555_1();
				temp_buff_1 =read_filtered_adc_CS5555_2();
			}
		 else
		 { 
		  temp_buff = read_filtered_adc();
      temp_buff_1 = read_filtered_adc_1();
	   }
			 
			
			
			
			//delay_ms(100);
			get_cdma_info_WAIT(CDMA_GET_TELNO, "TELNO");	//get_cdma_telno();
			get_cdma_info_WAIT(CDMA_GET_TIME, "TIME");	//get_cdma_time();
			get_cdma_info_WAIT(CDMA_GET_RSSI, "RSSI");	//get_cdma_rssi();
			//0728
			delay_ms(500);
			
			sprintf(sT0, "%2d,T=%s", i, jangbi.cdma.telno);
			GLCD_string(0,0, sT0);
			
			sprintf(sT0, "%2d,RSSI= -%d db", i, jangbi.cdma.rssi);
			GLCD_string(0,2, sT0);
			
      sprintf(sT0, "DATE=%04d-%02d-%02d", jangbi.cdma.tm.year, jangbi.cdma.tm.month, jangbi.cdma.tm.date);
		  GLCD_string(0,4, sT0);
 		
      sprintf(sT0, "TIME=%02d:%02d:%02d",  jangbi.cdma.tm.hour, jangbi.cdma.tm.min, jangbi.cdma.tm.sec);
		  GLCD_string(0,6, sT0);
			Delay_ms(150);
		if((jangbi.cdma.telno[0]=='0' )&&(jangbi.cdma.telno[1]=='1' )&&((jangbi.cdma.tm.year/100)==20)) // 20xx �⵵�̸�
		  {	
			break;
		  }	
		} //of for 
		
			for(i=0;i<2;i++)
		{	
		//	get_cdma_telno();
		
			get_cdma_info_WAIT(CDMA_GET_TELNO, "TELNO");	//get_cdma_telno();
			get_cdma_info_WAIT(CDMA_GET_TIME, "TIME");	//get_cdma_time();
			get_cdma_info_WAIT(CDMA_GET_RSSI, "RSSI");	//get_cdma_rssi();

      delay_ms(500);			
			
			sprintf(sT0, "%2d,T=%s", i, jangbi.cdma.telno);
			GLCD_string(0,0, sT0);
			
			sprintf(sT0, "%2d,RSSI= -%d db", i, jangbi.cdma.rssi);
			GLCD_string(0,2, sT0);
			
      sprintf(sT0, "DATE=%04d-%02d-%02d", jangbi.cdma.tm.year, jangbi.cdma.tm.month, jangbi.cdma.tm.date);
		  GLCD_string(0,4, sT0);
 		
      sprintf(sT0, "TIME=%02d:%02d:%02d",  jangbi.cdma.tm.hour, jangbi.cdma.tm.min, jangbi.cdma.tm.sec);
		  GLCD_string(0,6, sT0);
			Delay_ms(100);

		}// for loop

		
		
		
		
	
 } // of if(gnlCdmaUse) // ��ȭ�� ���� �Ǿ�����	
		if(gxhWeightBackup)
		{
		 v_adc_org=(long)(gnfFactor * v_zero);
     v_adc_org_2=(long)(gnfFactor_2 * v_zero_2);
		}
   else
		 {
		 v_adc_org=(long)(gnfFactor * temp_buff);
     v_adc_org_2=(long)(gnfFactor_2 * temp_buff_1);
		}

		  Silo_1_Getweight();
			Silo_1_Getweight();
			Silo_2_Getweight();
			Silo_2_Getweight();


if(gnlCdmaUse)//��ȭ�� ���õǾ����� .
{	
	for(i=0;i<2;i++)
		 {
		    Send_to_server(SEND_BAICHUL, "BC-B");	//���� ���۽� ���� ����
		  	test_routine();//ȸ�缭���� ������ 
        Delay_ms(100);
		 }	
	//close websms socket
	MultiSocketClose_LU202F( 2, 200);
	MultiSocketClose_LU202F( 2, 200);
}
		 
	monitoring_timer_ms = 10;		//send status
	monitoring_set_timer_ms = 2000;	//send set value
	Ten_Mili_Counter=0;
	Sec_Mili_Counter=0;	
	Sending_Mili_Counter=0;
	giToday = -1;
  lcd_clear(); //Delay_ms(3000);
 
 
  sprintf(str, "v_adc_or!!!: %d", v_adc_org);	USART1_puts(str);
  Led_Mili_Counter=0;
  Error_Led_Mili_Counter=0;

	
   // lcd_initial();
    //lcd_clear();
			

//0413
 /**************  Initial display *****************************/
 if(gnlSilo1Selection==1)// silo  NUMBER ==1   0413
 {
	 SendtoPc();
   Silo_1_Weight_Display(); // silo 1  current weight, feed comsumption weight displaying 
	 SendtoPc();
	 lcd_inverse();
	 if(gnlLanguage==1) // korean 
	 sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 else
	 sprintf(str, "TODAY: %5ld kg ", gnlDailyTotal);
	 
	 GLCD_string (0,6 ,str);
	 lcd_normal();

 }
else // silo number is 2  20171019
 {
	  if(gnlLanguage==1)
	 { 
	 lcd_inverse(); 
   sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 lcd_normal();
	  /*
	 sprintf(str, "���̷�1:%5ld kg", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "���̷�2:%5ld kg", gnlDailyTotal2);
	 */
 	 //ver 2.8
		sprintf(str, "���̷�1:%5ld kg", gnlFeeding1);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "���̷�2:%5ld kg", gnlFeeding2);
	 GLCD_string (0,4 ,str);
	
		 lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "�� ��: %5ld kg",sum);
 
		 
		 
		 //sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 GLCD_string (0,6 ,str);
	 lcd_normal();
	 }
	 else
	 { 
	 lcd_inverse(); 
   sprintf(str, "SILO:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 lcd_normal();
	 sprintf(str, "FEED1:%5ld kg", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "FEED2:%5ld kg", gnlDailyTotal2);
	 GLCD_string (0,4 ,str);
	 lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "TODAY: %5ld kg ",sum);
 //sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 GLCD_string (0,6 ,str);
	 lcd_normal();
	 }
	  
	
	}
 /**************  Initial display *****************************/
 
//	 if(gnlSilo1Selection==1)// silo  NUMBER ==1
//		  Silo_1_Weight_Display(); // silo 1  current weight, feed comsumption weight displaying 
	
	
	
 
 /************** �̴��� ����   ó�� ���� ON  ***************************/
	
	//	RS422ON;	
		//  if(gnlSendingInterval)
      {				
	      if(gnlSilo1Selection==1)
				{
	        sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-S|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, gxlWeight, gnlDailyTotal%100000,
					 (long)gnlPreDailyTotal[0]%100000, (long)gnlPreDailyTotal[1]%100000, (long)gnlPreDailyTotal[2]%100000, (long)gnlPreDailyTotal[3]%100000,
					 (long)gnlPreDailyTotal[4]%100000, (long)gnlPreDailyTotal[5]%100000, (long)gnlPreDailyTotal[6]%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }
     else
       {
	        sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-S|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, (gxlWeight+gxlWeight_2), (gnlDailyTotal+gnlDailyTotal2)%100000,
					 (long)(gnlPreDailyTotal[0]+gnlPreDailyTotal2[0])%100000, (long)(gnlPreDailyTotal[1]+gnlPreDailyTotal2[01])%100000, (long)(gnlPreDailyTotal[2]+gnlPreDailyTotal2[2])%100000, 
						 (long)(gnlPreDailyTotal[3]+gnlPreDailyTotal2[3])%100000,
					 (long)(gnlPreDailyTotal[4]+gnlPreDailyTotal2[4])%100000, (long)(gnlPreDailyTotal[5]+gnlPreDailyTotal2[5])%100000, (long)(gnlPreDailyTotal[6]+gnlPreDailyTotal2[6])%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }
			 }
				 
				if(gnlSendingInterval) //������ ���۽ð��� ���� �� �������� 
		      USART2_puts(sT0);
		      Sending_Mili_Counter=0;
	
	/************** �̴��� ����   ó�� ���� ON  ***************************/
	
	
	
		//lcd_initial();
    //lcd_clear();
		
		//	Silo_1_Weight_Display(); // silo 1  current weight, feed comsumption weight displaying 	
				
				
	
 
	do
	{
			SendtoPc(); // for pc program rs_422  
		  Phone_Sms_Processing();// lte �����ü�� �ִ�  ����  sms ó�� 
		
		
		
		
		
		
		
		
		IWDG_ReloadCounter(); // Reload IWDG counter
		
	//	#ifdef dpfdpfdpfpd 
		
		RTC_sec_to_time_conversion();
		if(gnlDisplay) 
		{
			RTC_time_display();	
			sprintf(sT0, "gnuDay=%d, working_flag=%d, gnhToday=%d, jangbi.cdma.tm.min=%d, mCnt=%ld, INTERVAL=%ld", gnuDay, working_flag, giToday, jangbi.cdma.tm.min, Ten_Mili_Counter, GET_TIME_INTERFAL_TIME);
			//lcd70_show_string_mode(10, 280, (const unsigned char *)sT0, 20, 0);
		}
	   	////////////���׺񿡼� �� ������ ����
#ifdef dpfdpfdp	

		for(i=0;;i++)
		{
			iz = USART4_Rx_queue_get();
			if(iz == -1) break; //empty
			else
			{
USART1_putchar(iz);
				CdmaSendQueue_tmp[CdmaSendQueue_index++] = iz;
				if(iz == 0x0a)
				{
					CdmaSendQueue_tmp[CdmaSendQueue_index] = NULL;
					if(gnlUseLTE) //lte ����ϴ� �����̸� ���׺�� �޾Ƽ� ������ ����
					{
						if( !strncmp( CdmaSendQueue_tmp, "OK", 2) && strlen(CdmaSendQueue_tmp)<5)
						{
						}
						if( !strncmp( &CdmaSendQueue_tmp[1], "DATE=", 5))
						{
						}
						else CdmaSendQueue_puts(CdmaSendQueue_tmp);
					}
					else
					{
						for(jz=0; jz<strlen(CdmaSendQueue_tmp); jz++)
						{
							if(CdmaSendQueue_tmp[jz] == '$')
							{
								sms_process(&CdmaSendQueue_tmp[jz]);
							}
						}
					}
				 	CdmaSendQueue_index = 0;

					break;
				}
			}		
		} 	////////////���׺񿡼� �� ������ ����
#endif
		
if(gnlCdmaUse) //��ȭ�Ⱑ ���õǾ�����	
	 {	
	   	//////////////////CDMA���� �� ������ ����
		for(i=0;;i++)
		{
			iz = RxCdmaQ_get();
			if(iz == -1) break; //empty
			else
			{
USART1_putchar(iz);
				RxCdmaTokenQ_tmp[RxCdmaTokenQ_index++] = iz;
				if(iz == 0x0a)
				{
					RxCdmaTokenQ_tmp[RxCdmaTokenQ_index] = NULL;
					RxCdmaTokenQ_puts(RxCdmaTokenQ_tmp);
				 	RxCdmaTokenQ_index = 0;

					break;
				}
			}		
		}	//////////////////CDMA���� �� ������ ����



/**
		sT0[i] = NULL;
		CdmaSendQueue_puts(sT0);
*/
////		if( !giGigbeeSendingFlag)
		{
			jz = CdmaSendQueue_gets();
			if(jz != -1)	//���� �����Ͱ� ������
			{
				giGigbeeSendingFlag = 1;
//				giGigbeeSendingRetry = MAX_giGigbeeSendingRetry;	//2014.8.25

///				strcpy(gszSendingGigbee, CdmaSendQueue[jz]);
				if(gnlUseLTE)
				{
///					sprintf( gszSendingGigbee,"%c|%s|%s", 0x02, jangbi.cdma.telno, CdmaSendQueue[jz]);
					gszSendingGigbee[0] = 0x02;
					gszSendingGigbee[1] = '|';
					for(iz=0; iz<11; iz++) if(jangbi.cdma.telno[iz]) gszSendingGigbee[iz+2] = jangbi.cdma.telno[iz];
					gszSendingGigbee[iz+2] = '|';
					kz = iz+3;
//					for(iz=0; iz<strlen(CdmaSendQueue[jz]); iz++) gszSendingGigbee[iz+kz] = CdmaSendQueue[jz][iz+2]; //stx ����
					for(iz=0; iz<strlen(CdmaSendQueue[jz]); iz++) gszSendingGigbee[iz+kz] = CdmaSendQueue[jz][iz]; 
///					sprintf( gszSendingGigbee,"|012345678901|%s", CdmaSendQueue[jz]);
///				sprintf( gszSendingGigbee,"AT+UNICAST=0000,%s|%s", jangbi.cdma.telno, &CdmaSendQueue[jz][2]);

//sprintf(sT0, "==(%d)|%s|==", strlen(jangbi.cdma.telno), jangbi.cdma.telno);
//DEBUG_puts(sT0);
//DEBUG_puts(CdmaSendQueue[jz]);
//DEBUG_puts(gszSendingGigbee);
					
sprintf(sT0, "CdmaSendQueue_qhead=%d, CdmaSendQueue_qtail=%d, %s", CdmaSendQueue_qhead, CdmaSendQueue_qtail, CdmaSendQueue[jz]);
DEBUG_puts(sT0);
					
				}
				else
				{
					sprintf( gszSendingGigbee,"AT+UNICAST=0000,%s", &CdmaSendQueue[jz][2]);
				}
				giSendingGigbeeLength = strlen(gszSendingGigbee);

USART1_puts("::::::::::::");
//USART1_puts(&CdmaSendQueue[jz][1]);
DEBUG_puts(gszSendingGigbee);

			}
		}///	if( !giGigbeeSendingFlag)

		/////////////////////////////////////////////////////////
		//USART3 CDMA SMS �޾��� ��
		if(Usart3_sms_received_flag)
		{
			SMS_PROCESS();
		}

		
	} // ��ȭ�Ⱑ ���õǾ�����		
		
		
		
		
		

////if(gnlSilo1Selection==1|| gnlSilo1Selection==2) // both silo 1ea or silo 2 ea  
{
		FIRST_INPUT_ON
		{
			 if(!ek_flag1)
			 {
			ek_flag1_HighCount = (ek_flag1_HighCount +1) % 50;
			ek_flag1_LowCount  = 0;
			if(ek_flag1_HighCount>2)
			{
			//	if(!ek_flag1)
				if(!Output_Low_Error&&!Output_High_Error)
				{	
				///if(!sign)
				{
		     //0212  
					if(sign)
          start_sign_flag=1;
          else
          start_sign_flag=0;						
		     
					
					ek_flag1=1;
				  First_Relay_On();
				 goto start_func;
        
				}
			  }
			}
		}
		} // of FIRST_INPUT_ON
	
		/*
		else 
		{
			 	if(ek_flag1)
				{
			ek_flag1_LowCount = (ek_flag1_LowCount +1) % 50;
			ek_flag1_HighCount  = 0;
			if( ek_flag1_LowCount>2)
			{
				
			//	if(ek_flag1)
				//if(!sign_2)
				{  
					 First_Relay_Off();
		       byNewStart = gxhEndDelay;
				  ek_flag1=0;
				  stop_flag=1;	  //ver3.02
				}
			}
		}
		}  // else
		*/
		
	//	#define FIRST_INPUT_OFF_CONFIRM_COUNT   100
		//#define SECOND_INPUT_OFF_CONFIRM_COUNT   100


else 
{
    if(ek_flag1)
    {
        if(ek_flag1_LowCount < 250)
            ek_flag1_LowCount++;

        ek_flag1_HighCount = 0;

        if(ek_flag1_LowCount > FIRST_INPUT_OFF_CONFIRM_COUNT)
        {
            First_Relay_Off();

            byNewStart = gxhEndDelay;
            ek_flag1 = 0;
            stop_flag = 1;
        }
    }
}
		
	}// of gnlSilo1Selection

//if(gnlSilo2Selection) // only when silo2 enable
////else if(gnlSilo1Selection==2) // silo number is 2 ea  

	{
	SECOND_INPUT_ON
		{
			if(!ek_flag2)
			{
			ek_flag2_HighCount = (ek_flag2_HighCount +1) % 50;
			ek_flag2_LowCount  = 0;
			if(ek_flag2_HighCount>2)
			{

     // if(!ek_flag2)
		if(!Output_Low_Error2&&!Output_High_Error2)	
			{
			////if(!sign_2)
				{
        
				if(sign_2)
          start_sign_flag_2=1;
          else
          start_sign_flag_2=0;						
		    	
					
					
			 Second_Relay_On();
 				ek_flag2=1;
				 Second_Relay_On();
				goto start_func;
			  }
			}
			}
		}
		}
	//	#define SECOND_INPUT_OFF_CONFIRM_COUNT   100

else 
{
    if(ek_flag2)
    {
        if(ek_flag2_LowCount < 250)
            ek_flag2_LowCount++;

        ek_flag2_HighCount = 0;

        if(ek_flag2_LowCount > SECOND_INPUT_OFF_CONFIRM_COUNT)
        {
            Second_Relay_Off();
            USART1_puts("Second input real off!\r\n");

            byNewStart2 = gxhEndDelay;
            ek_flag2 = 0;
            stop_flag2 = 1;
        }
    }
}
		/*
		else 
		{
				sprintf(str, "Second input off!");	USART1_puts(str);
    
			if(ek_flag2)
			 {
			ek_flag2_LowCount = (ek_flag2_LowCount +1) % 50;
			ek_flag2_HighCount  = 0;
			if( ek_flag2_LowCount>2)
			{
			//	if(ek_flag2)
				{
					 Second_Relay_Off();
					sprintf(str, "Second input off!");	USART1_puts(str);
				  byNewStart2 = gxhEndDelay;
					ek_flag2=0;
				 stop_flag2=1;	  //ver3.02
				}
			}
		 }
		  
		
		}  //else
 	 */ 
	
	
	}
		SendtoPc();
		
		
		if(Sec_Mili_Counter>=DEF_1_SEC) // 1�ʿ� �ѹ���   20180104
		{
			Sec_Mili_Counter=0;	
			Error_Sec_Counter++;
			Error_Sec_Counter2++;
			
			if(working_flag && stop_flag)	 //
			{
				if (byNewStart) --byNewStart;
			}	
  //silo 2
     	if(working_flag_2 && stop_flag2)	 //
			{
				if (byNewStart2) --byNewStart2;
			}	
		}

		if(working_flag && stop_flag) // �����߿�   ������ȣ�� ��������  
		{
			if (!byNewStart)	//ver 1.34 if new start	  ver 3.02
			{
				//gnlDailyTotal += (lDay_Ref_Weight - gxlGrossWeight);//VER1.32	   critical 
				goto stop_func;
			}
		}

		
		if(working_flag_2 && stop_flag2) // �����߿�   ������ȣ�� ��������  
		{
			if (!byNewStart2)	//ver 1.34 if new start	  ver 3.02
			{
				//gnlDailyTotal += (lDay_Ref_Weight - gxlGrossWeight);//VER1.32	   critical 
				goto stop_func;
			}
		}

		
	//#ifdef dpfdpfp 	
		
	//20180509	
		//���� ���� ����
		if(baichul_start_flag)	//������� ���� ����
		{
			//RS422ON;
			USART2_puts("Baichul start !!");
			baichul_start_flag = 0;
			Send_to_server(SEND_BAICHUL, "BC-B");	//���� ���۽� ���� ����
			//USART2_puts("Baichul start !!"); 
			 if(gnlSilo1Selection==1)
			 { 
			sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-B|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, gxlWeight, gnlDailyTotal%100000,
					 (long)gnlPreDailyTotal[0]%100000, (long)gnlPreDailyTotal[1]%100000, (long)gnlPreDailyTotal[2]%100000, (long)gnlPreDailyTotal[3]%100000,
					 (long)gnlPreDailyTotal[4]%100000, (long)gnlPreDailyTotal[5]%100000, (long)gnlPreDailyTotal[6]%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }	 
				else
       {
	        sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-S|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, (gxlWeight+gxlWeight_2), (gnlDailyTotal+gnlDailyTotal2)%100000,
					 (long)(gnlPreDailyTotal[0]+gnlPreDailyTotal2[0])%100000, (long)(gnlPreDailyTotal[1]+gnlPreDailyTotal2[01])%100000, (long)(gnlPreDailyTotal[2]+gnlPreDailyTotal2[2])%100000, 
						 (long)(gnlPreDailyTotal[3]+gnlPreDailyTotal2[3])%100000,
					 (long)(gnlPreDailyTotal[4]+gnlPreDailyTotal2[4])%100000, (long)(gnlPreDailyTotal[5]+gnlPreDailyTotal2[5])%100000, (long)(gnlPreDailyTotal[6]+gnlPreDailyTotal2[6])%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }
					if(gnlSendingInterval) 
		      USART2_puts(sT0);
		  
			
		}
		else if(working_flag)	//������ ���� ���� 20180626
		{
			if( !bachul_send_timer_ms)	//������ ���� ���� ���� �����߿��� 10�а������� ����
			{
				//RS422ON;
				USART2_puts("Baichul jung sending !!");
				bachul_send_timer_ms = WORKING_SEND_INTERVAL;    //�����߿��� 10�а������� 
				Send_to_server(SEND_BAICHUL, "BC-J");	//������ ���� ����
				//USART2_puts("Baichul jung sending !!");
					 if(gnlSilo1Selection==1)
			 { 
			    sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-J|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, gxlWeight, gnlDailyTotal%100000,
					 (long)gnlPreDailyTotal[0]%100000, (long)gnlPreDailyTotal[1]%100000, (long)gnlPreDailyTotal[2]%100000, (long)gnlPreDailyTotal[3]%100000,
					 (long)gnlPreDailyTotal[4]%100000, (long)gnlPreDailyTotal[5]%100000, (long)gnlPreDailyTotal[6]%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }	 
					 else
       {
	        sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-S|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, (gxlWeight+gxlWeight_2), (gnlDailyTotal+gnlDailyTotal2)%100000,
					 (long)(gnlPreDailyTotal[0]+gnlPreDailyTotal2[0])%100000, (long)(gnlPreDailyTotal[1]+gnlPreDailyTotal2[01])%100000, (long)(gnlPreDailyTotal[2]+gnlPreDailyTotal2[2])%100000, 
						 (long)(gnlPreDailyTotal[3]+gnlPreDailyTotal2[3])%100000,
					 (long)(gnlPreDailyTotal[4]+gnlPreDailyTotal2[4])%100000, (long)(gnlPreDailyTotal[5]+gnlPreDailyTotal2[5])%100000, (long)(gnlPreDailyTotal[6]+gnlPreDailyTotal2[6])%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }
					 if(gnlSendingInterval)
		      USART2_puts(sT0);
		  
			}
		}
		else if(baichul_end_flag) //����Ϸ� ���� ����
		{
				//RS422ON;	
			USART2_puts("Baichul end !!");
			baichul_end_flag = 0;
					 if(gnlSilo1Selection==1)
			 { 
			sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-E|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, gxlWeight, gnlDailyTotal%100000,
					 (long)gnlPreDailyTotal[0]%100000, (long)gnlPreDailyTotal[1]%100000, (long)gnlPreDailyTotal[2]%100000, (long)gnlPreDailyTotal[3]%100000,
					 (long)gnlPreDailyTotal[4]%100000, (long)gnlPreDailyTotal[5]%100000, (long)gnlPreDailyTotal[6]%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }	 
			else
       {
	        sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-S|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, (gxlWeight+gxlWeight_2), (gnlDailyTotal+gnlDailyTotal2)%100000,
					 (long)(gnlPreDailyTotal[0]+gnlPreDailyTotal2[0])%100000, (long)(gnlPreDailyTotal[1]+gnlPreDailyTotal2[01])%100000, (long)(gnlPreDailyTotal[2]+gnlPreDailyTotal2[2])%100000, 
						 (long)(gnlPreDailyTotal[3]+gnlPreDailyTotal2[3])%100000,
					 (long)(gnlPreDailyTotal[4]+gnlPreDailyTotal2[4])%100000, (long)(gnlPreDailyTotal[5]+gnlPreDailyTotal2[5])%100000, (long)(gnlPreDailyTotal[6]+gnlPreDailyTotal2[6])%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }
			
					 
					 if(gnlSendingInterval)
		      USART2_puts(sT0);
		  
			Send_to_server(SEND_BAICHUL, "BC-E");	//���� �Ϸ� ���� ����
			//USART2_puts("Baichul end !!"); 
		}

		if(gnlDisplay)
		{
			//gi8310-0122	
			sprintf(sT0, "%08ld", monitoring_timer_ms);
			//lcd70_show_string_mode(10, 280, (const unsigned char *)sT0, 20, 0);
		}
	
		
		
		/*

				sprintf(sT0, "%08ld", Sending_Mili_Counter);
		   RS422ON;	 Delay_ms(100);
	     USART2_puts(sT0);
		*/
		
	// 0509 ethernet sending 	
if(Sending_Mili_Counter>=(DEF_1_MIN*gnlSendingInterval)) // 1�ð��� �ѹ��� 
//if(Sending_Mili_Counter>=(DEF_1_MIN*1)) // 1�ð��� �ѹ��� 

//		DEF_1_SEC
//	if(Sending_Mili_Counter>=(DEF_1_SEC*20))
		{
			//  lcd_initial();
  
		 //		RS422ON;	
			
				 if(gnlSilo1Selection==1)
			 { 
		  	sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-N|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, gxlWeight, gnlDailyTotal%100000,
					 (long)gnlPreDailyTotal[0]%100000, (long)gnlPreDailyTotal[1]%100000, (long)gnlPreDailyTotal[2]%100000, (long)gnlPreDailyTotal[3]%100000,
					 (long)gnlPreDailyTotal[4]%100000, (long)gnlPreDailyTotal[5]%100000, (long)gnlPreDailyTotal[6]%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }		 
					 else
       {
	        sprintf( sT0, "%c|01212345678|M000|77777|M%07ld|M%03ld|BC-N|%s|%lx|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%ld|%c|%c",
					 STX,gnlSerialNo, gnlMyAddress, VERSION, gnlTick, (gxlWeight+gxlWeight_2), (gnlDailyTotal+gnlDailyTotal2)%100000,
					 (long)(gnlPreDailyTotal[0]+gnlPreDailyTotal2[0])%100000, (long)(gnlPreDailyTotal[1]+gnlPreDailyTotal2[01])%100000, (long)(gnlPreDailyTotal[2]+gnlPreDailyTotal2[2])%100000, 
						 (long)(gnlPreDailyTotal[3]+gnlPreDailyTotal2[3])%100000,
					 (long)(gnlPreDailyTotal[4]+gnlPreDailyTotal2[4])%100000, (long)(gnlPreDailyTotal[5]+gnlPreDailyTotal2[5])%100000, (long)(gnlPreDailyTotal[6]+gnlPreDailyTotal2[6])%100000,
					 ((working_flag)?'W':'N')
					 , gxlGrossWeight_2, gnlDailyTotal2%100000,
					 (long)gnlPreDailyTotal2[0]%100000, (long)gnlPreDailyTotal2[1]%100000, (long)gnlPreDailyTotal2[2]%100000, (long)gnlPreDailyTotal2[3]%100000,
					 (long)gnlPreDailyTotal2[4]%100000, (long)gnlPreDailyTotal2[5]%100000, (long)gnlPreDailyTotal2[6]%100000,
					 ((working_flag_2)?'W':'N'),ETX 
					 
					 );
				 }
			
					 //0303
					 Send_to_server(SEND_BAICHUL, "BC-N");	//���� �Ϸ� ���� ����
				   test_routine();
					 
					 if(gnlSendingInterval)
		      USART2_puts(sT0);
		    Sending_Mili_Counter=0;
 }	
		
 
 
 
 
 
 
 
		
		
		
		//0828
	//if(Sending_Mili_Counter>=(DEF_1_SEC*2)) // 1�ʿ� �ѹ��� 
	{
		//   Sending_Mili_Counter=0;
      test_routine();//ȸ�缭���� ������ 
	}	
	
//	#endif
	
		/*
			15�и���
			1. CDMA ��¥ �о����
			2. SMS 3�� ������ �����ð���
			3. ���� �ٲ��, ���⳯¥ ��� (D-N), �� ����Ʈ����
		*/	
		if(Ten_Mili_Counter>=GET_TIME_INTERFAL_TIME)	// 3�п� �ѹ���1204
		{
			Ten_Mili_Counter=0;
		////	if(!gnlCdmaUse) //��ȭ�� ��� ���Ҷ�
			{	
			Get1381(); // �ð��� �о���� 
			HT1381_year=Gettimebuf[6];
			HT1381_month=Gettimebuf[4];
			HT1381_date=Gettimebuf[3];
			HT1381_hour=Gettimebuf[2];
			HT1381_minute=Gettimebuf[1];
			HT1381_second=Gettimebuf[0];
		  }
			
			sprintf(str, "date:20%02x-%02X-%02X  time:%02x-%02X-%02X ", Gettimebuf[6],Gettimebuf[4],Gettimebuf[3],Gettimebuf[2],Gettimebuf[1],Gettimebuf[0]);
			USART1_puts(str);
			
			 if(gnlCdmaUse)// ��ȭ�� ����Ѵٸ�
			 {	
			 get_cdma_info_WAIT(CDMA_GET_TIME, "TIME");	//get_cdma_time();
        delay_ms(500);			
			  sprintf(str, "kwakwonho=%02d:%02d:%02d",  jangbi.cdma.tm.hour, jangbi.cdma.tm.min, jangbi.cdma.tm.sec);
		
		// ��ħ 9�ÿ� ������ lte reset	
		  if(!lte_restart_flag1 && jangbi.cdma.tm.hour==9)
			{
				
			  modem_power_reset();
				USART1_puts("modem restart !!!"); //Delay_ms(2000);
			  lte_restart_flag1=1;
			}
			
			if(jangbi.cdma.tm.hour!=9)
			 lte_restart_flag1=0;	
			
		//  ���� 3�ÿ� ������ lte reset	
			   if(!lte_restart_flag2 && jangbi.cdma.tm.hour==15)
			{
			  modem_power_reset();
				USART1_puts("modem restart !!!"); //Delay_ms(2000);
			  lte_restart_flag2=1;
			}
			
			if(jangbi.cdma.tm.hour!=15)
			 lte_restart_flag2=0;	
		 
		
			 
			 
			 
			 }
			
			
			/*		
			
		 	
			if(gnlCdmaUse) //��ȭ�� ��� �Ҷ�
			{	
			
			//if (giToday != HT1381_date && !working_flag) //������ġ ��ȯ,�Ϸ簡 �ٲ����. 1204
		//	if (giToday != rtc_date && !working_flag)
     if (giToday != rtc_date)
			{
				DATE_CHANGE:
				
		 	  beep(300);
				USART1_puts("Date is changed");
			//	if(gnlCdmaUse)// ���ϱ� ����Ѵٸ� 
				giToday = rtc_date;
			//	else
			//	giToday = HT1381_date;

				Once_flag=0;
				Once_flag_First=0;
				Once_flag_Second=0;
				Once_flag_Third=0;

				//for (i=6; i; i--) gnlPreDailyTotal[i] = gnlPreDailyTotal[i-1];
		   gnlPreDailyTotal[6]=gnlPreDailyTotal[5];
       gnlPreDailyTotal[5]=gnlPreDailyTotal[4];
       gnlPreDailyTotal[4]=gnlPreDailyTotal[3];
       gnlPreDailyTotal[3]=gnlPreDailyTotal[2];
       gnlPreDailyTotal[2]=gnlPreDailyTotal[1];
       gnlPreDailyTotal[1]=gnlPreDailyTotal[0];
       gnlPreDailyTotal[0] = gnlDailyTotal;

				//		for (i=6; i; i--) gnlPreDailyTotal2[i] = gnlPreDailyTotal2[i-1];
			 gnlPreDailyTotal2[6]=gnlPreDailyTotal2[5];
       gnlPreDailyTotal2[5]=gnlPreDailyTotal2[4];
       gnlPreDailyTotal2[4]=gnlPreDailyTotal2[3];
       gnlPreDailyTotal2[3]=gnlPreDailyTotal2[2];
       gnlPreDailyTotal2[2]=gnlPreDailyTotal2[1];
       gnlPreDailyTotal2[1]=gnlPreDailyTotal2[0];
       gnlPreDailyTotal2[0] = gnlDailyTotal2;




				gnuDay++;	// 0908
				gnuDay2++;	// increase day 
				gnlDailyTotal = 0;
				gnlDailyTotal2 = 0;
				save_DailyTotals();
			 if(!Output_Low_Error && !Output_Low_Error2 &&!Output_High_Error)
			 {        				 
				//20171018
				if(gnlSilo1Selection==1)
				{
				 lcd_inverse();
				 if(gnlLanguage==1) // korean 
	       sprintf(str, "�� ��: %5ld  kg", gnlDailyTotal);
	       else
	       sprintf(str, "DAY-0: %5ld  kg", gnlDailyTotal);
	       GLCD_string (0,6 ,str);
	       lcd_normal(); 
				 which_day_feeding=0;
				 Silo_1_Weight_Display();  // 0627
			 }
				else // silo 2 ea
        {
				 lcd_inverse(); 
         sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	       GLCD_string (0,0 ,str);
	       lcd_normal();
	       sprintf(str, "���̷�1:%5ld kg", gnlDailyTotal);
	       GLCD_string (0,2 ,str);
	       sprintf(str, "���̷�2:%5ld kg", gnlDailyTotal2);
	       GLCD_string (0,4 ,str);
	       lcd_inverse();
	       sum=gnlDailyTotal+gnlDailyTotal2;
	      sprintf(str, "�� ��  :%5ld kg",sum);
	      GLCD_string (0,6 ,str);
	      lcd_normal();
			 }
		 }	//if(!Output_Low_Error)
 				 modem_power_reset();

			}//of (giToday != rtc_date && !working_flag)
		} // ��ȭ�� ����Ҷ�	
	 else

  */
	
	//if(gnlCdmaUse)// ��ȭ�� ����Ѵٸ�
	//	HT1381_date=rtc_date;
	
	 
	{	
	//		if (giToday != HT1381_date && !working_flag) //������ġ ��ȯ,�Ϸ簡 �ٲ����. 1204
			//if (giToday != rtc_date && !working_flag)
     if (giToday != HT1381_date ) //������ġ ��ȯ,�Ϸ簡 �ٲ����. 1204 VER 2.6
			{
			//	DATE_CHANGE:
				
		 	  beep(300);
				
				
				USART1_puts("Date is changed");
			//	if(gnlCdmaUse)// ���ϱ� ����Ѵٸ� 
			//	giToday = rtc_date;
			//	else
				giToday = HT1381_date;

				Once_flag=0;
				Once_flag_First=0;
				Once_flag_Second=0;
				Once_flag_Third=0;

				//for (i=6; i; i--) gnlPreDailyTotal[i] = gnlPreDailyTotal[i-1];
		   gnlPreDailyTotal[6]=gnlPreDailyTotal[5];
       gnlPreDailyTotal[5]=gnlPreDailyTotal[4];
       gnlPreDailyTotal[4]=gnlPreDailyTotal[3];
       gnlPreDailyTotal[3]=gnlPreDailyTotal[2];
       gnlPreDailyTotal[2]=gnlPreDailyTotal[1];
       gnlPreDailyTotal[1]=gnlPreDailyTotal[0];
       gnlPreDailyTotal[0] = gnlDailyTotal;

				//		for (i=6; i; i--) gnlPreDailyTotal2[i] = gnlPreDailyTotal2[i-1];
			 gnlPreDailyTotal2[6]=gnlPreDailyTotal2[5];
       gnlPreDailyTotal2[5]=gnlPreDailyTotal2[4];
       gnlPreDailyTotal2[4]=gnlPreDailyTotal2[3];
       gnlPreDailyTotal2[3]=gnlPreDailyTotal2[2];
       gnlPreDailyTotal2[2]=gnlPreDailyTotal2[1];
       gnlPreDailyTotal2[1]=gnlPreDailyTotal2[0];
       gnlPreDailyTotal2[0] = gnlDailyTotal2;




				gnuDay++;	// 0908
				gnuDay2++;	// increase day 
				gnlDailyTotal = 0;
				gnlDailyTotal2 = 0;
				save_DailyTotals();
				
				//20171018
				if(!Output_Low_Error&&!Output_Low_Error2&&!Output_High_Error)
				{
				if(gnlSilo1Selection==1)
				{
				 lcd_inverse();
				 if(gnlLanguage==1) // korean 
	       sprintf(str, "�� ��: %5ld  kg", gnlDailyTotal);
	       else
	       sprintf(str, "TODAY: %5ld  kg", gnlDailyTotal);
	       GLCD_string (0,6 ,str);
	       lcd_normal(); 
				 which_day_feeding=0;
				 Silo_1_Weight_Display(); //0627
			 }
				else // silo 2 ea
        {
					
				 if(gnlLanguage==1) // korean
				 {					 
				  lcd_inverse(); 
          sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	        GLCD_string (0,0 ,str);
	        lcd_normal();
	        sprintf(str, "���̷�1:%5ld kg", gnlDailyTotal);
	        GLCD_string (0,2 ,str);
	        sprintf(str, "���̷�2:%5ld kg", gnlDailyTotal2);
	        GLCD_string (0,4 ,str);
	        lcd_inverse();
	        sum=gnlDailyTotal+gnlDailyTotal2;
	       sprintf(str, "�� ��: %5ld kg",sum);
	       GLCD_string (0,6 ,str);
	        lcd_normal();
				 }
       else				 
				{					 
				 lcd_inverse(); 
         sprintf(str, "SILO:%5ld-%5ld", gxlWeight,gxlWeight_2);
	       GLCD_string (0,0 ,str);
	       lcd_normal();
	       sprintf(str, "FEED1:%5ld kg", gnlDailyTotal);
	       GLCD_string (0,2 ,str);
	       sprintf(str, "FEED2:%5ld kg", gnlDailyTotal2);
	       GLCD_string (0,4 ,str);
	       lcd_inverse();
	       sum=gnlDailyTotal+gnlDailyTotal2;
	      sprintf(str, "TODAY: %5ld kg",sum);
	      GLCD_string (0,6 ,str);
	      lcd_normal();
				 } 
					
					
			 }
		 }
 				 modem_power_reset();

			}//of (giToday != rtc_date && !working_flag)
		} // ��ȭ�� ����Ҷ�	
				 
  


		
			//Buzzer_On(300);	//11
			//Data_Send_Sms(Reg_Tel); //��ϵ� ��ȣ�� ���� ����ī ������ 
		} //if(Ten_Mili_Counter>=GET_TIME_INTERFAL_TIME)	// 15������ ����  //15�и��� �ð��о 
	//void Silo_1_Getweight(void);
		
//ver3.00		
		
 if(!Output_Low_Error&&!Output_Low_Error2&&!Output_High_Error)   //20180627
 {
 if(gnlSilo1Selection==1) // only when silo1 is enabled 
 {	 SendtoPc();
	Silo_1_Getweight();
	if(gnlLanguage==1)
	{	
	 if(sign)	 
	 sprintf(str, ":-%5ld kg ", gxlWeight);
  else		 
  {
 	 sprintf(str, ": %5ld kg ", gxlWeight);
	}
	GLCD_string(5,0, str);
 }

 else
	{	
	 if(sign)	 
	 sprintf(str, ":-%5ld kg ", gxlWeight);
  else		 
  {
 	 sprintf(str, ": %5ld kg ", gxlWeight);
	}
	
	GLCD_string(5,0, str);
 } 
	
 
 if(gxlWeight>99999)
 {
	   lcd_clear();
	    if(gnlLanguage==1)
      {				
	    GLCD_string (0,0 ,"���Լ��� ����!!");
	    GLCD_string (0,2 ,"��� ������ ����");
		  GLCD_string (0,4 ,"���Լ�����");
		  GLCD_string (0,6 ,"������ �ּ���!");
		  Gpi8510_Relay_On(ERROR);
      }
		 else
      {
        GLCD_string (0,0 ,"LOAD CELL ERROR!");
		    GLCD_string (0,2 ,"POWER OFF !");
		    GLCD_string (0,4 ,"CHECK");
		    GLCD_string (0,6 ,"LOAD CELL !");
		    Gpi8510_Relay_On(ERROR);
				
	    }	
			
	  while(1)
		{
     Delay_ms(10);			
			};	
 } // if(gxlWeight>99999)
 
 //210412
 
 
 
 
 
 
	
	//GLCD_string(0,0, str);
	
	 SendtoPc();
 }	// of if(gnlSilo1Selection==1) // only when silo1 is enabled 
 
 //#ifdef dpfdp
 else if(gnlSilo1Selection==2)//1211
 {
	 SendtoPc();
	Silo_1_Getweight();
	 SendtoPc();
  Silo_2_Getweight();
 SendtoPc();	 
 lcd_inverse();
	 
//����ǥ�� 	
 /*
	 if(sign&&!sign_2)
	 sprintf(str, "-%4ld/%5ld", gxlWeight,gxlWeight_2);
	else if(!sign&sign_2)
	sprintf(str, "%5d*-%4ld", fwor,gxlWeight_2);
  else if(sign&&sign_2)	
	sprintf(str, "-%4d^-%4ld", gxlWeight,gxlWeight_2);	
	else	
	sprintf(str, "%5ld$%5ld", gxlWeight,gxlWeight_2);
  GLCD_string (5,0 ,str);
	lcd_normal();
*/

//20171226
 if(sign&&!sign_2)
 {
	 if(gxlWeight>9900)
		 gxlWeight=9900;
	 sprintf(str, "-%4ld/%5ld", (long)gxlWeight,(long)gxlWeight_2);
 } 
  
	else if(!sign&&sign_2)
	{
   if(gxlWeight_2>9900)
		 gxlWeight_2=9900;
			
	sprintf(str, "%5ld/-%4ld", (long)gxlWeight,(long)gxlWeight_2);
  
	}	
	else if(sign&&sign_2)
  {		
	 if(gxlWeight>9900)
		 gxlWeight=9900;
	  if(gxlWeight_2>9900)
		 gxlWeight_2=9900;
	
	sprintf(str, "-%4ld/-%4ld", (long)gxlWeight,(long)gxlWeight_2);	
	
	}
 else if(!sign&&!sign_2)
	{
		sprintf(str, "%5ld/%5ld", gxlWeight,gxlWeight_2);
	
	}
	GLCD_string (5,0 ,str);
	
	lcd_normal();

 // sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	
	
	//ver3.0
	
	/*
	sprintf(str, "%5ld kg", gnlFeeding1); // ver 2.8  20220712
	GLCD_string (8,2 ,str);
	sprintf(str, "%5ld kg", gnlFeeding2);
	GLCD_string (8,4 ,str);
	*/
	
	
	
	
	if(gxlWeight>99999 || gxlWeight_2>99999)
 {
	   lcd_clear();
	    if(gnlLanguage==1)
      {				
	    GLCD_string (0,0 ,"���Լ��� ����!!");
	    GLCD_string (0,2 ,"��� ������ ����");
		  GLCD_string (0,4 ,"���Լ�����");
		  GLCD_string (0,6 ,"������ �ּ���!");
		  Gpi8510_Relay_On(ERROR);
      }
		 else
      {
        GLCD_string (0,0 ,"LOAD CELL ERROR!");
		    GLCD_string (0,2 ,"POWER OFF !");
		    GLCD_string (0,4 ,"CHECK");
		    GLCD_string (0,6 ,"LOAD CELL !");
		    Gpi8510_Relay_On(ERROR);
				
	    }	
			
	  while(1)
		{
     Delay_ms(10);			
			};	
 } // if(gxlWeight>99999)
	
	
	
	
	
	//lcd_inverse();
	/*
	 sum=gnlDailyTotal+gnlDailyTotal2;
	sprintf(str, "%5ld kg",sum);
	GLCD_string (8,6 ,str);
	lcd_normal();
	*/


	 
	/*  
	 sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 sprintf(str, "���̷�1 :%5ld", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "���̷�2 :%5ld", gnlDailyTotal2);
	 GLCD_string (0,4 ,str);
	 */
	 
	 /*
	 lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "�����հ�:%5ld",sum);
	 GLCD_string (0,6 ,str);
	 lcd_normal();
	 */
 }	 
}
 
//210402
	
//ver3.00
if (working_flag)	    //2020
		{
			SendtoPc();
			Silo_1_Led_Operation(); // 
   	
		//	lPulseMaxHoldCount++;
			if (250< Feeding_Counter1)	// 250 msec *10= 2.5�� ����  ���� 
			{
				Feeding_Counter1=0;
				USART1_puts("interval !");
				lPulseMaxHoldCount = 0;	
			if(!sign)
			{				
				if (gxlWeight < lPulseRef) // ��ᰡ ���������� ������ ������
				{
					if((lPulseRef-gxlWeight)<=100)	// �����Ѱ��� 100 kg �����϶��� ���⹫�Է� �޾Ƶ���  
					{							 		// 100 kg �̻�Ǹ�  ������� �Ǵ��ϰ� 
				  	 gnlDailyTotal += (lPulseRef - gxlWeight);//VER1.32	   critical; //start���� ���Կ� stop ���� ���ⷮ��� 
	           gnlFeeding1+= (lPulseRef - gxlWeight); //ver 2.8 20220712
					   lPulseWeigh += (lPulseRef - gxlWeight);
             lOutput += (lPulseRef - gxlWeight);//0105 
						lPulseRef = gxlWeight;
						lPulseMaxHold = gxlWeight;
						lPulseMaxHoldCount = 0;
					 UpperError_Weight+= (lPulseRef - gxlWeight); //20220126 ,���ѿ�������
					
      		if ((gxuOutputHighErrorWeigh <= UpperError_Weight)&&gxuOutputHighErrorWeigh!=0 &&!Output_High_Error )		//0105		
						
						{
             Gpi8510_Relay_Off(SILO_ONE);
				     //Gpi8510_Relay_On(ERROR);
				     Gpi8510_Relay_Off(ERROR);
				     
						 Output_High_Error=1;
				     Error_2_Led_Operation();
				     lcd_clear();
							if(gnlLanguage==1)
             {								
				     GLCD_string (0, 0,"���ѹ��� ����!");
				     GLCD_string (0, 2,"���,�������");
             GLCD_string (0, 4,"������ ������");
             GLCD_string (0, 6,"�ٽ� ���ּ���!");		
				      }
						 else						
						{							
				     GLCD_string (0, 0," HIGH RELEASE");
				     GLCD_string (0, 2,"ERROR !!");
             GLCD_string (0, 4,"CHECK   RELEASE");
             GLCD_string (0, 6,"MOTOR !!");		
				    } 
								
								Silo1_led_Off();
				     working_flag = 0;
				     ek_flag1=0;
				     goto stop_func;

            }

						if(gnlSilo1Selection==1)
						{	
					    lcd_inverse();
						  sprintf(str, " %5ld kg ", gnlFeeding1);   // ���̷� ǥ�� 20180627
              GLCD_string (6, 2, str);
							sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal);
            	GLCD_string (0,6 ,str);
		           lcd_normal();
					  }
           else if(gnlSilo1Selection==2)						
						{	
						   sprintf(str, "%5ld", gnlFeeding1);
	             GLCD_string (8, 2, str);
							 lcd_inverse();
					    sprintf(str, "�� ��: %5ld kg ", (gnlDailyTotal +gnlDailyTotal2));
		          GLCD_string (0,6 ,str); 
				      lcd_normal();
					  } 
					}
				}//  if (gxlWeight < lPulseRef) // ��ᰡ ���������� ������ ������
	     
				#ifdef dpfddpp
				
				if ((gxlWeight > lPulseRef)&&sign)//���� ���԰� �����̸鼭 ������ 
				{
					if((gxlWeight-lPulseRef)<=100)	// �����Ѱ��� 100 kg �����϶��� ���⹫�Է� �޾Ƶ���  
					{							 		// 100 kg �̻�Ǹ�  ������� �Ǵ��ϰ� 
					 //ver3.10  20241204
						gnlDailyTotal+=gxlWeight-lPulseRef;
    	  		
						//lPulseWeigh += (gxlWeight-lPulseRef);
            //lOutput += (lPulseRef - gxlWeight);//0105 
						
						lPulseRef = gxlWeight;
						lPulseMaxHold = gxlWeight;
						lPulseMaxHoldCount = 0;
						UpperError_Weight+= (lPulseRef - gxlWeight); 
						
						if ((gxuOutputHighErrorWeigh <= UpperError_Weight)&&gxuOutputHighErrorWeigh!=0 &&!Output_High_Error )		//0105		
					
        //    if ((gxuOutputHighErrorWeigh <= lOutput)&&gxuOutputHighErrorWeigh!=0 &&!Output_High_Error )		//0105		
						{
             Gpi8510_Relay_Off(SILO_ONE);
				     //Gpi8510_Relay_On(ERROR);
				     Gpi8510_Relay_Off(ERROR);
				     
						 Output_High_Error=1;
				     Error_2_Led_Operation();
				     lcd_clear();
							if(gnlLanguage==1)
							{	
				      GLCD_string (0, 0,"���ѹ��� ����!");
				      GLCD_string (0, 2,"���,�������");
              GLCD_string (0, 4,"������ ������");
              GLCD_string (0, 6,"�ٽ� ���ּ���!");		
							}
						else
						 {							 
						GLCD_string (0, 0," HIGH RELEASE");
				     GLCD_string (0, 2,"ERROR !!");
             GLCD_string (0, 4,"CHECK   RELEASE");
             GLCD_string (0, 6,"MOTOR !!");		
				     }	
							
								Silo1_led_Off();
				     working_flag = 0;
				     ek_flag1=0;
				     goto stop_func;

            }

				//ver 3p0		
						
					
						if(gnlSilo1Selection==1)
						{	
					    lcd_inverse();
						  sprintf(str, " %5ld kg ", gnlFeeding1);   // ���̷� ǥ�� 20180627
              GLCD_string (6, 2, str);
						  lcd_normal();
					  }
           
						
						
						/* 
						else if(gnlSilo1Selection==2)						
						{	
						lcd_inverse();
						sprintf(str, "%5ld", gnlFeeding2);
	          GLCD_string (9, 2, str);
						lcd_normal();
					  } 
					*/
					
					}
				}
				  // �����߿�
				if ((gxlWeight > lPulseRef)&&!sign)//���� ���԰� ����ε� �������� ������� ũ�� ->  ��Ḧ �װ��ִ°Ŷ� �Ǵ� 
				{
					
					 gnlDailyTotal-=gxlWeight-lPulseRef; // - �� ������ ǥ���Ѵ�. -> ���⵵�߿� ��Ḧ �ִ°��� ������
				   gnlFeeding1-= (gxlWeight-lPulseRef); //ver 2.8 20220712
    	  		
					lPulseRef = gxlWeight;
						lPulseMaxHold = gxlWeight;
						lPulseMaxHoldCount = 0;
					
					 
					
					
					if(gnlSilo1Selection==1)
						{	
					    lcd_inverse();
							//ver 3p0  
						  sprintf(str, " %5ld kg ", gnlFeeding1);   // ���̷� ǥ�� 20180627
              GLCD_string (6, 2, str);
							if(gnlLanguage==1)
							sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
							 else
				     sprintf(str, "TODAY: %5ld kg ", gnlDailyTotal); 
	      			 
	           GLCD_string (0, 6, str);
						
						  lcd_normal();
					  }
           else if(gnlSilo1Selection==2)						
						{	
						lcd_inverse();
						sprintf(str, "%5ld", gnlFeeding2);
	          GLCD_string (9, 2, str);
						lcd_normal();
					  } 
						
					}// of ���繫�԰� ����϶�	
				
					 #endif 
					
						
				} // of if(!sign)
				
	
			} // of 	if (250< Feeding_Counter1)	// 250 msec *10= 2.5�� ����  ���� 
		}//working flag	
	
	//2.2D, 20181023 ,������ ��û	
		if(gxuPulseSetWeigh)
    {			
		if (!bPulse)  // 1228 // �ѹ��� ���� �ɷ� 
			{
				if ((long)gxuPulseSetWeigh <= lPulseWeigh)
				{
					Pulse_timer=0; //10 msec timer
					lPulseWeigh -= (long)gxuPulseSetWeigh;
					bPulse = 1;   Gpi8510_Relay_On(PULSE); //relay_on(PULSE_R);
				}
			}
		
			if(Pulse_timer>=50) // 0.5�ʰ� ������ -> 0.5�ʵ��� �����̸� �Ѱ�
			{
				Gpi8510_Relay_Off(PULSE); // �����̸� off
				
			}	
			
			if(Pulse_timer>=100) // 0.5�ʰ� ������ -> 0.5�ʵ��� �����̸� �Ѱ�
			{
				bPulse = 0; 
				
			}	
		}		
			

/*

			else { bPulse = 0;  //relay_off(PULSE_R); }
				    Gpi8510_Relay_Off(PULSE);
				
			     }
				 }
		
*/		
		
		
		//250926
		

// gxuOutputErrorWeigh=100;	//20180104
 if (working_flag&& ek_flag1&&!Output_Low_Error&& gnlSilo1Selection==1)	//   silo�� 1���϶��� ���� 20171228
 	{
		//USART1_puts("1111111");
		if(Error_Sec_Counter>=60 && Error_Sec_Counter<=63) // �����ؼ� �� 1�������� �ð��� �������� 
		{
			// USART1_puts("2222222");
			 if (lRefWeigh-gxlWeight < (long)(gxuOutputErrorWeigh)&&(long)(gxuOutputErrorWeigh)!=0)
			 {
				 
				 
         Gpi8510_Relay_Off(SILO_ONE);
				 //Gpi8510_Relay_On(ERROR);
				 Gpi8510_Relay_Off(ERROR);
				     
				 Output_Low_Error=1;
				 Error_1_Led_Operation();
				 lcd_clear();
				 
				  if(gnlLanguage==1)
					{	
				 GLCD_string (0, 0,"���ѹ��� ����!");
				 GLCD_string (0, 2,"���,�������");
         GLCD_string (0, 4,"������ ������");
         GLCD_string (0, 6,"�ٽ� ���ּ���!");		
				  }
					 else
						 {							 
						GLCD_string (0, 0," LOW RELEASE");
				     GLCD_string (0, 2,"ERROR !!");
             GLCD_string (0, 4,"CHECK   RELEASE");
             GLCD_string (0, 6,"MOTOR !!");		
				     }
				 
				 
				 //GLCD_string (9, 2,"error");
				// Delay_ms(1000);
				 Silo1_led_Off();
				 //lcd_clear();
				 working_flag = 0;
				 ek_flag1=0;
				 goto stop_func;
       }				 
		}	
	}	
	if(Output_Low_Error==1) //  ���� ������ �߻�
	{ 
	  Error_1_Led_Operation();
  }
	
	if(Output_High_Error==1) // ���� ������ �߻�
	{ 
	  Error_2_Led_Operation();
  }
	
	
	
			if (working_flag_2 && gnlSilo1Selection==2)	// 0825
		{
			SendtoPc();
			
			Silo_2_Led_Operation(); // 
   	 
			lPulseMaxHoldCount2++;
			if (250 < Feeding_Counter2)	// 250 msec *10= 2.5�� ����  ���� 
			{
				//lPulseMaxHoldCount2 = 0;	
				
				Feeding_Counter2=0;
				if (gxlGrossWeight_2 < lPulseRef2) //�������� �����̸�
				{
					if((lPulseRef2-gxlWeight_2)<=100)	// �����Ѱ��� 100 kg �����϶��� ���⹫�Է� �޾Ƶ���  
					{							 		// 100 kg �̻�Ǹ�  ������� �Ǵ��ϰ� 
						gnlDailyTotal2 += (lPulseRef2 - gxlWeight_2);//VER1.32	   critical 
						
						lPulseWeigh2 += (lPulseRef2 - gxlWeight_2);
						gnlFeeding2+= (lPulseRef2 - gxlWeight_2); // ver 2.8
						lPulseRef2 = gxlWeight_2;
						lPulseMaxHold2 = gxlWeight_2;
						lPulseMaxHoldCount = 0;
	        //  lcd_inverse();
					
            
					}
				}
				/*
				else //�ð��� ������ ���簪�� ���������� ũ��  -> ä�͸���
					{
					
					 gnlDailyTotal2-=gxlWeight_2-lPulseRef2; // - �� ������ ǥ���Ѵ�. -> ���⵵�߿� ��Ḧ �ִ°��� ������
				   gnlFeeding2-= (gxlWeight_2-lPulseRef2); //ver 2.8 20220712
    	  	 lPulseRef2 = gxlWeight_2;
					 lPulseMaxHold2 = gxlWeight_2;
					 lPulseMaxHoldCount2 = 0;
					}
				*/
				   sprintf(str, "%5ld", gnlFeeding2);  //Delay_ms(1000);    
					 GLCD_string (8, 4, str);
					 lcd_inverse();
					 sprintf(str, "�� ��: %5ld kg ", (gnlDailyTotal +gnlDailyTotal2));
			     GLCD_string (0,6 ,str); 
				   lcd_normal();
					
				
		
	if(gxuPulseSetWeigh)
	{		
		if (!bPulse2)  // 1228
			{
				if ((long)gxuPulseSetWeigh <= lPulseWeigh2)
				{
					lPulseWeigh2 -= (long)gxuPulseSetWeigh;
					bPulse2 = 1;   Gpi8510_Relay_On(PULSE); //relay_on(PULSE_R);
				}
			}
			else { bPulse2 = 0;  //relay_off(PULSE_R); }
				    Gpi8510_Relay_Off(PULSE);
			     }
				 }	
			}  // of if (250 < Feeding_Counter2)	// 250 msec *10= 2.5�� ����  ���� 
		}//working flag	
	
	
	
	/*
	
	#ifdef  dfdfdfd
	
		//if(gnlSilo1Selection==1)//20220713

		if (working_flag_2 && gnlSilo1Selection==2)	// 0825
		{
			SendtoPc();
			
			Silo_2_Led_Operation(); // 
   	 
			lPulseMaxHoldCount2++;
			if (250 < Feeding_Counter2)	// 250 msec *10= 2.5�� ����  ���� 
			{
				//lPulseMaxHoldCount2 = 0;	
				
				Feeding_Counter2=0;
				if (gxlGrossWeight_2 < lPulseRef2)
				{
					if((lPulseRef2-gxlWeight_2)<=100)	// �����Ѱ��� 100 kg �����϶��� ���⹫�Է� �޾Ƶ���  
					{							 		// 100 kg �̻�Ǹ�  ������� �Ǵ��ϰ� 
						gnlDailyTotal2 += (lPulseRef2 - gxlWeight_2);//VER1.32	   critical 
						
						lPulseWeigh2 += (lPulseRef2 - gxlWeight_2);
						gnlFeeding2+= (lPulseRef2 - gxlWeight_2); // ver 2.8
						lPulseRef2 = gxlWeight_2;
						lPulseMaxHold2 = gxlWeight_2;
						lPulseMaxHoldCount = 0;
	        //  lcd_inverse();
					
            sprintf(str, "%5ld", gnlFeeding2);  //Delay_ms(1000);    
						 GLCD_string (9, 4, str);
					   
						//sprintf(str, "gnlFeeding2=%5ld", gnlFeeding2); USART1_puts(str);
						//sprintf(str, "gnlFeeding2=%5ld", gnlFeeding2); USART1_puts(str);
						 //sprintf(str, "gnlFeeding2=%5ld", gnlFeeding2); USART1_puts(str);
						 //sprintf(str, "gnlDailyTotal2=%5ld", gnlDailyTotal2); USART1_puts(str);
					
					}
				}
		
	if(gxuPulseSetWeigh)
	{		
		if (!bPulse2)  // 1228
			{
				if ((long)gxuPulseSetWeigh <= lPulseWeigh2)
				{
					lPulseWeigh2 -= (long)gxuPulseSetWeigh;
					bPulse2 = 1;   Gpi8510_Relay_On(PULSE); //relay_on(PULSE_R);
				}
			}
			else { bPulse2 = 0;  //relay_off(PULSE_R); }
				    Gpi8510_Relay_Off(PULSE);
			     }
				 }	
			
			
			}
		}//working flag	
#endif

*/

		/*		
	if (working_flag_2&& ek_flag2&&!Output_Low_Error2)	// 20171228
 	{
		if(Error_Sec_Counter2>=60 && Error_Sec_Counter2<=63) // �����ؼ� �� 1�������� �ð��� �������� 
		{
			 if (lRefWeigh2-gxlGrossWeight_2 < (long)(gxuOutputErrorWeigh)&&(long)(gxuOutputErrorWeigh)!=0)
			 {
         Gpi8510_Relay_Off(SILO_TWO);
				 Gpi8510_Relay_On(ERROR);
				 Output_Low_Error2=1;
				 Error_2_Led_Operation();
				 lcd_clear();
				 GLCD_string (0, 0,"���ѹ���_2����!");
				 GLCD_string (0, 2,"���,�������");
         GLCD_string (0, 4,"������ ������");
         GLCD_string (0, 6,"�ٽ� ���ּ���!");		
				 //GLCD_string (9, 2,"error");
				// Delay_ms(1000);
				 Silo2_led_Off();
				 //lcd_clear();
				 working_flag_2 = 0;
				 ek_flag2=0;
				 goto stop_func;
       }				 
		}	
	}	
	if(Output_Low_Error2==1) // ������ �߻�
	{ 
	  Error_2_Led_Operation();
  }			
		
 */













		
/*************zero fucntion ****************************/
  	LEFT_ARROW_ON	 //0918
		{
			Zero_Mili_Counter=0;
		  beep(50);
     while(1)
		 {
			 
			 LEFT_ARROW_ON	
			{
			 //  Making_zero_timer++;
			if(Zero_Mili_Counter>(DEF_1_SEC*3))
			{
        //Making_zero_timer=0;
			  Zero_Mili_Counter=0;
				beep(500);
				zero_func();
				break;
			}
		}
				else
				{
					Zero_Mili_Counter=0;
					break;
				}
			}; // of while 	 
    } // of LEFT_ARROW_ON	
/*************zero fucntion ****************************/
		
//RIGHT_ARROW_ON  1211

if(gnlSilo1Selection==2)
{	
	RIGHT_ARROW_ON	 //0918
		{
			Zero_Mili_Counter=0;
			beep(50);
		 while(1)
		 {
 RIGHT_ARROW_ON
			{
			 //  Making_zero_timer++;
			if(Zero_Mili_Counter>(DEF_1_SEC*3))
			{
        //Making_zero_timer=0;
			  Zero_Mili_Counter=0;
				beep(500);
				zero_func2();
				break;
			}
		}
				else
				{
					Zero_Mili_Counter=0;
					break;
				}
			}; // of while 	 
    }		
	}	
		
		
		
		if (keypush_8510()) // 0830
		{
			 //ch=key_disp[KEYCODE];   //0829
			/*
			 if(KeyCode==LEFT)
			 {
				 Making_zero_timer++;
			
			sprintf(str, " %5ld ", Making_zero_timer); 
      GLCD_string (0, 4, str);
			*/			
			
			
				 
			
			
			switch(KeyCode)
			{/* 
				case RIGHT:
					Delay_ms(1);
				 //goto DATE_CHANGE;
				break;
				*/
				case UP:
					
				 	which_day_feeding++;
				if(which_day_feeding>8) // ������ 7, VER 2.5 : 8, �Ѵ��� ���ⷮ ǥ���ϱ����Ͽ�
					{
						// retry_message();
						which_day_feeding=0;
					}	
			
      	
				if(gnlSilo1Selection==1)// silo 1 enable )// silo 1 enable
				{
					 if(gnlLanguage==1)// korean
           { 	
             switch(which_day_feeding)
						 {
					     case 0:
							 sprintf(str, "�� ��: %5ld kg ",(int)gnlDailyTotal);
               break;
						   case 1:
							 sprintf(str, "1����: %5ld kg ",(int)gnlPreDailyTotal[0]);
               break;
							 case 2:
							 sprintf(str, "2����: %5ld kg ",(int)gnlPreDailyTotal[1]);
               break;
						   case 3:
							 sprintf(str, "3����: %5ld kg ",(int)gnlPreDailyTotal[2]);
               break;
						   case 4:
							 sprintf(str, "4����: %5ld kg ",(int)gnlPreDailyTotal[3]);
               break;
						   case 5:
							 sprintf(str, "5����: %5ld kg ",(int)gnlPreDailyTotal[4]);
               break;
						   case 6:
							 sprintf(str, "6����: %5ld kg ",(int)gnlPreDailyTotal[5]);
               break;
						   case 7:
							 sprintf(str, "7����: %5ld kg ",(int)gnlPreDailyTotal[6]);
               break;
	            case 8:
							 sprintf(str, "�Ѵ���: %5ld kg",(int)gxhTotalOutput);
               break;
													

							 default: break;
						 
						 } //of switch
           }


					 else// ENGLISH
					 { 
              switch(which_day_feeding)
						 {
					     case 0:
							 sprintf(str, "TODAY: %5ld kg ",(int)gnlDailyTotal);
               break;
						   case 1:
							 sprintf(str, "DAY-1: %5ld kg ",(int)gnlPreDailyTotal[0]);
               break;
							 case 2:
							 sprintf(str, "DAY-2: %5ld kg ",(int)gnlPreDailyTotal[1]);
               break;
						   case 3:
							 sprintf(str, "DAY-3: %5ld kg ",(int)gnlPreDailyTotal[2]);
               break;
						   case 4:
							 sprintf(str, "DAY-4: %5ld kg ",(int)gnlPreDailyTotal[3]);
               break;
						   case 5:
							 sprintf(str, "DAY-5: %5ld kg ",(int)gnlPreDailyTotal[4]);
               break;
						   case 6:
							 sprintf(str, "DAY-6: %5ld kg ",(int)gnlPreDailyTotal[5]);
               break;
						   case 7:
							 sprintf(str, "DAY-7: %5ld kg ",(int)gnlPreDailyTotal[6]);
               break;
							 case 8:
							 sprintf(str, "TOTAL: %5ld kg ",(int)gxhTotalOutput);
               break;
							 default: break;
						 } //of switch

					 }		 
						 
				 lcd_inverse(); 
				 GLCD_string (0,6 ,str);
				 lcd_normal();  
				}	// if(gnlSilo1Selection==1)// ONLY  SILO 
        else //silo 2 ea   //0331
					{
					 if(gnlLanguage==1)// korean
           { 	
             switch(which_day_feeding)
						 {
					     case 0:
								sum= gnlDailyTotal+gnlDailyTotal2;
							 sprintf(str, "�� ��:  %5ld kg",(int)sum);
               break;
						   case 1:
								sum= gnlPreDailyTotal[0]+gnlPreDailyTotal2[0];
							 sprintf(str, "1����:  %5ld kg",(int)sum);
               break;
							 case 2:
								 sum= gnlPreDailyTotal[1]+gnlPreDailyTotal2[1];
							 sprintf(str, "2����:  %5ld kg",(int)sum);
               break;
						   case 3:
								 sum= gnlPreDailyTotal[2]+gnlPreDailyTotal2[2];
							 sprintf(str, "3����:  %5ld kg",(int)sum);
               break;
						   case 4:
								 sum= gnlPreDailyTotal[3]+gnlPreDailyTotal2[3];
							 sprintf(str, "4����:  %5ld kg",(int)sum);
               break;
						   case 5:
								 sum= gnlPreDailyTotal[4]+gnlPreDailyTotal2[4];
							 sprintf(str, "5����:  %5ld kg",(int)sum);
               break;
						   case 6:
								 sum= gnlPreDailyTotal[5]+gnlPreDailyTotal2[5];
							 sprintf(str, "6����:  %5ld kg",(int)sum);
               break;
						   case 7:
								 sum= gnlPreDailyTotal[6]+gnlPreDailyTotal2[6];
							 sprintf(str, "7����:  %5ld kg",(int)sum);
               break;
							 case 8:
							 sprintf(str, "�Ѵ���: %5ld kg",(int)gxhTotalOutput);
               break;
               default: break;
						 } //of switch
           }
					 else// ENGLISH
					 { 
              switch(which_day_feeding)
						 {
					     case 0:
								 sum= gnlDailyTotal+gnlDailyTotal2;
							 sprintf(str, "TODAY: %5ld kg ",(int)gnlDailyTotal);
               break;
						   case 1:
								 sum= gnlPreDailyTotal[0]+gnlPreDailyTotal2[0];
							 sprintf(str, "DAY-1: %5ld kg ",(int)gnlPreDailyTotal[0]);
               break;
							 case 2:
								 sum= gnlPreDailyTotal[1]+gnlPreDailyTotal2[1];
							 sprintf(str, "DAY-2: %5ld kg ",(int)gnlPreDailyTotal[1]);
               break;
						   case 3:
								 sum= gnlPreDailyTotal[2]+gnlPreDailyTotal2[2];
							 sprintf(str, "DAY-3: %5ld kg ",(int)gnlPreDailyTotal[2]);
               break;
						   case 4:
								 sum= gnlPreDailyTotal[3]+gnlPreDailyTotal2[3];
							 sprintf(str, "DAY-4: %5ld kg ",(int)gnlPreDailyTotal[3]);
               break;
						   case 5:
								 sum= gnlPreDailyTotal[4]+gnlPreDailyTotal2[4];
							 sprintf(str, "DAY-5: %5ld kg ",(int)gnlPreDailyTotal[4]);
               break;
						   case 6:
								 sum= gnlPreDailyTotal[5]+gnlPreDailyTotal2[5];
							 sprintf(str, "DAY-6: %5ld kg ",(int)gnlPreDailyTotal[5]);
               break;
						   case 7:
								 sum= gnlPreDailyTotal[6]+gnlPreDailyTotal2[6];
							 sprintf(str, "DAY-7: %5ld kg ",(int)gnlPreDailyTotal[6]);
               break;
							 case 8:
							 sprintf(str, "TOTAL: %5ld kg",(int)gxhTotalOutput);
               break;
							 default: break;
						 } //of switch

					 }//silo 2 ea		 
						 
				 lcd_inverse(); 
				 GLCD_string (0,6 ,str);
				 lcd_normal();  
				}
         
				/*
				which_day_feeding++;
				 if(which_day_feeding>7)
					{
						 retry_message();
						which_day_feeding=7;
					}	
				*/  
					break;
				
				case DOWN:
					
				 which_day_feeding--;
				if(which_day_feeding<0)
					{
						// retry_message();
						which_day_feeding=8;
						break;
					}
				
  	  		
				if(gnlSilo1Selection==1)// silo 1 enable )// silo 1 enable
 				{
				if(gnlLanguage==1)// korean	
				{
		       switch(which_day_feeding) //1226
						 {
					     case 0:
							 sprintf(str, "�� ��: %5ld kg ",(int)gnlDailyTotal);
               break;
						   case 1:
							 sprintf(str, "1����: %5ld kg ",(int)gnlPreDailyTotal[0]);
               break;
							 case 2:
							 sprintf(str, "2����: %5ld kg ",(int)gnlPreDailyTotal[1]);
               break;
						   case 3:
							 sprintf(str, "3����: %5ld kg ",(int)gnlPreDailyTotal[2]);
               break;
						   case 4:
							 sprintf(str, "4����: %5ld kg ",(int)gnlPreDailyTotal[3]);
               break;
						   case 5:
							 sprintf(str, "5����: %5ld kg ",(int)gnlPreDailyTotal[4]);
               break;
						   case 6:
							 sprintf(str, "6����: %5ld kg ",(int)gnlPreDailyTotal[5]);
               break;
						   case 7:
							 sprintf(str, "7����: %5ld kg ",(int)gnlPreDailyTotal[6]);
               break;
							 case 8:
							 sprintf(str, "�Ѵ���: %5ld kg",(int)gxhTotalOutput);
               break;
							 default: break;
						 
						 
						 } //of switch

				
					 }
				
				else
        {	
         switch(which_day_feeding)
						 {
					     case 0:
							 sprintf(str, "TODAY: %5ld kg ",(int)gnlDailyTotal);
               break;
						   case 1:
							 sprintf(str, "DAY-1: %5ld kg ",(int)gnlPreDailyTotal[0]);
               break;
							 case 2:
							 sprintf(str, "DAY-2: %5ld kg ",(int)gnlPreDailyTotal[1]);
               break;
						   case 3:
							 sprintf(str, "DAY-3: %5ld kg ",(int)gnlPreDailyTotal[2]);
               break;
						   case 4:
							 sprintf(str, "DAY-4: %5ld kg ",(int)gnlPreDailyTotal[3]);
               break;
						   case 5:
							 sprintf(str, "DAY-5: %5ld kg ",(int)gnlPreDailyTotal[4]);
               break;
						   case 6:
							 sprintf(str, "DAY-6: %5ld kg ",(int)gnlPreDailyTotal[5]);
               break;
						   case 7:
							 sprintf(str, "DAY-7: %5ld kg ",(int)gnlPreDailyTotal[6]);
               break;
							 case 8:
							 sprintf(str, "TOTAL: %5ld kg",(int)gxhTotalOutput);
               break;
							 default: break;
						 } //of switch
				}		
	  		 lcd_inverse(); 
				 GLCD_string (0,6 ,str);
				 lcd_normal();
	  		}	//if(gnlSilo1Selection==1)// silo 1 enable )// silo 1 enable
 		  else// SILO SELECTION ==2
				{
				if(gnlLanguage==1)// korean	
				{
		       switch(which_day_feeding)
						 {
					     case 0:
								sum= gnlDailyTotal+gnlDailyTotal2;
							 sprintf(str, "�� ��:  %5ld kg",(int)sum);
               break;
						   case 1:
								sum= gnlPreDailyTotal[0]+gnlPreDailyTotal2[0];
							 sprintf(str, "1����:  %5ld kg",(int)sum);
               break;
							 case 2:
								 sum= gnlPreDailyTotal[1]+gnlPreDailyTotal2[1];
							 sprintf(str, "2����:  %5ld kg",(int)sum);
               break;
						   case 3:
								 sum= gnlPreDailyTotal[2]+gnlPreDailyTotal2[2];
							 sprintf(str, "3����:  %5ld kg",(int)sum);
               break;
						   case 4:
								 sum= gnlPreDailyTotal[3]+gnlPreDailyTotal2[3];
							 sprintf(str, "4����:  %5ld kg",(int)sum);
               break;
						   case 5:
								 sum= gnlPreDailyTotal[4]+gnlPreDailyTotal2[4];
							 sprintf(str, "5����:  %5ld kg",(int)sum);
               break;
						   case 6:
								 sum= gnlPreDailyTotal[5]+gnlPreDailyTotal2[5];
							 sprintf(str, "6����:  %5ld kg",(int)sum);
               break;
						   case 7:
								 sum= gnlPreDailyTotal[6]+gnlPreDailyTotal2[6];
							 sprintf(str, "7���� : %5ld kg",(int)sum);
               break;
							 case 8:
							 sprintf(str, "�Ѵ���: %5ld kg",(int)gxhTotalOutput);
               break;
              
							 default: break;
						 
						 } //of switch
				
					 }
				
				else
        {	
         switch(which_day_feeding)
						 {
					    case 0:
								 sum= gnlDailyTotal+gnlDailyTotal2;
							 sprintf(str, "TODAY: %5ld kg ",(int)gnlDailyTotal);
               break;
						   case 1:
								 sum= gnlPreDailyTotal[0]+gnlPreDailyTotal2[0];
							 sprintf(str, "DAY-1: %5ld kg ",(int)gnlPreDailyTotal[0]);
               break;
							 case 2:
								 sum= gnlPreDailyTotal[1]+gnlPreDailyTotal2[1];
							 sprintf(str, "DAY-2: %5ld kg ",(int)gnlPreDailyTotal[1]);
               break;
						   case 3:
								 sum= gnlPreDailyTotal[2]+gnlPreDailyTotal2[2];
							 sprintf(str, "DAY-3: %5ld kg ",(int)gnlPreDailyTotal[2]);
               break;
						   case 4:
								 sum= gnlPreDailyTotal[3]+gnlPreDailyTotal2[3];
							 sprintf(str, "DAY-4: %5ld kg ",(int)gnlPreDailyTotal[3]);
               break;
						   case 5:
								 sum= gnlPreDailyTotal[4]+gnlPreDailyTotal2[4];
							 sprintf(str, "DAY-5: %5ld kg ",(int)gnlPreDailyTotal[4]);
               break;
						   case 6:
								 sum= gnlPreDailyTotal[5]+gnlPreDailyTotal2[5];
							 sprintf(str, "DAY-6: %5ld kg ",(int)gnlPreDailyTotal[5]);
               break;
						   case 7:
								 sum= gnlPreDailyTotal[6]+gnlPreDailyTotal2[6];
							 sprintf(str, "DAY-7: %5ld kg ",(int)gnlPreDailyTotal[6]);
               break;
							 case 8:
							 sprintf(str, "TOTAL: %5ld kg",(int)gxhTotalOutput);
               break;
							 default: break;
						 } //of switch
				  }		
	  		 lcd_inverse(); 
				 GLCD_string (0,6 ,str);
				 lcd_normal();
	  		}
					break;
  
				case KEY_WEIGHT: //���繫��Ű 
					
				
			
///LCD_restart();	// 2017.07.19 test only
				
					/*
					Initiaize_eeprom();
					FSMC_DISABLE;	 //1126
					kwak.dw=gnlDailyTotal;
					I2C_EE_BufferWrite(kwak.c, ADR_gnlDailyTotal, 4);
					I2C_EE_BufferRead( kwak.c,ADR_gnlDailyTotal , 4);
					FSMC_ENABLE;
					*/				
					//read_factors();
					//write_factors();
					
INITIAL:
				///	lcd70_clear_screen(WHITE);
				
				///	lcd70_draw_rectangle(450, 130, 700, 230,BLUE);//���ù��ⷮ INNER BOX �׸���  
			///		lcd70_show_string_mode(500, 135,"TODAY OUTPUT", 16, 0);
			///		lcd70_draw_rectangle(445, 125, 705, 235,BLUE);//���ù��ⷮ OUTER BOX �׸��� 
			///		lcd70_draw_rectangle(95, 130, 350, 230,BLUE);//���繫�� INNNER BOX
			///		lcd70_draw_rectangle(90, 125, 355, 235,RED);  //���繫��  OUTER BOX  // 2015�� 1��6��
			///		lcd70_show_string_mode(150, 135,"CURRENT WEIGHT", 16, 0);
					
			/*		if(working_flag )
						lcd70_draw_demo_bin(start_lamp.pixel_data,550,400,start_lamp.width+550,start_lamp.height+400);// RED ǥ�ú� �׸��� 
					else
						lcd70_draw_demo_bin(stop_lamp.pixel_data,550,400,stop_lamp.width+550,stop_lamp.height+400);// RED ǥ�ú� �׸��� 
					
					Current_Display=NORMAL_DISPLAY;
			*/
					break;

				case KEY_RECORD:		  //1126	   1127
//					lcd70_clear_screen(WHITE);
					//gnlPreDailyTotal[0]=gnlDailyTotal;
					/*
					lcd43_show_big_num(250,40,0);
					lcd43_show_big_num(280,40,':');
					
					
					lcd70_write_weight(300,40,gnlDailyTotal);
					*/
					gnlPreDailyTotal[0]=gnlDailyTotal;
					for(i=0;i<7;i++)
					{ 
					 Delay_ms(10);
					///	lcd43_show_big_num(250,40+(i*60),i);
					///	lcd43_show_big_num(280,40+(i*60),':');
					///	lcd70_write_weight(300,40+(i*60),gnlPreDailyTotal[i]);// ������ ���ⷮ ������ 
					}
					Delay_ms(5000);

					goto 	INITIAL;

//					break;

start_func:   //0908
					
					if(ek_flag1==1)  // silo 1
					stop_flag = 0; 
					else                 // silo2
						stop_flag2 = 0;
					
					if (!working_flag &&ek_flag1 )
					{
						if (!byNewStart)	//ver 1.34 if new start
						{
							Error_Sec_Counter=0; //20180104   output low error TIME Initialize
							baichul_start_flag = 1;
              /*
							lPulseRef = gxlGrossWeight;
							lRefWeigh = gxlGrossWeight; // 
							lDay_Ref_Weight=gxlGrossWeight; // 2011 12/24  ver 3.04 		critical
							Start_Weight=gxlGrossWeight; //  
							*/
							// ver 1.1
							lPulseRef = gxlWeight;
							lRefWeigh = gxlWeight;
							lDay_Ref_Weight=gxlWeight; // 2011 12/24  ver 3.04 		critical
							Start_Weight=gxlWeight; //  
							TodayTotalref= gnlDailyTotal; // ���������� ���� ���ⷮ�� �����ϰ�  
							
							//20220121
							UpperError_Weight=0;
							
						//	gnlFeeding1=0;
							
							
							
						}
		       	gnlFeeding1=0; //ver 2.8
					  lcd_inverse();
						if(gnlSilo1Selection==1)
						{
						  sprintf(str, "�� ��: %5ld kg ", gnlFeeding1);
						  GLCD_string (0,2 ,str);
						}
						else //  2���϶�
						{	
							lcd_normal();
						  sprintf(str, "���̷�1:%5ld kg", gnlFeeding1);
	            GLCD_string (0,2 ,str);
	           
						}
					//		sprintf(str, "���̷�2:%5ld kg", gnlFeeding2);
	         //  GLCD_string (0,4 ,str);
	
						
						lcd_normal();
						/*
						lcd_inverse();
						
						sprintf(str, "�� ��: %5ld kg ", gnlFeeding1);
						lcd_normal();
						GLCD_string (0,2 ,str);
						*/
						working_flag = 1;
						//bachul_send_timer_ms = 10;	//���۽� ���� ���� ����	2016.4.5
						bachul_send_timer_ms = WORKING_SEND_INTERVAL;	//������  ���� ���� �ð� �ʱ�ȭ
					//bErrorCheck = 1;
						//bStartOn = TRUE;
						//bReStart = FALSE;
					} // !working_flag
					
					if (!working_flag_2&& ek_flag2)
					{
						if (!byNewStart2)	//ver 1.34 if new start
						{
							baichul_start_flag2 = 1;
              /*
							lPulseRef2 = gxlGrossWeight_2;
							lRefWeigh2 = gxlGrossWeight_2;
							lDay_Ref_Weight2=gxlGrossWeight_2; // 2011 12/24  ver 3.04 		critical
							Start_Weight2=gxlGrossWeight_2; //  
							 */
							//ver 1.1  20180212
							lPulseRef2 = gxlWeight_2;
							lRefWeigh2 = gxlWeight_2;
							lDay_Ref_Weight2=gxlWeight_2; // 2011 12/24  ver 3.04 		critical
							Start_Weight2=gxlWeight_2; //  
					
							
							TodayTotalref2= gnlDailyTotal2; // ���������� ���� ���ⷮ�� �����ϰ�  
							
							//gnlFeeding2=0;
							
						}
          //0713		       
						if(gnlSilo1Selection==2)
					 { 
					 
						 gnlFeeding2=0;
					   sprintf(str, "���̷�2:%5ld kg", gnlFeeding2);
	           GLCD_string (0,4 ,str);
	         
						  sprintf(str, "start_gnlFeeding2=%5ld", gnlFeeding2); USART1_puts(str);
						  sprintf(str, "start_lPulseRef2=%5ld", lPulseRef2); USART1_puts(str);
						  sprintf(str, "start_gxlWeight_2=%5ld", gxlWeight_2); USART1_puts(str);
						 
						 
						 
						 
					 }
						
						working_flag_2 = 1;
						//bachul_send_timer_ms = 10;	//���۽� ���� ���� ����	2016.4.5
						bachul_send_timer_ms = WORKING_SEND_INTERVAL;	//������  ���� ���� �ð� �ʱ�ȭ
					//bErrorCheck = 1;
						//bStartOn = TRUE;
						//bReStart = FALSE;
					} // !working_flag
					
					
					
					break;
					
stop_func:   //20171020
			

      if(stop_flag) // silo1
			{
					working_flag = FALSE;
					Silo1_led_Off();
					stop_flag = 0;  // ���� 
					baichul_start_flag = 0;	//���� �÷���
  			  TodayTotalref_result=gnlDailyTotal;	 // stop func  
				
				 //ver 2.6
				 Stop_Weight=gxlWeight;
				 Output_total=Start_Weight-Stop_Weight;
				
				if(Output_total>0)
				{
					gxhTotalOutput+=Output_total;
					gxhTotalOutput = EE_Write_val(ADR_gxhTotalOutput, gxhTotalOutput, 4); 
				}
				
				
				//ver 2.8
				//gnlFeeding1
				gnlFeeding1 = EE_Write_val(ADR_gnlFeeding1, gnlFeeding1, 4); Delay_ms(100);
				gnlFeeding2 = EE_Write_val(ADR_gnlFeeding2, gnlFeeding2, 4); Delay_ms(100);
				
				
      // if(TodayTotalref_result>=0 && TodayTotalref_result<15000)  // 				
       if( TodayTotalref_result<15000)  // - ���� �����ؾ��Ѵ�. 				
    		 {
            sprintf(str, "silo1  cuttrent feeeding quantity eeprom  save start !");	USART1_puts(str);
						gnlDailyTotal = EE_Write_val(ADR_gnlDailyTotal, TodayTotalref_result, 4); Delay_ms(100);
					 //// gnlDailyTotal = EE_Write_val(ADR_gnlPreDailyTotal_0, TodayTotalref_result, 4); Delay_ms(100);
		      
					if(gnlSilo1Selection==1)// only silo number is 1 ea
          {						
					 if(gnlLanguage==1)// korean
						 //sprintf(str, "�� ��   : %5ld kg", gnlDailyTotal);
					   { sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal);}
					 

						 // sprintf(str, "�� ��: %5ld kg ",(int)gnlDailyTotal);
					   else 
					   sprintf(str, "TODAY: %5ld kg", gnlDailyTotal);
					  lcd_inverse(); 
				    {
						 GLCD_string (0,6 ,str);
				     Delay_ms(3000);
						} 
						 
						 lcd_normal();
					 }
					else if(gnlSilo1Selection==2)
					{
						sum=0;
						lcd_inverse();
	          sum=gnlDailyTotal+gnlDailyTotal2;
						 sprintf(str, "�� ��: %5ld kg",sum);
	         // sprintf(str, "�����հ�:%5ld",sum);
	          GLCD_string (0,6 ,str);
	          lcd_normal();
					}		
					 

					 sprintf(str, "silo1  cuttrent feeeding quantity eeprom  save end !");	USART1_puts(str);
					 
					
								    
								 
				 }
					baichul_end_flag = 1;


					    sprintf(str, "TodayTotalref=%6lu ",(long)TodayTotalref_result);
							sprintf(str, "Stop_Weight : %d", Stop_Weight);	USART1_puts(str);
		          sprintf(str, "Start_Weight : %d", Start_Weight);	USART1_puts(str);
              sprintf(str, "gxlGrossWeight : %d", gxlGrossWeight);	USART1_puts(str);
		          sprintf(str, "Start_Weight : %d", Start_Weight);	USART1_puts(str);
               sprintf(str, "TodayTotalref : %d", TodayTotalref);	USART1_puts(str);
		          sprintf(str, "gnlDailyTotal : %d", gnlDailyTotal);	USART1_puts(str);
					
			}	
      else if(stop_flag2) //20171020
		 	{
					working_flag_2 = FALSE;
					Silo2_led_Off();
					stop_flag2 = 0;  // ���� 
					baichul_start_flag2 = 0;	//���� �÷���
				
				
				
				 Stop_Weight2=gxlWeight_2;
				 Output_total2=Start_Weight2-Stop_Weight2;
				
				if(Output_total2>0)
				{
					gxhTotalOutput+=Output_total2;
					gxhTotalOutput = EE_Write_val(ADR_gxhTotalOutput, gxhTotalOutput, 4); 
				}
			
				
				
				
				
				
       /*					
				   if(!sign_2)
				 Stop_Weight2=Start_Weight2-gxlWeight_2; //start���� ���Կ� stop ���� ���ⷮ��� 
				 else
				 {	 
				 if(start_sign_flag_2)// �����Ҷ� ���԰��� - ������
					Stop_Weight2=gxlWeight_2-Start_Weight2; 
				 else
				 Stop_Weight2=Start_Weight2+gxlWeight_2; //start���� ���Կ� stop ���� ���ⷮ��� 
				 
				 }				
		   */
				// TodayTotalref_result2=TodayTotalref2+Stop_Weight2;	 // stop func
				
				TodayTotalref_result2=gnlDailyTotal2;//TodayTotalref2+Stop_Weight2;	 // stop func
				

				 if(TodayTotalref_result2>=0 &&TodayTotalref_result2<9000 )
				 {	
					  
						gnlDailyTotal2 = EE_Write_val(ADR_gnlDailyTotal2, TodayTotalref_result2, 4); Delay_ms(200);
						
					 lcd_inverse();
	         sum=gnlDailyTotal+gnlDailyTotal2;
	        sprintf(str, "�� ��: %5ld kg",sum);
	       GLCD_string (0,6 ,str);
	       lcd_normal();
	

					 }
						sprintf(str, "TodayTotalref=%6lu ",(long)TodayTotalref_result2);
					 baichul_end_flag2 = 1;

					sprintf(str, "%ld", Stop_Weight2);	USART1_puts(str);
					sprintf(str, "%ld", gnlDailyTotal2);	USART1_puts(str);
					Delay_ms(100);
					Silo2_led_Off();
				  Delay_ms(200);
					Silo2_led_On();
	       	Delay_ms(200);
					Silo2_led_Off();
			}	
	
   #ifdef dfpdfpdpf 

			TodayTotalref_result=TodayTotalref+Stop_Weight;	 // stop func 
					// if(abs(TodayTotalref_result-gnlDailyTotal)<=5*v_division) // �ǽð� ������ �Ѳ����� ������ 
					          // ���밪�� 5 ���� ���Ϸ� ����  
					{	
						// stop ���� �Ѳ����� ������ ���� 
						gnlDailyTotal = EE_Write_val(ADR_gnlDailyTotal, TodayTotalref_result, 4);
						
						//lcd70_write_weight(500,150,gnlDailyTotal);// ������ ���ⷮ ������ 
					}

					if(gnlDisplay)
					{
						//lcd70_write_weight(500,300,gnlDailyTotal);// ������ ���ⷮ ������ 
						sprintf(str, "TodayTotalref=%6lu ",(long)TodayTotalref_result);
						//lcd70_show_string_mode(500, 370,str, 16, 0);
					}
					
					//NoiseCount = 0;
					//NoiseFactor = 0;
					//NoiseWeightGo = 0;
					//NoiseWeight = 0;
					//NoiseLast = 0;
					//	signal_flag=0;
					//						vputs("333333");delay(100);
					// ver 1.32				nv_wei_No++;	// ver 1.20
					// VER 1.32				gnlPreOutput = lOutput; //ver 1.30
					//						relay_off(END_R);
					//relay_off(LOSS_R); //  LAMPUP = 1;
					//	LcdUpdate();
					//	bErrorCheck = 0;
					//	ErrorMinute = 60;	// ver 1.28
					//ErrorSecond = 60;	// ver 1.28
					//lcd70_draw_demo_bin(stop_lamp.pixel_data,550,400,stop_lamp.width+550,stop_lamp.height+400);	//  GREEN LED
					baichul_end_flag = 1;
					//	bStartOn = FALSE;
					//	delay(1300);
				#endif	
					
					
					
					
					
					break;

				case KEY_STATUS: //������ 
					//lcd70_clear_screen(WHITE);
					// bsp_lcd70_init();
				//	lcd70_clear_screen(WHITE);
				//	lcd70_draw_rectangle(400, 50, 700, 100,BLUE);
				//	lcd70_draw_rectangle(400, 130, 700, 180,BLUE);
				//	lcd70_draw_rectangle(400, 210, 700, 260,BLUE);
				//	lcd70_draw_rectangle(400, 290, 700, 340,BLUE);
				//	lcd70_draw_rectangle(400, 370, 700, 420,BLUE);
					
					//	sprintf(str, "CODE=%2d",(int)KEYCODE);
					// lcd70_show_string_mode(13, 74, str, 16, 0);
					
					//sprintf(str, "L/C1 WEIGHT=%06ld kg",One_Weight);
					sprintf(sT0, "DEVICE_TEL:%s", jangbi.cdma.telno);
//					lcd70_show_string_mode(470, 70,"DEVICE_TEL:012-2203-1337", 16, 0);
				//	lcd70_show_string_mode(470, 70, sT0, 16, 0);
					
					//sprintf(str, "L/C2 WEIGHT=%06ld kg",Two_Weight);
				//	lcd70_show_string_mode(470, 150, "ANNTENNA=GOOD", 16, 0);
					
					//sprintf(str, "L/C3 WEIGHT=%06ld kg",Three_Weight);
					//lcd70_show_string_mode(470, 230, "USER1:0103443-1529", 16, 0);
					Reg_Tel[11] = 0;
					sprintf(sT0, "TEL=%s", Reg_Tel);
				//	lcd70_show_string_mode(470, 230, (const unsigned char *)sT0, 20, 0);
					
					sprintf(sT0, "SMS_TIME=%c%c%c%c", Sms_Time[0], Sms_Time[1], Sms_Time[2], Sms_Time[3] );
				//	lcd70_show_string_mode(470, 310, (const unsigned char *)sT0, 20, 0);
					
					
					//sprintf(str, "L/C4 WEIGHT=%06ld kg",Four_Weight);
					//lcd70_show_string_mode(470, 310, "USER2:010-9195-4072", 16, 0);
					
				//	lcd70_show_string_mode(470, 390, "USER3:010-2004-0580", 16, 0);
					
					Current_Display=STATUS_DISPLAY;
					Delay_ms(6000);
					goto INITIAL;					
					
//					break;

				default:
					break;
			} //switch(ch)
		} //if (keypush())
	 
	
		/*
		raw_data=Get_adc_from_module();  // ���κ��� a/d ���� �о�´�.
		if(Weight_flag)// ���� ���� ���Ը� ���������� �޾�����  ���繫�Ը� ǥ���Ѵ�. 
		{
			v_adc1_buf = (long)(gnfFactor * raw_data);
			diff1 = v_adc1_buf - v_adc_org;
			diff2 = v_adc1_buf - prev_adc1;	// for stable 
			gxlGrossWeight = ((diff1 + 10) / v_ei_multiply_factor) * v_division;
			gxlGrossWeight=gxlGrossWeight+gpl3Weight;
			lcd70_write_weight(100,150,gxlGrossWeight);// total weight displayin
			Weight_flag=0;
		}
		*/
	
		/*
		INPUT_ONE   // �����Է��� ������  
		lcd70_draw_demo_bin(start_lamp.pixel_data,550,400,start_lamp.width+550,start_lamp.height+400);// RED ǥ�ú� �׸��� 
		else
		lcd70_draw_demo_bin(stop_lamp.pixel_data,550,400,stop_lamp.width+550,stop_lamp.height+400);	//  GREEN LED
		*/		

		
		// �ɼǺ���� ���� �����ð� ������ ������ �ɼǺ� ������ ������  ON/OFF �Ѵ�
		// 200 �� �������� ���� ������ ������ �ٽ� on/off ��Ų��. 
	////	Adc_Power_Off_On(); 
	
	
//	u8  min_rotate=0;
//u8  min_buffer;

	
		//u8 HT1381_year,HT1381_month,HT1381_date,HT1381_hour,HT1381_minute,HT1381_second; 
	//	Get1381(); 
	//sprintf(str, "date:20%02x-%02X-%02X  time:%02x-%02X-%02X ", Gettimebuf[6],Gettimebuf[4],Gettimebuf[3],Gettimebuf[2],Gettimebuf[1],Gettimebuf[0]);	USART1_puts(str);
  

		//�źи��� �����ϴ� ���
		if(gbMinEvent) // 20171203  at rtc.c
		{
			
		 Get1381(); // �ð��� �о���� 
			HT1381_year=Gettimebuf[6];
			HT1381_month=Gettimebuf[4];
			HT1381_date=Gettimebuf[3];
			HT1381_hour=Gettimebuf[2];
			HT1381_minute=Gettimebuf[1];
			HT1381_second=Gettimebuf[0];
				
			sprintf(str, " : giToday=%02x   1381_DATA=%02X",giToday, HT1381_date);	
		  USART1_puts(str);  
				
			
			
			
			
			if(gnlCdmaUse)//��ȭ�� ����ϸ� 
			{
			 	gbMinEvent = 0;
			//websms ���� ���� Ȯ�� �� �翬��
			gbWebSMSConnection = 1;
			//cdma �ð� �о ���׺�� ����ð� ������
			gbGetCdmaTime = 1;
			if(gnlUseLTE)
			{
				sprintf( sT0,"AT+BC=$DATE=%04d%02d%02d%02d%02d%02d@", jangbi.cdma.tm.year, jangbi.cdma.tm.month, jangbi.cdma.tm.date, rtc_hour, rtc_min, rtc_sec);
				UART4_puts(sT0);
        USART1_puts(sT0);
			}
			
			//�ð�����ȭ �ɵ��� day-x ��� ��¥ ������Ʈ - ���� 12�� ��ó�̸� �ȵ� ���� ����.
			if(poweron_date_set_counter)
			{
				poweron_date_set_counter--;
				///giToday = rtc_date;
				 giToday = HT1381_date;
			}
				
			}

      else // ��ȭ�� ��� ���ϸ� 
      {				
			SendtoPc();
			gbMinEvent = 0;
			
			USART1_puts("One minute rotaion");
			if(poweron_date_set_counter) //1204
			{
				poweron_date_set_counter--;
				giToday = HT1381_date;
				
				sprintf(str, "One_minutes rotation : giToday=%02x   1381_DATA=%02X",giToday, HT1381_date);	
		    USART1_puts(str);
			}
			}
			
		///	 Send_to_server(SEND_BAICHUL, "BC-X");	//���� ���۽� ���� ����
		/// 	test_routine();//ȸ�缭���� ������ 
      


		} //�źи��� �����ϴ� ���
		/*
		else if (gbHourEvent&&gnlCdmaUse)	//add 2017.03.02
		
		{
			gbHourEvent = 0;
			cdma_detach();
			Cdma_Power_Off();
	
///	LCD_restart();

			Delay_ms(1000);
			Cdma_Power_On();
		}
		*/
		
		//gbDayEvent
		
		/*
		else if (gbDayEvent&&gnlCdmaUse)	//add 2017.03.02  2020
		{
			  Send_to_server(SEND_BAICHUL, "BC-X");	//���� ���۽� ���� ����
		  	test_routine();//ȸ�缭���� ������ 
      
			
			
			gbDayEvent = 0;
			cdma_detach();
			Delay_ms(3000); // power off �ϱ���  3������ ��ٸ���.
			Cdma_Power_Off();
	
///	LCD_restart();

			Delay_ms(1000);
			Cdma_Power_On();
		}
		
		*/
		
		
   
	} while(1);
} /* main */




void SendtoPc(void)  // 20171108
{ 
	#define  STX 0X02
	#define  ETX 0X03
  #define  REQ 0X05
	char  str[50];
	long sum=0;
	
	RS422OFF;
 
 /******** Request from pc program *******************/
	// for test: @ ID CMD !
	// for real: REQ ID CMD ETX
  //	if((cmd_2[0]/0x30)==(gnlMyAddress/10) &&(cmd_2[1]/0x30)==(gnlMyAddress%10))
 if(Usart2_Interrupt_flag==1)//1204
 {	 
	//RS422ON; Delay_ms(30);
	 //#define	RS422ON		GPIO_SetBits(GPIOA, GPIO_Pin_4)
//#define	RS422OFF	GPIO_ResetBits(GPIOA, GPIO_Pin_4)

	if((cmd_2[0]-0x30)==(gnlMyAddress/10) &&(cmd_2[1]-0x30)==(gnlMyAddress%10))
	//	if((cmd_2[1]-0x30)==(gnlMyAddress%10))
	{
	 RS422ON;	
	 Delay_ms(50); // request from Mr park
		
	 switch (cmd_2[2] * 0x10000L + cmd_2[3] * 0x100L + cmd_2[4]) //1204
	{
	 case 'C'*0x10000L+'W'*0x100L+'T':	//Current WeighT//43   57  54
		 
	 USART1_puts("CWT");
      USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
	   //1205 
	 if(gnlSilo1Selection==1)//SILO ������ 1��
	 {
	   if(sign)
			sprintf (str, "-%7lu", (long)gxlWeight);
			  else
			sprintf (str, " %7lu", (long)gxlWeight);
	 }   
	 else// silo ������ 2��
	 {
		 if(sign_2) gxlWeight_2=0;
		 if(sign)   gxlWeight=0;
		 sum=gxlWeight+gxlWeight_2;
		 sprintf (str, " %7lu", (long)sum);
	 } 
     //gxlWeight_2			
		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
				
			//	USART2_puts_rs422
	 
	 
	    //sprintf(str, "CWT%5ld", (long)gxlWeight);
	    //USART2_puts(str);
	    //USART2_putchar(0x03);   //tail
  	    break;
	 
	 case 'D'*0x10000L+'-'*0x100L+'0':	//Current WeighT
		 USART1_puts("D-0");
		  USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			if(gnlSilo1Selection==1)//SILO ������ 1��
	     sprintf (str, "%8lu", (long)gnlDailyTotal);
		  else
			{
       sum=gnlDailyTotal+gnlDailyTotal2;
				sprintf (str, "%8lu", (long)sum);
      }				
	    USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
	       break;
 		case 'D'*0x10000L+'A'*0x100L+'T':	//DATe
			USART1_puts("DAT");
		  USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
		  sprintf (str, "%2X.%02X.%02X", HT1381_year, HT1381_month, HT1381_date);
			USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
	  break;
	
    	case 'T'*0x10000L+'I'*0x100L+'M':	//DATe
				USART1_puts("TIM");
		  USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
		  sprintf (str, "%2X.%02X.%02X", HT1381_hour, HT1381_minute, HT1381_second);
			USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
	  break;
	

		
			/*
			
			 HT1381_year=Gettimebuf[6];
			HT1381_month=Gettimebuf[4];
			HT1381_date=Gettimebuf[3];
			HT1381_hour=Gettimebuf[2];
			HT1381_minute=Gettimebuf[1];
			HT1381_second=Gettimebuf[0];
		
			case 'D'*0x10000L+'A'*0x100L+'T':	//DATe
				SendDataEnable = 0xFF;
				sprintf (&SendBuffer[6], "%2d.%02d.%02d", (int)RTCYEAR, (int)RTCMONTH, (int)RTCDATE);
				SendBuffer[14] = ETX;
				SendBuffer[15] = 0;
				break;
			case 'T'*0x10000L+'I'*0x100L+'M':	//TIMe
				SendDataEnable = 0xFF;
				sprintf (&SendBuffer[6], "%2d.%02d.%02d", (int)RTCHOURS, (int)RTCMINUTES, (int)RTCSECONDS);
				SendBuffer[14] = ETX;
				SendBuffer[15] = 0;
				break;
			
			*/
			
			
			
			
			
			
	 	
	case 'D'*0x10000L+'-'*0x100L+'1':	//Current WeighT
		USART1_puts("D-1");
	    USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[0]);
       else
			 {
        sum=gnlPreDailyTotal[0]+gnlPreDailyTotal2[0];
				 sprintf (str, "%8lu", (long)sum);
       }				 


			USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			 
	
	      break;
	 
	case 'D'*0x10000L+'-'*0x100L+'2':	//Current WeighT
		USART1_puts("D-2");
	      // USART2_puts("D-2 Result sending!!");
	       USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			//sprintf (str, "%8lu", (long)gnlPreDailyTotal[1]);
		if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[1]);
       else
			 {
        sum=gnlPreDailyTotal[1]+gnlPreDailyTotal2[1];
				 sprintf (str, "%8lu", (long)sum);
       }				 

		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			  
	
	      break;
	 
	case 'D'*0x10000L+'-'*0x100L+'3':	//Current WeighT
		USART1_puts("D-3");
	      //USART2_puts("D-3 Result sending!!");
	 USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			//sprintf (str, "%8lu", (long)gnlPreDailyTotal[2]);
		  if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[2]);
       else
			 {
        sum=gnlPreDailyTotal[2]+gnlPreDailyTotal2[2];
				 sprintf (str, "%8lu", (long)sum);
       }				 

		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			
	      break;
	case 'D'*0x10000L+'-'*0x100L+'4':	//Current WeighT
		USART1_puts("D-4");
		   USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			//sprintf (str, "%8lu", (long)gnlPreDailyTotal[3]);
	  if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[3]);
       else
			 {
        sum=gnlPreDailyTotal[3]+gnlPreDailyTotal2[3];
				 sprintf (str, "%8lu", (long)sum);
       }				 

		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			
       // USART2_puts("D-4 Result sending!!");
	       break;
	case 'D'*0x10000L+'-'*0x100L+'5':	//Current WeighT
		USART1_puts("D-5");
		     USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			//sprintf (str, "%8lu", (long)gnlPreDailyTotal[4]);
	  if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[4]);
       else
			 {
        sum=gnlPreDailyTotal[4]+gnlPreDailyTotal2[4];
				 sprintf (str, "%8lu", (long)sum);
       }				 

		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			
		     //USART2_puts("D-5 Result sending!!");
	      break;
	case 'D'*0x10000L+'-'*0x100L+'6':	//Current WeighT
		USART1_puts("D-6");
	      // USART2_puts("D-6 Result sending!!"); 
	 USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			//sprintf (str, "%8lu", (long)gnlPreDailyTotal[5]);
	  if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[5]);
       else
			 {
        sum=gnlPreDailyTotal[5]+gnlPreDailyTotal2[5];
				 sprintf (str, "%8lu", (long)sum);
       }				 

		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			
	       break;
	case 'D'*0x10000L+'-'*0x100L+'7':	//Current WeighT
		USART1_puts("D-7");
	      //USART2_puts("D-7 Result sending!!");
	     USART2_putchar(0x02);   //head
      USART2_putchar((gnlMyAddress/10)+0x30);
      USART2_putchar((gnlMyAddress%10)+0x30);	 
	    USART2_putchar(cmd_2[2]);
	    USART2_putchar(cmd_2[3]);
	    USART2_putchar(cmd_2[4]);
			//sprintf (str, "%8lu", (long)gnlPreDailyTotal[6]);
	  if(gnlSilo1Selection==1)//SILO ������ 1��
			sprintf (str, "%8lu", (long)gnlPreDailyTotal[6]);
       else
			 {
        sum=gnlPreDailyTotal[6]+gnlPreDailyTotal2[6];
				 sprintf (str, "%8lu", (long)sum);
       }				 

		  USART2_puts_rs422(str);
			USART2_putchar(0x03);
			USART2_putchar(0);
			
	      break;
	
	default:
   break;		
		
}
	/*
cmd_2[0]=0XFF;
cmd_2[1]=0XFF;
cmd_2[2]=0XFF;
cmd_2[3]=0XFF;
cmd_2[4]=0XFF;
cmd_2[5]=0XFF;
	
Usart2_Interrupt_flag=0;
	*/
// Delay_ms(50);
 //RS422OFF;

//	Usart2_Interrupt_flag=0;
  Delay_ms(50);
  RS422OFF;
	
	}
	
	
cmd_2[0]=0XFF;
cmd_2[1]=0XFF;
cmd_2[2]=0XFF;
cmd_2[3]=0XFF;
cmd_2[4]=0XFF;
cmd_2[5]=0XFF;
	
RxBuffer2[0]=0XFF;
RxBuffer2[1]=0XFF;
RxBuffer2[2]=0XFF;
RxBuffer2[3]=0XFF;
RxBuffer2[4]=0XFF;
RxBuffer2[5]=0XFF;
RxBuffer2[6]=0XFF;
RxBuffer2[7]=0XFF;

	
	
	
	
Usart2_Interrupt_flag=0;
	
// Delay_ms(10);
 //RS422OFF;
	
}	//if(Usart2_Interrupt_flag==1)//1204
	

}


void SMS_PROCESS(void)
{	
	int	iz;
	char telephone_number[20];
	union { u32 dw; u16 u[2]; u8 c[4];} temp;
	char sT0[100];

//	Send_to_server(SMS_RECEIVED, RxBuffer2_sms);

	//#RES_MODEMLONE01034431529@(26 BYTE)	//CDMA RESET
	//#REG_TELEPHONE01034431529@(26 BYTE)	//���ⷮ ������ ��ȭ��ȣ��� 
	//#DEL_TELEPHONE01034431529@(26 BYTE)	//��ϵ� ��ȭ��ȣ ����
	//#AUT_SENDINGTIME_SMS_1234@(26 BYTE)	//DATA �����ϴ� �ð� ���(�ڵ�����)
	//#MAN_SENDINGTI01034431529@(26 BYTE)	//SMS �� ���� DATA ���� 
	//#REMOTE_PROGRAM_UPLOADING@(26 BYTE)	//���� �߿��� �������� 
	//#IP=123.123.123.123:12345@(26 BYTE)	//�߿��� ������Ʈ IP ���� 
	
/*
	sprintf(sT0, "sms=%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c  c=%2d",
                   RxBuffer2_sms[RxCounter2_sms-28],	   
                   RxBuffer2_sms[RxCounter2_sms-27],	   
                   RxBuffer2_sms[RxCounter2_sms-26],	   
				   RxBuffer2_sms[RxCounter2_sms-25],
				   RxBuffer2_sms[RxCounter2_sms-24],
				   RxBuffer2_sms[RxCounter2_sms-23],
				   
                   RxBuffer2_sms[RxCounter2_sms-22],	   
                   RxBuffer2_sms[RxCounter2_sms-21],	   
				   RxBuffer2_sms[RxCounter2_sms-20],
				   RxBuffer2_sms[RxCounter2_sms-19],
				   RxBuffer2_sms[RxCounter2_sms-18],
				   RxBuffer2_sms[RxCounter2_sms-17],
				   RxBuffer2_sms[RxCounter2_sms-16],
				   RxBuffer2_sms[RxCounter2_sms-15],
				   RxBuffer2_sms[RxCounter2_sms-14],
				   RxBuffer2_sms[RxCounter2_sms-13],
				   RxBuffer2_sms[RxCounter2_sms-12],
				   RxBuffer2_sms[RxCounter2_sms-11],	   
				   RxBuffer2_sms[RxCounter2_sms-10],
				   RxBuffer2_sms[RxCounter2_sms-9],
				   RxBuffer2_sms[RxCounter2_sms-8],
				   RxBuffer2_sms[RxCounter2_sms-7],
				  // RxBuffer2_sms[RxCounter2_sms-6],
				  // RxBuffer2_sms[RxCounter2_sms-5],
				  // RxBuffer2_sms[RxCounter2_sms-4],
				  // RxBuffer2_sms[RxCounter2_sms-3],
				  // RxBuffer2_sms[RxCounter2_sms-2],
				   RxCounter2_sms
	);
	lcd70_show_string_mode(200, 100, (const unsigned char *)sT0, 20, 0);
*/
//	sprintf(sT0, "sms=%s ::c=%2d", RxBuffer2_sms, RxCounter2_sms);
//	lcd70_show_string_mode(200, 100, (const unsigned char *)sT0, 20, 0);

		   //1127
		   //1222
		   
DEBUG_puts("SMS RECEIVED");
DEBUG_puts(RxBuffer2_sms);

//	if(RxBuffer2_sms[RxCounter2_sms-28]=='R' &&  RxBuffer2_sms[RxCounter2_sms-27]=='E' && RxBuffer2_sms[RxCounter2_sms-26]=='S')
	if(RxBuffer2_sms[1]=='R' &&  RxBuffer2_sms[2]=='E' && RxBuffer2_sms[3]=='S')
	{
		//lcd70_show_string_mode(300, 50,"MODEM RESET !!!", 20, 0);
		cdma_send_cmd("AT$LGTRESET", 11);	//2014.10.27
	}
/**	
	else if(RxBuffer2_sms[1]=='I' &&  RxBuffer2_sms[2]=='A' && RxBuffer2_sms[3]=='P')
	{
		lcd70_show_string_mode(300, 50,"FIRMWARE DOWNLOAD  !!!", 20, 0);
		goto_iap(TMS_SERVER_IP, TMS_SERVER_PORT); 
		//cdma_send_cmd("AT$LGTRESET", 11);	//2014.10.27
	}
***/	
	else if(RxBuffer2_sms[1]=='R' &&  RxBuffer2_sms[2]=='E' && RxBuffer2_sms[3]=='G')
	{
		//lcd70_show_string_mode(300, 50,"TELEPHONE_REGISTRATION", 20, 0);
		
		//long Tel_Number_1;//     01
		//long Tel_Number_2;//     3443 
		//long Tel_Number_3;//     1529 
		//Reg_Tel[20]
		
/* 2016.4.20
		Initiaize_eeprom();
		FSMC_DISABLE;
		
		Delay_ms(1000);
		
		//temp.dw=v_zero;
		temp.c[0]=RxBuffer2_sms[RxCounter2_sms-15];//0
		temp.c[1]=RxBuffer2_sms[RxCounter2_sms-14];//0
		temp.c[2]=RxBuffer2_sms[RxCounter2_sms-13];//0
		
		
		I2C_EE_BufferWrite(temp.c, ADR_Tel_Number_1, 4);
		I2C_EE_BufferRead( temp.c, ADR_Tel_Number_1, 4);
		
		Reg_Tel[0]=temp.c[0];
		Reg_Tel[1]=temp.c[1];
		Reg_Tel[2]=temp.c[2];
		


		     
             temp.c[0]=RxBuffer2_sms[RxCounter2_sms-12];//0
			 temp.c[1]=RxBuffer2_sms[RxCounter2_sms-11];//0
			 temp.c[2]=RxBuffer2_sms[RxCounter2_sms-10];//0
			 temp.c[3]=RxBuffer2_sms[RxCounter2_sms-9];//0
			 I2C_EE_BufferWrite(temp.c, ADR_Tel_Number_2, 4);
	         I2C_EE_BufferRead( temp.c, ADR_Tel_Number_2, 4);

			 Reg_Tel[3]=temp.c[0];
			 Reg_Tel[4]=temp.c[1];
             Reg_Tel[5]=temp.c[2];
			 Reg_Tel[6]=temp.c[3];

			 temp.c[0]=RxBuffer2_sms[RxCounter2_sms-8];//0
			 temp.c[1]=RxBuffer2_sms[RxCounter2_sms-7];//0
			 temp.c[2]=RxBuffer2_sms[RxCounter2_sms-6];//0
			 temp.c[3]=RxBuffer2_sms[RxCounter2_sms-5];//0
			 I2C_EE_BufferWrite(temp.c, ADR_Tel_Number_3, 4);
	         I2C_EE_BufferRead( temp.c, ADR_Tel_Number_3, 4);
		
			 Reg_Tel[7]=temp.c[0];
			 Reg_Tel[8]=temp.c[1];
             Reg_Tel[9]=temp.c[2];
			 Reg_Tel[10]=temp.c[3];
			 Reg_Tel[11]=0;
	          FSMC_ENABLE;
*/
/*
		Reg_Tel[0] = temp.c[0] = RxBuffer2_sms[RxCounter2_sms-15];//0
		Reg_Tel[1] = temp.c[0] = RxBuffer2_sms[RxCounter2_sms-14];//0
		Reg_Tel[2] = temp.c[0] = RxBuffer2_sms[RxCounter2_sms-13];//0
		EE_Write_val(ADR_Tel_Number_1, temp.dw, 4);

		Reg_Tel[3] = temp.c[0] = RxBuffer2_sms[RxCounter2_sms-12];//0
		Reg_Tel[4] = temp.c[1] = RxBuffer2_sms[RxCounter2_sms-11];//0
		Reg_Tel[5] = temp.c[2] = RxBuffer2_sms[RxCounter2_sms-10];//0
		Reg_Tel[6] = temp.c[3] = RxBuffer2_sms[RxCounter2_sms-9];//0
		EE_Write_val(ADR_Tel_Number_2, temp.dw, 4);

		Reg_Tel[7] = temp.c[0] = RxBuffer2_sms[RxCounter2_sms-8];//0
		Reg_Tel[8] = temp.c[1] = RxBuffer2_sms[RxCounter2_sms-7];//0
		Reg_Tel[9] = temp.c[2] = RxBuffer2_sms[RxCounter2_sms-6];//0
		Reg_Tel[10] = temp.c[3] = RxBuffer2_sms[RxCounter2_sms-5];//0
		Reg_Tel[11]=0;
		EE_Write_val(ADR_Tel_Number_3, temp.dw, 4);
*/
		sprintf(sT0, "TEL=%s", Reg_Tel);
		//lcd70_show_string_mode(300, 80, (const unsigned char *)sT0, 20, 0);
	}
    else if(RxBuffer2_sms[RxCounter2_sms-28]=='D' &&  RxBuffer2_sms[RxCounter2_sms-27]=='E' && RxBuffer2_sms[RxCounter2_sms-26]=='L')
	{
		//lcd70_show_string_mode(300, 50,"TELEPHONE_DELETION !!!", 20, 0);
	}
	else if(RxBuffer2_sms[RxCounter2_sms-28]=='A' &&  RxBuffer2_sms[RxCounter2_sms-27]=='U' && RxBuffer2_sms[RxCounter2_sms-26]=='T')
//	else if(RxBuffer2_sms[1]=='A' &&  RxBuffer2_sms[2]=='U' && RxBuffer2_sms[3]=='T')
	{
		//lcd70_show_string_mode(300, 50,"DATA_SENDING_TIME  !!!", 20, 0);
/* 2016.4.20		
		Initiaize_eeprom();
		FSMC_DISABLE;
		
		temp.c[0]=RxBuffer2_sms[RxCounter2_sms-8];//0
		temp.c[1]=RxBuffer2_sms[RxCounter2_sms-7];//0
		temp.c[2]=RxBuffer2_sms[RxCounter2_sms-6];//0
		temp.c[3]=RxBuffer2_sms[RxCounter2_sms-5];//0
		
		Delay_ms(1000);
		I2C_EE_BufferWrite(temp.c, ADR_gnlSms_Send_Time, 4);
		I2C_EE_BufferRead( temp.c, ADR_gnlSms_Send_Time, 4);
		FSMC_ENABLE; 
		
		Sms_Time[0]=temp.c[0];
		Sms_Time[1]=temp.c[1];
		Sms_Time[2]=temp.c[2];
		Sms_Time[3]=temp.c[3];
*/		
//		FSMC_DISABLE;
//		Delay_ms(1000);
/*
		Sms_Time[0] = temp.c[0] = RxBuffer2_sms[RxCounter2_sms-8];
		Sms_Time[1] = temp.c[1] = RxBuffer2_sms[RxCounter2_sms-7];
		Sms_Time[2] = temp.c[2] = RxBuffer2_sms[RxCounter2_sms-6];
		Sms_Time[3] = temp.c[3] = RxBuffer2_sms[RxCounter2_sms-5];
		
		EE_Write_val(ADR_gnlSms_Send_Time, temp.dw, 4);
*/
//		Delay_ms(1);
//  		FSMC_ENABLE; 

		sprintf(sT0, "SMS TIME=%lu.%lu.%c%c%c%c", temp.dw, (u32 *)Sms_Time, Sms_Time[0], Sms_Time[1], Sms_Time[2], Sms_Time[3]);
		//lcd70_show_string_mode(300, 20, (const unsigned char *)sT0, 20, 0);
	}
   	// �������� FACTOR �� :: #RFAC=12345@
   	//else if(RxBuffer2_sms[RxCounter2_sms-28]=='F' &&  RxBuffer2_sms[RxCounter2_sms-27]=='A' && RxBuffer2_sms[RxCounter2_sms-26]=='C')
	else if( !strncmp(RxBuffer2_sms, "#RFAC=", 6))
	{
		sms_process(RxBuffer2_sms);
/*		
		lcd70_show_string_mode(300, 50,"REAL_WEIGHT_FACTOR  !!!", 20, 0);
		
		RxBuffer2_sms[11] = 0;
		Real_Weight_Factor = EE_Write_val(ADR_Real_Weight_Factor, atol(&RxBuffer2_sms[6]), 4);
		
		sprintf(sT0, "FACTOR=%ld", (long)Real_Weight_Factor);
		lcd70_show_string_mode(300, 80, (const unsigned char *)sT0, 20, 0);
*/		
	}
   	// �������� �� :: #RWEIGHT=12345@
	else if( !strncmp(RxBuffer2_sms, "#RWEIGHT=", 8))
	{
		sms_process(RxBuffer2_sms);
	}
   	// �������� :: #RZERO=12345@
	else if( !strncmp(RxBuffer2_sms, "#RZERO=", 6))
	{
		sms_process(RxBuffer2_sms);
	}
   	// �������� ���۰��� ����(��) :: #RSTTIME=12345@
	else if( !strncmp(RxBuffer2_sms, "#RSTTIME=", 8))
	{
		sms_process(RxBuffer2_sms);
	}
	// �ε弿 �׾��� �� ���� ON/OFF/
	else if( !strncmp(RxBuffer2_sms, "#RLCCOMP=", 8))
	{
		sms_process(RxBuffer2_sms);
	}
	else if( !strncmp(RxBuffer2_sms, "#IAP=", 4))
	{
	//	lcd70_show_string_mode(300, 50,"FIRMWARE DOWNLOAD  !!!", 20, 0);
		goto_iap(TMS_SERVER_IP, TMS_SERVER_PORT); 
	}
	else if(RxBuffer2_sms[RxCounter2_sms-28]=='M' &&  RxBuffer2_sms[RxCounter2_sms-27]=='A' && RxBuffer2_sms[RxCounter2_sms-26]=='N')
	{
	//	lcd70_show_string_mode(300, 50,"MANUAL DATA SENDING  !!!", 20, 0);	//1127
		
		telephone_number[0]=RxBuffer2_sms[RxCounter2_sms-15];	  //0
		telephone_number[1]=RxBuffer2_sms[RxCounter2_sms-14];	  //1
		telephone_number[2]=RxBuffer2_sms[RxCounter2_sms-13];	  //0
		
		telephone_number[3]=RxBuffer2_sms[RxCounter2_sms-12];	  //3
		telephone_number[4]=RxBuffer2_sms[RxCounter2_sms-11];	  //4
		telephone_number[5]=RxBuffer2_sms[RxCounter2_sms-10];	  //4
		telephone_number[6]=RxBuffer2_sms[RxCounter2_sms-9];	  //3
		
		telephone_number[7]=RxBuffer2_sms[RxCounter2_sms-8];	 //1
		telephone_number[8]=RxBuffer2_sms[RxCounter2_sms-7];	 //5
		telephone_number[9]=RxBuffer2_sms[RxCounter2_sms-6];	 //2
		telephone_number[10]=RxBuffer2_sms[RxCounter2_sms-5];	 //9
		telephone_number[11]=0; //NULL

		/*
		telephone_number[0]='0';
		telephone_number[1]='1';
		telephone_number[2]='0';
		
		telephone_number[3]='3';
		telephone_number[4]='4';
		telephone_number[5]='4';
		telephone_number[6]='3';
		
		telephone_number[7]='1';
		telephone_number[8]='5';
		telephone_number[9]='2';
		telephone_number[10]='9';
		telephone_number[11]=0;
		*/

		Data_Send_Sms(telephone_number);
		cdma_send_cmd("AT$LGTACK", 9); 	//2014.10.21 �޾Ҵٴ� ���� ������ ���ڰ� �ѹ��� ���ƿ��� �Ѵ�. 
	}
	
	//zigbee�� ���� @#ZIGBEE=ID,$MSG@
	else if( !strncmp(RxBuffer2_sms, "#ZIGBEE=", 8))
	{
		//lcd70_show_string_mode(300, 50,"ZIGBEE !!!", 20, 0);
		
		sprintf(sT0, "AT+UC=%s", &RxBuffer2_sms[8]);
		ZIGBEE_puts(sT0);
	}

//	RxBuffer2_sms[RxCounter2_sms-28]=0XFF;
//	RxBuffer2_sms[RxCounter2_sms-27]=0XFF;
//	RxBuffer2_sms[RxCounter2_sms-26]=0XFF;

	for(iz=0; iz<MAX_RXBUFFER2_SMS; iz++) RxBuffer2_sms[iz] = 0;
	
sprintf(sT0, "Usart3_sms_received_flag=%d, ", Usart3_sms_received_flag);
//lcd70_show_string_mode(0, 20,sT0, 16, 0);	//1127
	
	Usart3_sms_received_flag=0;
	RxCounter2_sms = 0;
	Delay_ms(1000);
sprintf(sT0, "Usart3_sms_received_flag=%d, ", Usart3_sms_received_flag);
//lcd70_show_string_mode(300, 20,sT0, 16, 0);	//1127
	
//	lcd70_show_string_mode(300, 50,"                         ", 16, 0);	//1127
}

//lte, zigbee common
void sms_process(char *msg)     // 0829
{
	signed long	l;
	unsigned long ul;
	char sT0[50];
	
   	// �������� FACTOR �� :: #RFAC=12345@, $RFAC=12345@
	if( !strncmp( &msg[1], "RFAC=", 5))	//stx ����
	{
//		lcd70_show_string_mode(300, 50,"REAL_WEIGHT_FACTOR  !!!", 20, 0);
		
		msg[11] = 0;
		Real_Weight_Factor = EE_Write_val(ADR_Real_Weight_Factor, atol(&msg[6]), 4);
	
		sprintf(sT0, "FACTOR=%ld  ", (long)Real_Weight_Factor);
		GLCD_string (0, 4, sT0); Delay_ms(3000);
		
		
		
		
//		lcd70_show_string_mode(300, 80, (const unsigned char *)sT0, 20, 0);
		
		Send_to_server(SEND_SETVALUE, "set");
	}
   	// �������� �� :: #RWEIGHT=12345@, $RWEIGHT=12345@
	else if( !strncmp( &msg[1], "RWEIGHT=", 8))	//stx ����
	{
//		lcd70_show_string_mode(300, 50,"REAL_WEIGHT !!!", 20, 0);
		msg[14] = 0;
		gplCompensationWeight = calcCompensationWeight(atol(&msg[9]));
		gplCompensationWeight = EE_Write_val(ADR_gplCompensationWeight, gplCompensationWeight, 4);
	
		sprintf(sT0, "REAL_WEIGHT=%ld, %ld. ", (long)gplCompensationWeight, atol(&msg[9]));
//		lcd70_show_string_mode(300, 80, (const unsigned char *)sT0, 20, 0);
	
		Delay_ms(2000);
		
		Send_to_server(SEND_SETVALUE, "set");
		USART1_puts(sT0);
	}
   	// �������� :: #RZERO=12345@
	else if( !strncmp( &msg[1], "RZERO=", 6))
	{
//		sms_process(RxBuffer2_sms);
		zero_func();
	}
   	// �������� ���۰��� ����(��) :: #RSTTIME=12345@
	else if( !strncmp( &msg[1], "RSTTIME=", 8))
	{
		l = atol(&msg[9]);
		if(( MIN_gxwStatusSendInterval <= gxwStatusSendInterval) && (gxwStatusSendInterval <= MAX_gxwStatusSendInterval))
		{
			gxwStatusSendInterval = EE_Write_val(ADR_gxwStatusSendInterval, gxwStatusSendInterval, 4);
		}
	}
	// �ε弿 �׾��� �� ���� ON/OFF/
	else if( !strncmp( &msg[1], "RLCCOMP=", 8))
	{
		l = atol(&msg[9]);
		if(( MIN_gnlLcCompensation <= l) && (l <= MAX_gnlLcCompensation))
		{
			gnlLcCompensation = l;
			gnlLcCompensation = EE_Write_val(ADR_gnlLcCompensation, gnlLcCompensation, 4);
		}
	}

	//��¥, �ð� ����ȭ
	else if( !strncmp(&msg[1], "DATE=", 5) && msg[20] == '@')
	{
		RTC_date_to_sec( &msg[6]);
	}

USART1_puts(msg);	
}	

#ifdef __gpi8310

void zero_func(void)
{
	char sT0[256];
	
	sprintf(sT0, "v_zero1=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
//	lcd70_show_string_mode(200, 30, (const unsigned char *)sT0, 20, 0);

	/*
	while(!Weight_flag)
	{
		raw_data=Get_adc_from_module_20170626(); 	// 
	};
*/
	
	get_weight_wait();
	get_weight_wait();
	get_weight_wait();
	if( get_weight_wait()) {
	/*		
		Weight_flag = 0;
		rotation = 1;
			
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 
		raw_data=Get_adc_from_module_20170626(); 	// 

		sprintf(sT0, "v_zero2=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
		lcd70_show_string_mode(200, 30, (const unsigned char *)sT0, 20, 0);

		v_zero=raw_data;

		v_adc_org  = (long)((float)raw_data * gnfFactor);  // calibration�� ������ ��� 

		gplCompensationWeight=0;
	*/
		sprintf(sT0, "v_zero2=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
//		lcd70_show_string_mode(200, 30, (const unsigned char *)sT0, 20, 0);

		v_zero = gxlRawAdc;
		v_adc_org  = gxlFactoredAdc;	// factor ���� ������ ��� 
		gplCompensationWeight = 0;

		v_zero = EE_Write_val(ADR_v_zero, v_zero, 4);
		v_adc_org = EE_Write_val(ADR_v_adc_org, v_adc_org, 4);
		gplCompensationWeight = EE_Write_val(ADR_gplCompensationWeight, gplCompensationWeight, 4);

	/*
		v_zero = EE_Write_val(ADR_v_zero, v_zero, 4);
		v_zero = EE_Read_val(ADR_v_zero, 4);
		Delay_ms(300);
		//					gplCompensationWeight = EE_Write_val(ADR_gplCompensationWeight, gplCompensationWeight, 4);
		gplCompensationWeight = EE_Write_val(ADR_gplCompensationWeight, 0, 4);

		gplCompensationWeight = EE_Read_val(ADR_gplCompensationWeight, 4);
	**/	
		
		sprintf(sT0, "v_zero3=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
//		lcd70_show_string_mode(200, 30, (const unsigned char *)sT0, 20, 0);
	}
}

#endif

void zero_func(void) // 0829
{
	char sT0[100];
	u8 i;
	long temp_buff;
	u8 exit_flag=0;
	long sum=0;
	
	sprintf(sT0, "v_zero1=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
	
	//091801
	
	lcd_clear();
	if(gnlLanguage==1)// korean
	{	
	if(gnlSilo1Selection==2)// silo 2�� ����	
	GLCD_string (0, 2, " ���̷� 1��");	
	GLCD_string (0, 4, " ���� ���� ?");
	
	}
	else
		{
		if(gnlSilo1Selection==2)// silo 2�� ����		
		GLCD_string (0, 2, " SILO 1");	
		GLCD_string (0, 4, " MAKE ZERO ?");
		}
	
	Delay_ms(2000);
	
	while(!exit_flag)
	{
		if(keypush_8510())
	{
		//ch=(keypush_8510());

		switch(KeyCode)
		{
			case  ENTER:
		   exit_flag=1;
		  break;
			
			case  UP: case  DOWN: case  LEFT: case  RIGHT:
			   retry_message();
         goto ZERO_FINISH;			
			
		  break;
			
			
      default:
       break;				
			
		}
		
		
	} // of keypuxh 
	
};	
	
	lcd_clear();
	
	/*
	get_weight_wait();
	get_weight_wait();
	get_weight_wait();
	*/
	 for(i=0;i<5;i++)
 {
   //temp_buff = read_filtered_adc();
 if(which_adc==1) 
			{
				temp_buff =read_filtered_adc_CS5555_1();
				//temp_buff_1 =read_filtered_adc_CS5555_2();
			}
		 else
		 { 
		  temp_buff = read_filtered_adc();
      //temp_buff_1 = read_filtered_adc_1();
	   }
 
 }
    v_adc_org=(long)(gnfFactor * temp_buff);
		sprintf(sT0, "v_zero2=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);

		v_zero = temp_buff;
		gplCompensationWeight = 0;
		v_zero = EE_Write_val(ADR_v_zero, v_zero, 4);                   Delay_ms(10);
		v_adc_org = EE_Write_val(ADR_v_adc_org, v_adc_org, 4);   Delay_ms(10);
		gplCompensationWeight = EE_Write_val(ADR_gplCompensationWeight, gplCompensationWeight, 4); Delay_ms(10);
		sprintf(sT0, "v_zero3=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
	 GLCD_string (0, 4, " ZERO FINISHED..");
   sign=0;
   sign_2=0;

 ZERO_FINISH:
 
 //0919
lcd_clear(); 
 
  /**************  Initial display *****************************/
 //20210408
 if(gnlSilo1Selection==1)// silo 1 enable   20180627
 {
   Silo_1_Weight_Display(); // silo 1  current weight, feed comsumption weight displaying  0627
	 lcd_inverse();
	// sprintf(str, "�� �� :%5ld kg",gnlDailyTotal);
	 if(gnlLanguage==1)  
	  sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 else
		sprintf(str, "TODAY: %5ld kg ", gnlDailyTotal); 
	  
	// sprintf(str, "DAY-0: %5ld kg ", gnlDailyTotal);
	
	 GLCD_string (0,6 ,str);
	 lcd_normal();

 }
 if(gnlSilo1Selection==2)//1205
 {
	 if(gnlLanguage==1)
	 { 
	  lcd_inverse(); 
    sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	  GLCD_string (0,0 ,str);
	  lcd_normal();
		/* 
	  sprintf(str, "���̷�1:%5ld kg", gnlDailyTotal);
	  GLCD_string (0,2 ,str);
	  sprintf(str, "���̷�2:%5ld kg", gnlDailyTotal2);
	  GLCD_string (0,4 ,str);
	  */
		sprintf(str, "���̷�1:%5ld kg", gnlFeeding1);
	  GLCD_string (0,2 ,str);
	  sprintf(str, "���̷�2:%5ld kg", gnlFeeding2);
	  GLCD_string (0,4 ,str);
	   
		lcd_inverse();
	  sum=gnlDailyTotal+gnlDailyTotal2;
	  sprintf(str, "�� �� :%5ld kg",sum);
	  GLCD_string (0,6 ,str);
	  lcd_normal(); 
	 }
	 else
		 { 
	  lcd_inverse(); 
    sprintf(str, "SILO:%5ld-%5ld", gxlWeight,gxlWeight_2);
	  GLCD_string (0,0 ,str);
	  lcd_normal();
	  sprintf(str, "FEED1:%5ld kg", gnlDailyTotal);
	  GLCD_string (0,2 ,str);
	  sprintf(str, "FEED2:%5ld kg", gnlDailyTotal2);
	  GLCD_string (0,4 ,str);
	  lcd_inverse();
	  sum=gnlDailyTotal+gnlDailyTotal2;
	  sprintf(str, "TODAY :%5ld kg",sum);
	  GLCD_string (0,6 ,str);
	  lcd_normal(); 
	 }
	 
	}

}


void zero_func2(void) // 0829
{
	char sT0[100];
	u8 i;
	long temp_buff;
	u8 exit_flag=0;
	long sum=0;
	
	sprintf(sT0, "v_zero1=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
	
	//091801
	
	lcd_clear();
	if(gnlLanguage==1)// korean
	{	
	GLCD_string (0, 2, " ���̷� 2");	
	GLCD_string (0, 4, " ���� ����    ?");
	}
		else
		{
    GLCD_string (0, 2, "SILO 2");			
	  GLCD_string (0, 4, " MAKE ZERO    ?");
	  }
	
	Delay_ms(2000);
	
	while(!exit_flag)
	{
		if(keypush_8510())
	{
		switch(KeyCode)
		{
			case  ENTER:
		   exit_flag=1;
		  break;
			case  UP: case  DOWN: case  LEFT: case  RIGHT:
			   retry_message();
         goto ZERO_FINISH;			
		  break;
      default:
       break;				
		}
	} // of keypuxh 
};	
// of silo2	

/*
    raw_data = read_filtered_adc_1();		// ad ���� �о�´٤�
		v_adc1_buf = (s32)(gnfFactor_2 * raw_data);	// count �� �Է�(���Կ� ����)
			v_i_value  =  v_adc1_buf - v_adc_org_2;	//���� ī��Ʈ ������ zero ������ ī��Ʈ���� ����. 
		
*/

	lcd_clear();
	 for(i=0;i<5;i++)
 {
   //temp_buff = read_filtered_adc_1();
	 if(which_adc==1) 
			{
				//temp_buff =read_filtered_adc_CS5555_1();
				temp_buff =read_filtered_adc_CS5555_2();
			}
		 else
		 { 
		  temp_buff = read_filtered_adc_1();
      //temp_buff_1 = read_filtered_adc_1();
	   }
 }
    v_adc_org_2=(long)(gnfFactor_2 * temp_buff);
		sprintf(sT0, "v_zero2=%6lu  comp=%6lu",(long)v_zero,(long)gplCompensationWeight);
		v_zero_2 = temp_buff;
		gplCompensationWeight2 = 0;
		v_zero_2 = EE_Write_val(ADR_v_zero_2, v_zero_2, 4);                   Delay_ms(10);
		v_adc_org_2 = EE_Write_val(ADR_v_adc_org_2, v_adc_org_2, 4);   Delay_ms(10);
		gplCompensationWeight2 = EE_Write_val(ADR_gplCompensationWeight2, gplCompensationWeight2, 4); Delay_ms(10);
		sprintf(sT0, "v_zero2=%6lu  comp=%6lu",(long)v_zero_2,(long)gplCompensationWeight2);
	 GLCD_string (0, 4, " ZERO FINISHED..");
   sign=0;
   sign_2=0;

 ZERO_FINISH:
 
 //0919
lcd_clear(); 
 
  /**************  Initial display *****************************/
 if(gnlSilo1Selection==1)// silo 1 enable  //0627
 {
   Silo_1_Weight_Display(); // silo 1  current weight, feed comsumption weight displaying  0627
	 lcd_inverse();
	  if(gnlLanguage==1)
	   sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal);
    else		
		sprintf(str, "TODAY: %5ld kg ", gnlDailyTotal);	
	 GLCD_string (0,6 ,str);
	 lcd_normal();

 }
 if(gnlSilo1Selection==2)//1205
 {
	 if(gnlLanguage==1)
	 { 
	 lcd_inverse(); 
   sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 lcd_normal();
	 sprintf(str, "���̷�1:%5ld kg", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "���̷�2:%5ld kg", gnlDailyTotal2);
	 GLCD_string (0,4 ,str);
	 lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "�� ��: %5ld kg",sum);
	 GLCD_string (0,6 ,str);
	 lcd_normal(); 
	 }
	else
	 { 
	 lcd_inverse(); 
   sprintf(str, "SILO:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 lcd_normal();
	 sprintf(str, "FEED1:%5ld kg", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "FEED2:%5ld kg", gnlDailyTotal2);
	 GLCD_string (0,4 ,str);
	 lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "TODAY: %5ld kg",sum);
	 GLCD_string (0,6 ,str);
	 lcd_normal(); 
	 }	
 
 }

}





 void Data_Send_Sms(char *tel_number)
 {
	char sT0[100];

	 //Data_Send_Sms(gtech_tel);
   // sprintf(sT0, "07-7-����:%5lu kg ����:%5lu kg ����:%5lu kg ", 	 //õ���̷ʳ��� 
    sprintf(sT0, "07-1-����:%5lu kg ����:%5lu kg ����:%5lu kg ",  //ȸ����� 

		                                    (long)gxlGrossWeight,
											(long)gnlDailyTotal,
											(long)gnlPreDailyTotal[1]
											);
    send_sms(tel_number ,sT0); Delay_ms(1000);  //����ũ����  ���ں����� 
  }

void test_set(void)	  // 0409
{
	char ch;
	char exit_flag=0;
	int	menu_display = 1;
	
	#define  GAP   30
	#define  START 100
	Delay_ms(1000);

	do {
		if ( menu_display) {
			menu_display = 0;

		}
		
		if (keypush())
		{
			menu_display = 1;

			ch=key_disp[KEYCODE];

			switch(ch)
			{
				case  KEY_3:
					cal_mode();
					break;
				case  KEY_1:
					test_mode();
					break;
				case  KEY_CLEAR:
					exit_flag = 1;
					break;
				case  KEY_PRINT:
					Data_Clear(); // ���ⷮ ��� "0" ���� �ʱ�ȭ 
					break;
				case  KEY_7:
					set_mode();
					break;
				case KEY_SET:
					set_mode_simple();
					break;
				default:
					menu_display = 0;
					retry_message();
					break;
			} // of switch
		} // of keypush()
	} while( !exit_flag);
}


void Data_Clear(void)//0908
{
	long password;
	int i;
	u8 exit_flag=0;
	union { u32 dw; u16 u[2]; u8 c[4];} temp;
		 
	lcd_clear(); // data clear
  /*	
	sprintf(str, "TODAY=%6lu ",(long)gnlDailyTotal);
  
	
	GLCD_string (0, 2, str); Delay_ms(500);
	for(i=0;i<7;i++)
	{
		sprintf(str, "%d  gnlPre=%6lu ",(int)i,(long)gnlPreDailyTotal[i]);
	}
	*/
 
 if(gnlLanguage==1) // korean
 { 
	lcd_inverse();
	GLCD_string (0, 0,"����Ÿ �����"); //Delay_ms(5000);
  lcd_normal();
	sprintf(str, "�����Ϸ�=%5lu",(long)gnuDay);
  GLCD_string (0, 2, str); //Delay_ms(5000);
	lcd_inverse();
	GLCD_string (0, 6, "Ȯ��Ű:�����");
	lcd_normal();
	// GLCD_string(0, 6, "ALL DAT");
 }
 else
  { 
	lcd_inverse();
	GLCD_string (0, 0,"DATA CLEAR"); //Delay_ms(5000);
  lcd_normal();
	sprintf(str, "DAYCOUNT=%5lu",(long)gnuDay);
  GLCD_string (0, 2, str); //Delay_ms(5000);
	GLCD_string (0, 4, "PRESS ENTER");
	 GLCD_string(0, 6, "ALL DATA !!");
 }
 
 
	while(!exit_flag)
	{
		 	if (keypush_8510()) // 0830
		{
			if(KeyCode==ENTER)
				exit_flag=1;
			}
	};

	
	lcd_clear();
 // GLCD_string (0, 0, "DATA CLEAR!");

	password=4070;
	if(password==4070)
	{
		gnuDay = 0;
		gnlDailyTotal = 0;
		gnlPreDailyTotal[0] = 0;
		gnlPreDailyTotal[1] = 0;
		gnlPreDailyTotal[2] = 0;
		gnlPreDailyTotal[3] = 0;
		gnlPreDailyTotal[4] = 0;
		gnlPreDailyTotal[5] = 0;
		gnlPreDailyTotal[6] = 0;

    gnuDay2 = 0;
		gnlDailyTotal2 = 0;
		gnlPreDailyTotal2[0] = 0;
		gnlPreDailyTotal2[1] = 0;
		gnlPreDailyTotal2[2] = 0;
		gnlPreDailyTotal2[3] = 0;
		gnlPreDailyTotal2[4] = 0;
		gnlPreDailyTotal2[5] = 0;
		gnlPreDailyTotal2[6] = 0;

		save_DailyTotals();

		Delay_ms(200);	


		FSMC_ENABLE;
		if(gnlLanguage==1) // korean
 { 
	lcd_inverse();
	GLCD_string (0, 0,"����Ÿ �����"); //Delay_ms(5000);
  lcd_normal();
	sprintf(str, "�����Ϸ�=%5lu",(long)gnuDay);
  GLCD_string (0, 2, str); //Delay_ms(5000);
	lcd_inverse();
	GLCD_string (0, 6, "����� �Ϸ�");
	lcd_normal();
	// GLCD_string(0, 6, "ALL DAT");
 }
 else
  { 
	lcd_inverse();
	GLCD_string (0, 0,"DATA CLEAR"); //Delay_ms(5000);
  lcd_normal();
	sprintf(str, "DAYCOUNT=%5lu",(long)gnuDay);
  GLCD_string (0, 2, str); //Delay_ms(5000);
	//GLCD_string (0, 4, "");
	 GLCD_string(0, 6, "END ..");
 }

    /*
		sprintf(str, "TODAY=%6lu ",(long)gnlDailyTotal);
		 GLCD_string (0, 2, str); //Delay_ms(5000);
		for(i=0;i<7;i++)
		{
			sprintf(str, "%d  gnlPre=%6lu ",(int)i,(long)gnlPreDailyTotal[i]);
		}

		sprintf(str, "day=%6lu ",(long)gnuDay);
		 GLCD_string (0, 4, str);  Delay_ms(5000);
	*/
	
	
	}
}


void Adc_Power_Off_On(void)
{
	if( !Adc_Counter)  // �ɼǺ���� ���� �����ð� ������ ������ �ɼǺ� ������ ������  ON/OFF �Ѵ� 
	{
		Adc_Power_Off();
		Delay_ms(1000);
		Adc_Power_On();
		Adc_Counter = OPTION_POWER_COUNTER;
	}
}


void logo(void)
{
	#define Y_AXIS_SPACE   50
	char str[20];

//POINT_COLOR = BLACK;
//BACK_COLOR = WHITE;

	//lcd70_show_string_mode_24x24(200, 100+(Y_AXIS_SPACE*1),"MODEL:GPI-8310", 16, 0);
	sprintf(str, "VERSION:%s", VERSION);
	//lcd70_show_string_mode_24x24(200, 100+(Y_AXIS_SPACE*2), str, 16, 0);
	//lcd70_show_string_mode_24x24(200, 100+(Y_AXIS_SPACE*3),"G-TECH INTERNATIONAL CO., ", 16, 0);
}

void mode_check(void)//0727
{
	char ch;
	
//	if (keypush())
	if(keypush_8510())
	{
		//ch=(keypush_8510());

		switch(KeyCode)
		{
			case  UP:
				test_mode();
				break;
			
			case  DOWN:
				//test_mode();
   			 
    	if(gnlSilo1Selection==2)// if 2 hopper selected
			{				
			 cal_display();
			 if(cal_selection==1)	
			   cal_mode();
			  else
					cal_mode_2();
		  }		
			else if(gnlSilo1Selection==1)// one hopper
			{
				cal_selection=1; 
				cal_mode();
			}	
				break;
		
     case  ENTER:
			 if(gnlSilo1Selection==1)//silo�� �Ѱ��̸� 
				   set_mode();
			   else //silo �� 2���̸� 
				  set_mode2();
		 
		     break;
		 
		case  RIGHT: // ���ⷮ ��� "0" ���� �ʱ�ȭ 
				Data_Clear();
				break;
		case  LEFT:
       Show_ToalOutput();
		     Initial_Display();			

			break;
		
   case  DOUBLE:
		  	 set_ip();
			   set_port();
		
	
    break;




		
			/*
			case  RIGHT: // ���ⷮ ��� "0" ���� �ʱ�ȭ 
				Data_Clear();
				break;
			case KEY_SET: test_set();
     */			

			break;
		} // of switch 
	}
}
   

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
#ifdef _____unused___________

void Get_Weight(void)
{
	
/////STST20160608
/**
DEBUG_puts("Get_Weight(void) -- TEST MODE");
Weight_flag = 1;
Real_Weight = 5300;
gxlGrossWeight = Real_Weight;
gxlWeight = gxlGrossWeight;

return;	
**/	

	
	//raw_data=Get_adc_from_module();  // ���κ��� a/d ���� �о�´�.
	
	//if(Weight_flag)// ���� ���� ���Ը� ���������� �޾�����  ���繫�Ը� ǥ���Ѵ�. 
	while( !Weight_flag)
	{
		raw_data = Get_adc_from_module_20170626();  // ���κ��� a/d ���� �о�´�.
		v_adc1_buf = (long)(gnfFactor * raw_data);
		
		//0116		   v_adc1_buf=1000;	 /////
		//0116		   v_adc_org=3000;	 ///// 0115
		
		diff1 = v_adc1_buf - v_adc_org;
		if(diff1<0)
		{
			diff1 = diff1*-1;
			sign_flag = 1;
		}
		else sign_flag=0;
		
		diff2 = v_adc1_buf - prev_adc1;	// for stable 
		// gxlWeight = ((diff1 + 10) / v_ei_multiply_factor) * v_division;
		gxlWeight = ((diff1) / v_ei_multiply_factor) * v_division;
		
		if(gnlDisplay)
		{
			sprintf(str, "diff1_1=%6lu ",(long)diff1);
	//		lcd70_show_string_mode(100, 300,str, 16, 0);
			
			sprintf(str, "v_adc_org_1=%6lu ",(long)v_adc_org);
	//		lcd70_show_string_mode(100, 330,str, 16, 0);

			sprintf(str, "gxlWeight_1=%6lu ",(long)gxlWeight);
	//		lcd70_show_string_mode(100, 360,str, 16, 0);
		}
		
		// �����̸� 
	//	if(gxlGrossWeight==0)
	//		sign_flag=0;
		if(sign_flag) gxlGrossWeight = gplCompensationWeight - gxlWeight;
		else 		  gxlGrossWeight = gplCompensationWeight + gxlWeight;
		
	//	gxlGrossWeight =  gxlWeight;
		
		
		if(Real_Weight_Factor != 10000)// ���Ժ��� factor�� �����Ǿ����� 
		{
			Real_Weight = (float)(((Real_Weight_Factor)/10000.0) * gxlGrossWeight);
			gxlGrossWeight = Real_Weight;
			//lcd70_write_weight(100,220,Real_Weight);// total weight displayin
		}
		
		if(gxlGrossWeight < (v_capacity+2000)) // ���繫�԰� v_capacity ���� ������ ���繫�Ը� ǥ���Ѵ�.
		{
			if(0 <= gxlGrossWeight) //2016.7.5
			{
	//			lcd70_write_weight(100,150,gxlGrossWeight);//  Big font total weight displayin
			}
		}
		
		
		/* 
		if(Real_Weight_Factor!=10000)// ���Ժ��� factor�� �����Ǿ����� 
		{
			(float)Real_Weight=(float)(((Real_Weight_Factor)/10000)*gxlGrossWeight);
			lcd70_write_weight(100,220,Real_Weight);// total weight displayin
		}
		*/
		
		//  Weight_flag=0;
	} //while( !Weight_flag) //  ���Ը� �о���� 
}
#endif	//#ifdef _____unused___________



void goto_iap(char *ip, u16 port)																 
{
	int ret_val;
	int retry = 0;
//	int iz;
	char szIP[20];
	
//	return;

//	NVIC_InitTypeDef NVIC_InitStructure;

	
	USART1_puts(" IN IAP ");

   	//2014.10.21
	////Send_to_Gtech_Event("FIRMWARE_UPDATE", "FAIL"); //�߻��� event�� �����Ѵ�.

	
	ret_val = SocketOpen(TMS_SERVER_IP, TMS_SERVER_PORT);
	if(ret_val != 1) return;
	
	
//2014.10.30	__disable_irq();

	TIM_Cmd(TIM1, DISABLE);
	TIM_Cmd(TIM2, DISABLE);
	TIM_Cmd(TIM3, DISABLE);

	//Disable USART1 Receive and Transmit interrupts 
  	USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
	//USART_ITConfig(USART1, USART_IT_TXE, ENABLE);

	//Disable USART2 Receive and Transmit interrupts 
	USART_ITConfig(USART2, USART_IT_RXNE, DISABLE);
	//USART_ITConfig(USART2, USART_IT_TXE, ENABLE);

	//Disable USART3 Receive and Transmit interrupts 
	USART_ITConfig(USART3, USART_IT_RXNE, DISABLE);
	//USART_ITConfig(USART3, USART_IT_TXE, ENABLE);
	USART_ITConfig(UART4, USART_IT_RXNE, DISABLE);

	//Disable the USART1 
	USART_Cmd(USART1, DISABLE);
	//Disable the USART2 
	USART_Cmd(USART2, DISABLE);
	//Disable the USART2 
	USART_Cmd(USART3, DISABLE);
	USART_Cmd(UART4, DISABLE);

	RTC_ITConfig(RTC_IT_SEC, DISABLE); // 2017.7.6 Disable the RTC Second

	//lcd70_clear_screen(WHITE);

//	lcd70_show_string_mode_24x24(0, 200,"��� ���׷��̵� �մϴ�.", 16, 0);
//	lcd70_show_string_mode_24x24(0, 250,"��ø� ��ٷ� �ֽʽÿ�.", 16, 0);

///	lcd70_show_string_mode(250, 200,"��� ���׷��̵� �մϴ�.", 16, 0);
///	lcd70_show_string_mode(250, 250,"��ø� ��ٷ� �ֽʽÿ�.", 16, 0);

//	lcd70_show_string_mode_24x24( 350, 150, "Upgrading.... ", 16, 0);	
//	lcd70_show_string_mode_24x24( 200, 250, "Wait a minute, and I'll be back soon.", 16, 0);	

//	Delay_ms(1000);

//	system_reset('T', 12345);

  	/* Set the Vector Table base location at 0x08000000 */ 
	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);  


	//iap flag
	USART1->BRR = 12345;

	JumpAddress = *(vu32*) (ApplicationAddress + 4);

    /* Jump to user application */
    Jump_To_Application = (pFunction) JumpAddress;
    /* Initialize user application's Stack Pointer */
	__MSR_MSP(*(vu32*) ApplicationAddress); 
    Jump_To_Application();
}


int test_get_cdma_time()
{
	char sT0[30];

	get_cdma_time();
	sprintf(sT0, "%04d-%02d-%02d %02d:%02d:%02d", jangbi.cdma.tm.year, jangbi.cdma.tm.month, jangbi.cdma.tm.date, jangbi.cdma.tm.hour, jangbi.cdma.tm.min, jangbi.cdma.tm.sec);
//	lcd70_show_string_mode(500, 10, (const u8 *)sT0, strlen(sT0), 0);

	return 0;
}		


#ifdef  USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif


void ZIGBEE_puts(char *str)
{
	UART4_puts(str);
}


//2000 ~ 2099 �����
#define	SECONDS_OF_HOUR	3600
int RTC_sec_to_time_conversion()
{	
	int ret_val = 0;
    u32 rtc_days;
    u32 THH, TMM, TSS;
	u32 TimeVar;
	// the beginning of each month
	u32 DaysToMonth[13] = { 0,31,59,90,120,151,181,212,243,273,304,334,365 };	
		  
	if(RTC_TimeUpdated)
	{
		ret_val = -1;
		RTC_TimeUpdated = 0;
		TimeVar = RTC_GetCounter();

/*		
RTC_BinaryToDate(RTC_GetCounter(),&system_datetime);

// ����ü�� �������� �ʸ� ����ϴ� ���

Sec = RTC_DateToBinary(&system_datetime);		
*/
		
		rtc_days = TimeVar / (SECONDS_OF_HOUR*24);
		
		rtc_year = rtc_days / 365;
		rtc_month = (rtc_days - (rtc_year*365)) / 30;
		rtc_date = (rtc_days - (rtc_year*365 + rtc_year/4 + 1)) - DaysToMonth[rtc_month];
		
		
		TimeVar = TimeVar % (24*SECONDS_OF_HOUR);
		rtc_hour = TimeVar / SECONDS_OF_HOUR;  /* Compute  hours */
		rtc_min = (TimeVar % SECONDS_OF_HOUR) / 60;  /* Compute minutes */
		rtc_sec = TimeVar % 60;  /* Compute seconds */
		
/////////STST		
//		rtc_date = rtc_hour/2;
		
		
		
//		sprintf(str, "Date:%04lu-%02lu-%02lu, Time:%02d:%02d:%02d, %lu", rtc_year, rtc_month, rtc_date, rtc_hour, rtc_min, rtc_sec, rtc_days);
///		sprintf(str, "Date:20%02lu-%02lu-%02lu, Time:%02d:%02d:%02d, %lu", rtc_year, rtc_month, rtc_date, rtc_hour, rtc_min, rtc_sec, rtc_days);
///		USART1_puts(str);
//		sprintf(sT0, "tel=%s,rssi= %d,Date=%04d-%02d-%02d Time=%02d:%02d:%02d",  jangbi.cdma.telno, jangbi.cdma.rssi,
//		jangbi.cdma.tm.year, jangbi.cdma.tm.month, jangbi.cdma.tm.date, jangbi.cdma.tm.hour, jangbi.cdma.tm.min, jangbi.cdma.tm.sec);
//lcd70_show_string_mode(420, 30, (const unsigned char *)str, 20, 0);
///lcd70_show_string_mode(170, 460, (const unsigned char *)str, 20, 0);
	}

	return ret_val;
}

//2000 ~ 2099 �����
int RTC_time_display()
{	
	sprintf(str, "Date:20%02lu-%02lu-%02lu, Time:%02d:%02d:%02d.", rtc_year, rtc_month, rtc_date, rtc_hour, rtc_min, rtc_sec);
//	lcd70_show_string_mode(170, 460, (const unsigned char *)str, 20, 0);
}


int CdmaSendQueue_puts(char *txt)
{
	int	ret_val = -1;

	CdmaSendQueue_qhead = ++CdmaSendQueue_qhead % MAX_CDMA_QUEUE_BUFFER;
	strncpy(CdmaSendQueue[CdmaSendQueue_qhead], txt, strlen(txt)+1);

USART1_puts(CdmaSendQueue[CdmaSendQueue_qhead]);

	return ret_val;
}

int CdmaSendQueue_gets()
{
	if (CdmaSendQueue_qhead == CdmaSendQueue_qtail)	return -1;	//queue empty
	
	CdmaSendQueue_qtail = ++CdmaSendQueue_qtail % MAX_CDMA_QUEUE_BUFFER;

//USART1_puts(CdmaSendQueue_queue[CdmaSendQueue_qtail]);

	return CdmaSendQueue_qtail;
}

//LTE MODEM reset and power on/off
void modem_power_reset(void)
{
	cdma_send_cmd("AT$LGTRESET", 11);	//2014.12.23   ���̹ٲ�� modem reset ���� 
	Delay_ms(1000);
	Cdma_Power_Off();
	Delay_ms(1000);
	Cdma_Power_On();
}

int get_weight()
{
	int ret_val = 0;
	long raw_adc;
	
// v1.9 2017.6.26	raw_adc = Get_adc_from_module_20160629();
	raw_adc = Get_adc_from_module_20170626();

	if(Weight_flag)// ���� ���� ���Ը� ���������� �޾�����  ���繫�Ը� ǥ���Ѵ�. 
	{
		ret_val = -1;
		Weight_flag = 0;
		
		v_adc1_buf = (long)(gnfFactor * raw_adc);
		diff1 = v_adc1_buf - v_adc_org;
//		diff2 = v_adc1_buf - prev_adc1;	// for stable 
		gxlWeight = ((diff1) / v_ei_multiply_factor) * v_division;
		
		if(gnlDisplay)
		{
			sprintf(str, "gxlWeight=%6ld ",(long)gxlWeight);
//			lcd70_show_string_mode(10, 360,str, 16, 0);
			sprintf(str, "diff1=%6ld ",(long)diff1);//
//			lcd70_show_string_mode(10, 300,str, 16, 0);
			sprintf(str, "v_adc_org=%6ld ",(long)v_adc_org);
//			lcd70_show_string_mode(10, 330,str, 16, 0);
		}

		gxlGrossWeight = gxlWeight + gplCompensationWeight;
		if(Real_Weight_Factor != 10000)// ���Ժ��� factor�� �����Ǿ����� 
		{
			gxlGrossWeight = (float)(((Real_Weight_Factor)/10000.0) * gxlGrossWeight);
		}

		//�Ѵ��� ������ ���߱�
		if(gxlGrossWeight < 0) gxlGrossWeight -= (long)(-gxlGrossWeight % v_division);
		else gxlGrossWeight -= ((long)gxlGrossWeight % v_division);
		
// 2016.7.25
		mon_raw_adc = raw_adc;
		
		mon_gxlGrossWeight = gxlGrossWeight;
		
		mon_One_Weight = One_Weight;
		mon_Two_Weight = Two_Weight;
		mon_Three_Weight = Three_Weight;
		mon_Four_Weight = Four_Weight;
		mon_Five_Weight = Five_Weight;
		mon_Six_Weight = Six_Weight;
		
		mon_One_Weight_Ok = One_Weight_Ok;
		mon_Two_Weight_Ok = Two_Weight_Ok;
		mon_Three_Weight_Ok = Three_Weight_Ok;
		mon_Four_Weight_Ok = Four_Weight_Ok;	
		mon_Five_Weight_Ok = Five_Weight_Ok;	
		mon_Six_Weight_Ok = Six_Weight_Ok;	


///STST			
//Send_to_server(SEND_STATUS, "status");
	}
	
	return ret_val;
}		


int get_weight_nowait()
{
	int	 ret_val = 0;
	int	 exit_flag = 0;
	long raw_adc, factored_adc;
	long diff, raw_weight, gross_weight;

//	rotation = 1;

//	do {
		raw_adc = Get_adc_from_module_20170626();

		if( Weight_flag)// ���κ��� ���Ը� ���������� �޾����� ���繫�Ը� ǥ���Ѵ�. 
		{
			Weight_flag = 0;
			ret_val = -1;

			factored_adc = (long)(gnfFactor * raw_adc);
			diff = factored_adc - v_adc_org;
//			diff2 = adc1_buf - prev_adc1;	// for stable 
			raw_weight = ((diff + (v_ei_multiply_factor/2)) / v_ei_multiply_factor) * v_division;

			// �������� �ݿ�
			gross_weight = raw_weight + gplCompensationWeight;

			// ���Ժ��� factor�� �����Ǿ����� 
			gross_weight = (float)(((Real_Weight_Factor)/10000.0) * gross_weight);

			//�Ѵ��� ������ ���߱�
			if(gross_weight < 0) gross_weight -= (long)(-gross_weight % v_division);
			else gross_weight -= ((long)gross_weight % v_division);

			if(gnlDisplay)
			{
				sprintf(str, "diff1=%6ld ",(long)diff1);
//				lcd70_show_string_mode(10, 330,str, 16, 0);
				sprintf(str, "v_adc_org=%6ld ",(long)v_adc_org);
//				lcd70_show_string_mode(10, 350,str, 16, 0);
				sprintf(str, "gxlWeight=%6ld, gxlGrossWeight=%ld ",(long)raw_weight, gross_weight);
//				lcd70_show_string_mode(10, 370,str, 16, 0);
			}

			
			gxiAdcFlag = 1;	// ad conversion end flag
			gxlRawAdc = raw_adc;	// raw adc value
			gxlSpanAdc = gxlRawAdc - v_zero; // gxlRawAdc - v_zero
			gxlPreAdc = gxlFactoredAdc;	// previous gxlFactoredAdc  : prev_adc1
			gxlFactoredAdc = factored_adc;	// gxlRawAdc * gnfFactor
			gxlCountAdc = diff;	// internal weight counter
			gxlRawWeight = raw_weight; // raw_span weight - not compensation
			gxlWeight = raw_weight;	// net weight
			gxlGrossWeight = gross_weight; // gross weight			

			
			mon_raw_adc = raw_adc;
			mon_gxlGrossWeight = gxlGrossWeight;
			
			mon_One_Weight = One_Weight;
			mon_Two_Weight = Two_Weight;
			mon_Three_Weight = Three_Weight;
			mon_Four_Weight = Four_Weight;
			mon_Five_Weight = Five_Weight;
			mon_Six_Weight = Six_Weight;
			
			mon_One_Weight_Ok = One_Weight_Ok;
			mon_Two_Weight_Ok = Two_Weight_Ok;
			mon_Three_Weight_Ok = Three_Weight_Ok;
			mon_Four_Weight_Ok = Four_Weight_Ok;	
			mon_Five_Weight_Ok = Five_Weight_Ok;	
			mon_Six_Weight_Ok = Six_Weight_Ok;	

	///STST			
	//Send_to_server(SEND_STATUS, "status");
		}
			
//	} while( !exit_flag);
	
	return ret_val;
}		





/******************************************************************************/


int get_weight_wait()
{
	int ret_val = 0;

	rotation = 1;	// scan start

	while( !get_weight_nowait());
	
	ret_val = -1;

	return ret_val;
}



/************** function of gpi-8510 ***********************/



void  Silo_1_Led_Operation()
{
	 if(Led_Mili_Counter>100)
	    Silo1_led_On();
	 if(Led_Mili_Counter>200)
	 {
		 Silo1_led_Off();
		 Led_Mili_Counter=0;
	 }
	 	
	
}

void  Silo_2_Led_Operation()
{
	 if(Led_Mili_Counter_2>100)
	    Silo2_led_On();
	 if(Led_Mili_Counter_2>200)
	 {
		 Silo2_led_Off();
		 Led_Mili_Counter_2=0;
	 }
}

void Error_1_Led_Operation()
{
	 if(Error_Led_Mili_Counter>50)
	     Silo1_Error_led_On();
	 if(Error_Led_Mili_Counter>100)
	 {
		  Silo1_Error_led_Off();
		 Error_Led_Mili_Counter=0;
	 }
}

void Error_2_Led_Operation()
{
	 if(Error_Led_Mili_Counter_2>50)
	     Silo2_Error_led_On();
	 if(Error_Led_Mili_Counter_2>100)
	 {
		  Silo2_Error_led_Off();
		 Error_Led_Mili_Counter_2=0;
	 }
}


void  Silo_1_Weight_Display() //0908  // 0627
{
	
	//lcd_initial();
 
 if(gnlLanguage==1) // korean
 { 

	if(Loadcell_Error1)
   	 GLCD_string ("�ε弿 ����");
	
  else//�����϶�	
  {  
	 sprintf(str, "�� ��: %5ld kg ", gxlWeight);
	 //  sprintf(str, ": %5ld kg ", gxlWeight);	
   	
		GLCD_string (0,0 ,str);
	} 
	lcd_inverse();	
  

	//sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal);
	// if(!working_flag)
   {		 
	   sprintf(str, "�� ��: %5ld kg ", gnlFeeding1);
  	 GLCD_string (0,2 ,str);
	 } 
	//sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal);
	//GLCD_string (0,6 ,str);

	 lcd_normal();	
 
	
	}//of if(gnlLanguage==1)
 
  else
 {
  if(Loadcell_Error1)
   	 GLCD_string ("LOAD_CELL ERROR!");
	 else
   {		 
   	sprintf(str, "SILO : %5ld kg ", gxlWeight);
  	GLCD_string (0,0 ,str);
   }	

	lcd_inverse();	
	//sprintf(str, "FEED : %5ld kg ", gnlDailyTotal);
	 sprintf(str, "FEED : %5ld kg ", gnlFeeding1);
	GLCD_string (0,2 ,str);
	 lcd_normal();	
 }
 
 
 

}	

void  Silo_2_Weight_Display()
{
	lcd_initial();
	sprintf(str, "SILO2: %5ld kg ", gxlWeight_2);
	GLCD_string (0,4 ,str);
	 lcd_inverse();	
	sprintf(str, "FEED2: %5ld kg ", gnlDailyTotal2);
	GLCD_string (0,6 ,str);
	 lcd_normal();	
}	
	


void cal_display(void)  //0907
{
	 u8 exit_flag=0;
//	 u8 select_flag;
	lcd_clear(); 
	GLCD_string (0,0 ,"CAL SELECT");
  lcd_inverse();
	GLCD_string (0,2 ,"SILO_1 CAL");
	lcd_normal();
  GLCD_string (0,4 ,"SILO_2 CAL");
  GLCD_string (0,6 ,"ENTER:NEXT");
	cal_selection=1; 

	do
	{
		
		if (keypush_8510()) // 0830
		{
			 //ch=key_disp[KEYCODE];   //0829
			
			switch(KeyCode)
			{
           case UP:	//1127
           cal_selection=1; 
					 GLCD_string (0,0 ,"CAL SELECT");
          lcd_inverse();
	       GLCD_string (0,2 ,"SILO_1 CAL");
	       lcd_normal();
         GLCD_string (0,4 ,"SILO_2 CAL");
	          break;
					 
					 case DOWN:
				cal_selection=2; 
			   GLCD_string (0,2 ,"SILO_1 CAL");
         	lcd_inverse();
	    		GLCD_string (0,4 ,"SILO_2 CAL");
	       lcd_normal();
         
						 break;
           case ENTER:
						  exit_flag=1;
						 break;
					 default: 
						 break;
        	
			}//of switch
		
	
	//cal_mode();
//	cal_mode_2();
		} //of if 	
	} while( !exit_flag);
	
}






void Silo_1_Getweight(void) //1211
{
/**************** �����о ǥ�� silo_1 ******************************/
		//raw_data = read_filtered_adc();		// ad ���� �о�´�.
	 if(which_adc==1) 
			{
				raw_data =read_filtered_adc_CS5555_1();
				//temp_buff_1 =read_filtered_adc_CS5555_2();
			}
		 else
		 { 
		  raw_data = read_filtered_adc();
      //temp_buff_1 = read_filtered_adc_1();
	   }
	  if(raw_data>400000)
			Loadcell_Error1=1;
		else
			Loadcell_Error1=0;
	
		v_adc1_buf = (s32)(gnfFactor * raw_data);	// count �� �Է�(���Կ� ����)
			v_i_value  =  v_adc1_buf - v_adc_org;	//���� ī��Ʈ ������ zero ������ ī��Ʈ���� ����. 
		
			if(Real_Weight_Factor != 10000)// ���Ժ��� factor�� �����Ǿ����� 
		{
			Real_Weight = (float)(((Real_Weight_Factor)/10000.0) * v_i_value);
			v_i_value = Real_Weight;
			//lcd70_write_weight(100,220,Real_Weight);// total weight displayin
		}
		if (0 <= v_i_value)   //0828
		{
			gxlGrossWeight = (v_i_value + (v_ei_multiply_factor/2));  // 10000+(10/2)=10005
			gxlGrossWeight=(gxlGrossWeight / v_ei_multiply_factor);	//10005/10=1000
			gxlGrossWeight=gxlGrossWeight * v_division;					//1000*5=5000
  		sign=0;
		}
		else  
		{
 			sign=1;
			v_i_value=v_i_value*-1;
			gxlGrossWeight = (v_i_value + (v_ei_multiply_factor/2));
			gxlGrossWeight=(gxlGrossWeight / v_ei_multiply_factor);
			gxlGrossWeight=gxlGrossWeight * v_division;
		  if(gxlGrossWeight==0)
			sign=0;	
		
		}

	//	 if(gxlGrossWeight>=0  &&gxlGrossWeight<=v_capacity)
	
   if (!gplCompensationWeight) gxlWeight = gxlGrossWeight;      // ���󹫰� ó�� 
    else 
		{
     if(!sign)			
		 gxlWeight = gxlGrossWeight + gplCompensationWeight;
		 else
		  gxlWeight = gplCompensationWeight-gxlGrossWeight;
		
   	 if(gxlWeight>=0)
		  sign=0;
		 else
		 {
			 gxlWeight=gxlWeight*-1; 
			 sign=1;
		
     }
		}	
			
		
	}
		
	void Silo_2_Getweight(void)
	{
	/**************** �����о ǥ�� silo_2 ******************************/
		//raw_data = read_filtered_adc_1();		// ad ���� �о�´٤�
    if(which_adc==1) 
			{
				//temp_buff =read_filtered_adc_CS5555_1();
				raw_data =read_filtered_adc_CS5555_2();
			}
		 else
		 { 
		  //temp_buff = read_filtered_adc();
      raw_data = read_filtered_adc_1();
	   }	



		if(raw_data>400000)
			Loadcell_Error2=1;
		else
			Loadcell_Error2=0;
	
		
		
		
		v_adc1_buf = (s32)(gnfFactor_2 * raw_data);	// count �� �Է�(���Կ� ����)
			v_i_value  =  v_adc1_buf - v_adc_org_2;	//���� ī��Ʈ ������ zero ������ ī��Ʈ���� ����. 
		
			if(Real_Weight_Factor2 != 10000)// ���Ժ��� factor�� �����Ǿ����� 
		{
			Real_Weight = (float)(((Real_Weight_Factor)/10000.0) * v_i_value);
			v_i_value = Real_Weight;
			//lcd70_write_weight(100,220,Real_Weight);// total weight displayin
		}
		if (0 <= v_i_value)   //0828
		{
			gxlGrossWeight_2 = (v_i_value + (v_ei_multiply_factor/2));  // 10000+(10/2)=10005
			gxlGrossWeight_2=(gxlGrossWeight_2 / v_ei_multiply_factor);	//10005/10=1000
			gxlGrossWeight_2=gxlGrossWeight_2 * v_division_2;					//1000*5=5000
  		sign_2=0;
		}
		else  
		{
 			sign_2=1;
			v_i_value=v_i_value*-1;
			gxlGrossWeight_2 = (v_i_value + (v_ei_multiply_factor/2));
			gxlGrossWeight_2=(gxlGrossWeight_2 / v_ei_multiply_factor);
			gxlGrossWeight_2=gxlGrossWeight_2 * v_division_2;
			if(gxlGrossWeight_2==0)
			sign_2=0;	
		}

	//	 if(gxlGrossWeight>=0  &&gxlGrossWeight<=v_capacity)
	
   if (!gplCompensationWeight2) gxlWeight_2 = gxlGrossWeight_2;      // ���󹫰� ó�� 
   else
		{
     if(!sign_2)			
		 gxlWeight_2 = gxlGrossWeight_2 + gplCompensationWeight2;
		 else
		  gxlWeight_2 = gplCompensationWeight2-gxlGrossWeight_2;
		
		if(gxlWeight_2>=0)
		  sign_2=0;
		 else
		 { 
			 sign_2=1;
		   gxlWeight_2=gxlWeight_2*-1;
		 
		 }
		}	


		
		
	}
/*
		if(Real_Weight_Factor != 10000)// ���Ժ��� factor�� �����Ǿ����� 
		{
			Real_Weight = (float)(((Real_Weight_Factor)/10000.0) * gxlWeight);
			gxlWeight = Real_Weight;
			//lcd70_write_weight(100,220,Real_Weight);// total weight displayin
		}
*/
	
/*
	
	#define	 RTC_CLOCK_HIGH   GPIO_SetBits(GPIOB, GPIO_Pin_5)
  #define	 RTC_CLOCK_LOW  	GPIO_ResetBits(GPIOB, GPIO_Pin_5)
  #define	 RTC_RESET_HIGH   GPIO_SetBits(GPIOB, GPIO_Pin_9)
  #define	 RTC_RESET_LOW  	GPIO_ResetBits(GPIOB, GPIO_Pin_9)
  #define	 RTC_DATA_HIGH   GPIO_SetBits(GPIOB, GPIO_Pin_8)
  #define	 RTC_DATA_LOW  	GPIO_ResetBits(GPIOB, GPIO_Pin_8)
	
	*/
	
#define  TIME_DLEAY 5
	
	void WriteByte(unsigned char Data)   
{   
  unsigned i; 
  Rtc_Write();// data portstatus : output  
  for(i = 0; i < 8; i++)   
  {   
  // SCLK_0;
   RTC_CLOCK_LOW; // clock high		
   if(Data & 0x01)   
   RTC_DATA_HIGH;   
   else  
   RTC_DATA_LOW;	

   Delay(TIME_DLEAY);
	 
	 
	 RTC_CLOCK_HIGH; Delay(TIME_DLEAY);
   Data <<= 1;   
  }
   RTC_CLOCK_LOW; Delay(TIME_DLEAY);		 
   
}   

unsigned char ReadByte()   
{   
  unsigned i, Data = 0;   
  Rtc_Read();	// data port status : input
  RTC_CLOCK_LOW;	
 
	for(i = 0; i < 8; i++)   
  {   
   RTC_CLOCK_HIGH;	Delay(TIME_DLEAY);	
  	if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) == 0x01)
           Data += 0x80;   
   else   
           Data += 0x00;   
  RTC_CLOCK_LOW;	Delay(TIME_DLEAY);
   Data >>= 1; Delay(TIME_DLEAY);  
  }   
  return Data;   
}   


unsigned char Get_Second()   
{   
 unsigned Second;   
 RTC_RESET_LOW; Delay(TIME_DLEAY);  
 RTC_RESET_HIGH;  Delay(TIME_DLEAY) ;
 WriteByte(GetSecond);   
 Second = ReadByte();   
 RTC_RESET_LOW;  Delay(TIME_DLEAY);
 return Second;   
}   

/*
#define PCPORT         GPIOB 
#define DS7_SCLK   GPIO_PIN_5 //DS1302?? 
#define DS6_IO    GPIO_PIN_8 // DS1302 ?�� 
#define DS5_RST   GPIO_PIN_9 //DS1302��?/?�� 
*/

#ifdef dpfpd

void Clock_Pin_Init(void) 
{ 
   // GPIO_Init_TypeDef GPIO_InitStructure; 
	  EXTI_InitTypeDef EXTI_InitStructure;
  	GPIO_InitTypeDef GPIO_InitStructure;

	
	
	
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //_LOW_SLOW; 
    GPIO_InitStructure.GPIO_Pin = DS7_SCLK; 
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(PBPORT, &GPIO_InitStructure); 
    
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;//_LOW_FAST;//GPIO_MODE_OUT_OD_HIZ_FAST ; 
    GPIO_InitStructure.GPIO_Pin = DS6_IO; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	  GPIO_Init(PBPORT, &GPIO_InitStructure); 
     
    
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//_LOW_SLOW; 
    GPIO_InitStructure.GPIO_Pin = DS5_RST; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_Init(PBPORT, &GPIO_InitStructure); 
	
	


}


#define DATA_DELAY 10



void W8bit_HT1381(u8 wrdata) 
{ 
    u8 i; 
	Rtc_Write(); // 1201
  for(i=0; i<8; i++) 
  { 
        if(wrdata&0x01){GPIO_SetBits(PBPORT,DS6_IO );} 
        else{GPIO_ResetBits(PBPORT,DS6_IO );} 
        Delay(DATA_DELAY); 
        GPIO_SetBits(PBPORT,DS7_SCLK);         
      Delay(DATA_DELAY); 
        GPIO_ResetBits(PBPORT,DS7_SCLK); 
        Delay(DATA_DELAY); 
        wrdata >>= 1; 
  } 
} 
u8 R8bit_HT1381(void) 
{ 
    u8 i,rddata=0; 
    GPIO_SetBits(PBPORT,DS6_IO );
   Rtc_Read();	
  for(i=0; i<8; i++) 
  { 
        rddata >>=1; 
        Delay(DATA_DELAY); 
       // if ((GPIO_ReadInputData(PBPORT) & DS6_IO) != (u8)0x00) 
		if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8) != 0x00)
        { rddata |=0x80; } 
        GPIO_SetBits(PBPORT,DS7_SCLK);         
      Delay(DATA_DELAY); 
        GPIO_ResetBits(PBPORT,DS7_SCLK); 
        Delay(DATA_DELAY); 
         
  } 
  return(rddata); 
}

	void Write1381(u8 Addr, u8 Wdata) 
{ 
    GPIO_ResetBits(PBPORT,DS5_RST); 
    Delay(DATA_DELAY); 
    GPIO_ResetBits(PBPORT,DS7_SCLK); 
    Delay(DATA_DELAY); 
    
	  GPIO_SetBits(PBPORT,DS5_RST); 
    W8bit_HT1381(Addr); 
    W8bit_HT1381(Wdata); 
    GPIO_SetBits(PBPORT,DS7_SCLK); 
    Delay(DATA_DELAY); 
    GPIO_ResetBits(PBPORT,DS7_SCLK); 
    Delay(DATA_DELAY); 
    GPIO_ResetBits(PBPORT,DS5_RST); 
} 
u8 Read1381(u8 Addr) 
{ 
    u8 rddata; 
    GPIO_ResetBits(PBPORT,DS5_RST); 
    Delay(DATA_DELAY); 
    GPIO_ResetBits(PBPORT,DS7_SCLK); 
    Delay(DATA_DELAY); 
   
	 GPIO_SetBits(PBPORT,DS5_RST); 
    Delay(DATA_DELAY); 
    W8bit_HT1381(Addr); 
    rddata = R8bit_HT1381(); 
    Delay(DATA_DELAY); 
    GPIO_SetBits(PBPORT,DS7_SCLK);         
    Delay(DATA_DELAY); 
    GPIO_ResetBits(PBPORT,DS7_SCLK); 
    Delay(DATA_DELAY); 
    GPIO_ResetBits(PBPORT,DS5_RST); 
  return(rddata); 
} 

void Set1381(u8 *pSecDa) 
{ 
    u8 i; 
    u8 Addr = 0x80; 
    Write1381(0x8e,0x00); /* ���٤ֵ,WP=0,?����?*/ 
    for(i =7;i>0;i--) 
    { 
        Write1381(Addr,*pSecDa); /* �� �� ? �� �� ��Ѣ Ҵ */ 

        pSecDa++; 
        Addr +=2; 
    } 
    Write1381(0x8e,0x80); /* ���٤ֵ,WP=1,?��??*/ 
} 
/******************************************************************** 
* 
* ٣?: v_Get1381 
* ?٥: 
* ����: ?��HT1381?��?? 
* ?��: uc_R1381() 
* ?��: ucCurtime: ����?��??�򣡣?��??̫��?: �� �� ? �� �� ��Ѣ Ҵ 
* 7Byte (BCD?) 1B 1B 1B 1B 1B 1B 1B 
* ����?: �� 
***********************************************************************/ 
void Get1381(void) 
{ 
    u8 i; 
    u8 Addr = 0x81; 
    for (i=0;i<7;i++) 
    { 
        Gettimebuf[i] = Read1381(Addr);/*̫��?: �� �� ? �� �� 
        ��Ѣ Ҵ */ 
        Addr += 2; 
    } 
} 

	#endif
	
	


void Date_Time_Display(void)
{
  
	Get1381(); 
	sprintf(str, "date:20%02x-%02X-%02X  time:%02x-%02X-%02X ", Gettimebuf[6],Gettimebuf[4],Gettimebuf[3],Gettimebuf[2],Gettimebuf[1],Gettimebuf[0]);	USART1_puts(str);
  if(gnlLanguage==1)
	{	
	 GLCD_string (0,0 ,"���糯¥");
   sprintf(str, "20%02x��%02X��%02X��", Gettimebuf[6],Gettimebuf[4],Gettimebuf[3]);	
	 lcd_inverse();
 	 GLCD_string (0,2 ,str);
   lcd_normal();	 
   GLCD_string (0,4 ,"����ð�");
   lcd_inverse();
	 sprintf(str, "%02x��%02X��%02X��", Gettimebuf[2],Gettimebuf[1],Gettimebuf[0]);	
   GLCD_string (0,6 ,str);
	 lcd_normal();
	}
else
		
	{	
	GLCD_string (0,0 ,"    DATE        ");
  sprintf(str, "  20%02x-%02X-%02X    ", Gettimebuf[6],Gettimebuf[4],Gettimebuf[3]);	
	lcd_inverse();
	GLCD_string (0,2 ,str);
  lcd_normal();	 
  GLCD_string (0,4 ,"    TIME        ");
  lcd_inverse();
	sprintf(str, "  %02x-%02X-%02X      ", Gettimebuf[2],Gettimebuf[1],Gettimebuf[0]);	
  GLCD_string (0,6 ,str);
	 lcd_normal();
	}
		Delay_ms(1000);
}



void Show_ToalOutput(void)//�������ⷮ
{
	
	
	long password;
	int i;
	u8 exit_flag=0;
	union { u32 dw; u16 u[2]; u8 c[4];} temp;
	u8 clear_counter=0;
		 
	lcd_clear(); // data clear
  
 if(gnlLanguage==1) // korean
 { 
	lcd_inverse();
	GLCD_string (0, 0," �Ѵ��� ���ⷮ"); //Delay_ms(5000);
  lcd_normal();
	sprintf(str, "��=%9lu kg",(long)gxhTotalOutput); // �Ѵ������ⷮ ǥ��
  GLCD_string (0, 2, str); //Delay_ms(5000);
	
	 
	 lcd_inverse();
	GLCD_string (0, 4, "�����:�Ʒ�Ű3��");
	lcd_normal();
	 GLCD_string (0, 6, "������:Ȯ��Ű");
	// GLCD_string(0, 6, "ALL DAT");
 }
 //1202
 
	while(!exit_flag)
	{
		 	if (keypush_8510()) // 0830
		{
		       switch(KeyCode)
			 {
						 case UP:case LEFT: case RIGHT:
							  clear_counter=0;
						     break;
						 case DOWN:
               clear_counter++;
						   if(clear_counter==3)
								  exit_flag=1;
               break;						 
	           case ENTER:
            		  exit_flag=1;
               break;						 
	 		 } // of switch
		 }// of keypush 
	};

  if(clear_counter==3) //1202
	{
		lcd_inverse();
	GLCD_string (0, 0," �Ѵ��� �����"); //Delay_ms(5000);
  lcd_normal();
		
	gxhTotalOutput=0; 	
		gxhTotalOutput = EE_Write_val(ADR_gxhTotalOutput, gxhTotalOutput, 4); Delay_ms(100);
		
	sprintf(str, "��=%9lu kg",(long)gxhTotalOutput); // �Ѵ������ⷮ ǥ��
  GLCD_string (0, 2, str); Delay_ms(2000);
		
	}	



	
	lcd_clear();

}

void Initial_Display(void)
{
	long  sum;
 /**************  Initial display *****************************/
 if(gnlSilo1Selection==1)// silo  NUMBER ==1
 {
	 SendtoPc();
   Silo_1_Weight_Display(); // silo 1  current weight, feed comsumption weight displaying 
	 SendtoPc();
	 lcd_inverse();
	 if(gnlLanguage==1) // korean 
	 sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 else
	 sprintf(str, "TODAY: %5ld kg ", gnlDailyTotal);
	 
	 GLCD_string (0,6 ,str);
	 lcd_normal();

 }
else // silo number is 2  20171019
 {
	if(gnlLanguage==1)
  {		
	 lcd_inverse(); 
   sprintf(str, "����:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 lcd_normal();
    /*	
		sprintf(str, "���̷�1:%5ld kg", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "���̷�2:%5ld kg", gnlDailyTotal2);
	 GLCD_string (0,4 ,str);
		*/
   //ver 2.8
		sprintf(str, "���̷�1:%5ld kg", gnlFeeding1);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "���̷�2:%5ld kg", gnlFeeding2);
	 GLCD_string (0,4 ,str);



		lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "�� ��: %5ld kg",sum);
 //sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 GLCD_string (0,6 ,str);
	 lcd_normal();
	}
	else
   {		
	 lcd_inverse(); 
   sprintf(str, "SILO:%5ld-%5ld", gxlWeight,gxlWeight_2);
	 GLCD_string (0,0 ,str);
	 lcd_normal();
	 sprintf(str, "FEED1:%5ld kg", gnlDailyTotal);
	 GLCD_string (0,2 ,str);
	 sprintf(str, "FEED2:%5ld kg", gnlDailyTotal2);
	 GLCD_string (0,4 ,str);
	 lcd_inverse();
	 sum=gnlDailyTotal+gnlDailyTotal2;
	 sprintf(str, "TODAY: %5ld kg",sum);
 //sprintf(str, "�� ��: %5ld kg ", gnlDailyTotal); 
	 GLCD_string (0,6 ,str);
	 lcd_normal();
	}
 }
}
 /**************  Initial display *****************************/

void set_ip()
{
	int i;
	char loc=0;
	int  count;
	int  blink;
	unsigned char	digit_max[6] = { 9, 9, 1, 9, 3, 9 };
	unsigned char	exit_flag =0;
	unsigned char	curr_num = 0;
	char			tbuf[6];
	char  serverip[15];
	char			year, month, date;
	char  str[50];
	lcd_normal();
	lcd_clear();
	lcd_normal();
	if(gnlLanguage==1)//����
	GLCD_string (0,0 ," IP ���� ");
	else
	GLCD_string (0,0 ," IP SETTING");
	Delay_ms(1500);
	
	
	/*
	
	tbuf[0] = Gettimebuf[6] / 16;
	tbuf[1] = Gettimebuf[6] % 16;
	tbuf[2] = Gettimebuf[4] / 16;
	tbuf[3] = Gettimebuf[4] % 16;
	tbuf[4] = Gettimebuf[3] / 16;
	tbuf[5] = Gettimebuf[3] % 16;

  sprintf(str, "20%1x%1x-%1x%1x-%1x%1x",tbuf[0],tbuf[1],tbuf[2],tbuf[3],tbuf[4],tbuf[5] );	
	GLCD_string (0,4 ,str);
 */
	
	serverip[0]=IpAdresss_1/100;
	serverip[1]=(IpAdresss_1%100)/10;
	serverip[2]=(IpAdresss_1%100)%10;
	
	serverip[3]=IpAdresss_2/100;
	serverip[4]=(IpAdresss_2%100)/10;
	serverip[5]=(IpAdresss_2%100)%10;
	
	serverip[6]=IpAdresss_3/100;
	serverip[7]=(IpAdresss_3%100)/10;
	serverip[8]=(IpAdresss_3%100)%10;
	
	serverip[9]=IpAdresss_4/100;
	serverip[10]=(IpAdresss_4%100)/10;
	serverip[11]=(IpAdresss_4%100)%10;
	
  //sprintf(str, "%c%c%c.%c%c%c.%c%c%c.%c%c%c",serverip[0],serverip[1],serverip[2],serverip[3],serverip[4],serverip[5],serverip[6],serverip[7],serverip[8],serverip[9],serverip[10],serverip[11] );	
	sprintf(str, "%d%d%d.%d%d%d.%d%d%d.%d%d%d",serverip[0],serverip[1],serverip[2],serverip[3],serverip[4],serverip[5],serverip[6],serverip[7],serverip[8],serverip[9],serverip[10],serverip[11] );	
	
	GLCD_string (0,4 ,str);
	
	
	loc = 0;
	blink=2000;
	do
	{
		blink++;
		if(blink==3500)
		{lcd_normal();
		 switch(loc)
		 {
			 case 0:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (0,4 ,str); 			 
       break;			 
	     case 1:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (1,4 ,str); 			 
       break;			 
			 case 2:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (2,4 ,str); 			 
       break;			 
			 case 3:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (4,4 ,str); 			 
       break;			 
			 case 4:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (5,4 ,str); 			 
       break;			 
			 case 5:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (6,4 ,str); 			 
        break;			 
			 
			 case 6:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (8,4 ,str); 			 
        break;			 
			 case 7:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (9,4 ,str); 			 
        break;			 
			 case 8:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (10,4 ,str); 			 
        break;			 
			 
			 case 9:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (12,4 ,str); 			 
        break;			 
			 case 10:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (13,4 ,str); 			 
        break;			 
			 case 11:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (14,4 ,str); 			 
        break;			 
			 
			 default: break; 
		 }	//of switch 
			
		}

    else if(blink>7000)
		{
    blink=0;
		lcd_inverse();
			switch(loc)
		 {
		   case 0:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (0,4 ,str); 			 
       break;			 
	     case 1:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (1,4 ,str); 			 
       break;			 
			 case 2:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (2,4 ,str); 			 
       break;			 
			 case 3:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (4,4 ,str); 			 
       break;			 
			 case 4:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (5,4 ,str); 			 
       break;			 
			 case 5:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (6,4 ,str); 			 
        break;			 
			 
			 case 6:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (8,4 ,str); 			 
        break;			 
			 case 7:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (9,4 ,str); 			 
        break;			 
			 case 8:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (10,4 ,str); 			 
        break;			 
			 
			 case 9:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (12,4 ,str); 			 
        break;			 
			 case 10:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (13,4 ,str); 			 
        break;			 
			 case 11:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (14,4 ,str); 			 
        break;			 
			 
			 default: break; 
			 
			 
		 }	//of switch 
     lcd_normal();			


    }			
		
		if (keypush_8510()) // 0830
		{
			
			switch(KeyCode) //99�� 12�� 31�� 
			{
				case UP:
					serverip[loc]++;
				 if(serverip[loc]>9)
				   {
				   serverip[loc]=9;
						retry_message(); 
			     }
					/*
					tbuf[loc]++;
				 if(loc==0 |loc==1|loc==5 )
         {					 
				 if(tbuf[loc]>9)
				   {
				   tbuf[loc]=9;
						retry_message(); 
			     }
				 }
         if(loc==2)
				 {
			    	if(tbuf[loc]>1)
						{
						retry_message();
						 tbuf[loc]=1;
						}
				 }	 
				 if(loc==3 )
				 {
			    	if(tbuf[loc]>2)
						{
						retry_message();
						 tbuf[loc]=2;
						}
				 }
				 if(loc==4 )
				 {
			    	if(tbuf[loc]>3)
						{
						retry_message();
						 tbuf[loc]=3;
						}
				 }
				 */
					break;
				
        case DOWN:
					if(serverip[loc]!=0) 
					serverip[loc]--;
					else
						retry_message();
				  break;
				
				case LEFT:
					Delay_ms(1);
				  break;
				case RIGHT:
					 loc++;
				   if(loc>=12)
						  loc=0;
				  break;
				case ENTER:
					exit_flag=1;
				  break;
				default: break;
			} // of switch 
			
			
			//sprintf(str, "20%1x%1x-%1x%1x-%1x%1x",tbuf[0],tbuf[1],tbuf[2],tbuf[3],tbuf[4],tbuf[5] );	
			sprintf(str, "%d%d%d.%d%d%d.%d%d%d.%d%d%d",serverip[0],serverip[1],serverip[2],serverip[3],serverip[4],serverip[5],serverip[6],serverip[7],serverip[8],serverip[9],serverip[10],serverip[11] );	
	    GLCD_string (0,4 ,str);

		}// of keypush	
	} while (!exit_flag);
	
	
	/*
	IpAdresss_1=((serverip[0]-0x30)*100)+((serverip[1]-0x30)*10)+(serverip[2]-0x30);
	IpAdresss_2=((serverip[3]-0x30)*100)+((serverip[4]-0x30)*10)+(serverip[5]-0x30);
	IpAdresss_3=((serverip[6]-0x30)*100)+((serverip[7]-0x30)*10)+(serverip[8]-0x30);
	IpAdresss_4=((serverip[9]-0x30)*100)+((serverip[10]-0x30)*10)+(serverip[11]-0x30);
	*/

  IpAdresss_1=((serverip[0])*100)+((serverip[1])*10)+(serverip[2]);
	IpAdresss_2=((serverip[3])*100)+((serverip[4])*10)+(serverip[5]);
	IpAdresss_3=((serverip[6])*100)+((serverip[7])*10)+(serverip[8]);
	IpAdresss_4=((serverip[9])*100)+((serverip[10])*10)+(serverip[11]);
	

	IpAdresss_1 = EE_Write_val(ADR_IpAdresss_1, IpAdresss_1, 4); Delay_ms(10);
 IpAdresss_2 = EE_Write_val(ADR_IpAdresss_2, IpAdresss_2, 4); Delay_ms(10);
 IpAdresss_3 = EE_Write_val(ADR_IpAdresss_3, IpAdresss_3, 4); Delay_ms(10);
 IpAdresss_4 = EE_Write_val(ADR_IpAdresss_4, IpAdresss_4, 4); Delay_ms(10);

	
	
	
	
	
	 /* 
   	Settimebuf[6] =tbuf[0]*16+tbuf[1]; //Ҵ 
    Settimebuf[4] =tbuf[2]*16+tbuf[3]; 0x12; //�� 
 	  Settimebuf[3] =tbuf[4]*16+tbuf[5]; 0x01; //�� 
    Settimebuf[2] =Gettimebuf[2]; //? 
    Settimebuf[1] =Gettimebuf[1]; //�� 
    Settimebuf[0] =Gettimebuf[0];//�� 
		Set1381(Settimebuf);//setting current data & time  
	*/


	
} /* of set_date */

void set_port()
{
	int i;
	char loc=0;
	int  count;
	int  blink;
	unsigned char	digit_max[6] = { 9, 9, 1, 9, 3, 9 };
	unsigned char	exit_flag =0;
	unsigned char	curr_num = 0;
	char			tbuf[6];
	char  serverip[15];
	char			year, month, date;
	char  str[50];
	lcd_normal();
	lcd_clear();
	lcd_normal();
	if(gnlLanguage==1)//����
	GLCD_string (0,0 ," ��Ʈ ���� ");
	else
	GLCD_string (0,0 ," PORT SETTING");
	
	//IpPort=1491;
	//12345
	serverip[0]=IpPort/10000;
	serverip[1]=(IpPort%10000)/1000;
	serverip[2]=((IpPort%10000)%1000)/100;
	serverip[3]=(((IpPort%10000)%1000)%100)/10;
	serverip[4]=(((IpPort%10000)%1000)%100)%10;
	
	
	sprintf(str, "%d%d%d%d%d",serverip[0],serverip[1],serverip[2],serverip[3],serverip[4] );	
	
	GLCD_string (0,4 ,str);
	
	
	loc = 0;
	blink=2000;
	do
	{
		blink++;
		if(blink==3500)
		{lcd_normal();
		 switch(loc)
		 {
			 case 0:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (0,4 ,str); 			 
       break;			 
	     case 1:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (1,4 ,str); 			 
       break;			 
			 case 2:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (2,4 ,str); 			 
       break;			 
			 case 3:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (3,4 ,str); 			 
       break;			 
			 case 4:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (4,4 ,str); 			 
       break;			 
			 
			 default: break; 
		 }	//of switch 
			
		}

    else if(blink>7000)
		{
    blink=0;
		lcd_inverse();
			switch(loc)
		 {
		   case 0:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (0,4 ,str); 			 
       break;			 
	     case 1:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (1,4 ,str); 			 
       break;			 
			 case 2:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (2,4 ,str); 			 
       break;			 
			 case 3:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (3,4 ,str); 			 
       break;			 
			 case 4:
				 sprintf(str, "%1d",serverip[loc]); // A/D��
         GLCD_string (4,4 ,str); 			 
       break;			 
			 default: break; 
			 
			 
		 }	//of switch 
     lcd_normal();			


    }			
		
		if (keypush_8510()) // 0830
		{
			
			switch(KeyCode) //99�� 12�� 31�� 
			{
				case UP:
					serverip[loc]++;
				 if(serverip[loc]>9)
				   {
				   serverip[loc]=9;
						retry_message(); 
			     }
					break;
				
        case DOWN:
					if(serverip[loc]!=0) 
					serverip[loc]--;
					else
						retry_message();
				  break;
				
				case LEFT:
					Delay_ms(1);
				  break;
				case RIGHT:
					 loc++;
				   if(loc>=5)
						  loc=0;
				  break;
				case ENTER:
					exit_flag=1;
				  break;
				default: break;
			} // of switch 
			
			
			//sprintf(str, "20%1x%1x-%1x%1x-%1x%1x",tbuf[0],tbuf[1],tbuf[2],tbuf[3],tbuf[4],tbuf[5] );	
			sprintf(str, "%d%d%d%d%d",serverip[0],serverip[1],serverip[2],serverip[3],serverip[4] );	
	    GLCD_string (0,4 ,str);

		}// of keypush	
	} while (!exit_flag);
	
	
	
	//IpPort=((serverip[0]-0x30)*10000)+((serverip[1]-0x30)*1000)+((serverip[2]-0x30)*100)+((serverip[3]-0x30)*10)+((serverip[4]-0x30));
	IpPort=((serverip[0])*10000)+((serverip[1])*1000)+((serverip[2])*100)+((serverip[3])*10)+((serverip[4]));
	
 IpPort = EE_Write_val(ADR_IpPort, IpPort, 4); Delay_ms(10);
 
	
	
	
	
	 /* 
   	Settimebuf[6] =tbuf[0]*16+tbuf[1]; //Ҵ 
    Settimebuf[4] =tbuf[2]*16+tbuf[3]; 0x12; //�� 
 	  Settimebuf[3] =tbuf[4]*16+tbuf[5]; 0x01; //�� 
    Settimebuf[2] =Gettimebuf[2]; //? 
    Settimebuf[1] =Gettimebuf[1]; //�� 
    Settimebuf[0] =Gettimebuf[0];//�� 
		Set1381(Settimebuf);//setting current data & time  
	*/


	
} /* of set_date */



void Phone_Sms_Processing(void)
   {
		 int i;
		 int temp[7];
		 int tel_number[11];
	
 /*
		 if(keypush_8510())
	{
		//ch=(keypush_8510());

		switch(KeyCode)
		{
		 	
			case  UP:
				strcpy(szMsg, "AT$LGTCTRM?"); // SMS �޼��� ����
		 cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
				break;
			
			case  DOWN:
				
			
			strcpy(szMsg, "AT$LGTDELRM=*"); // SMS �޼��� ��ü����� 
		 cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
				break;
		
     case  ENTER:
		     break;
		 
		 case  RIGHT: // ���ⷮ ��� "0" ���� �ʱ�ȭ 
				break;
		
			break;
		} // of switch 
	}
	 
	 */
	 
	 //�ڵ��� ���÷κ���  "START"��� ���ڸ޼����� �޾����� 
	 if(Usart3_sms_received_flag==1) // �ܺ���ȭ�� ���� sms �� ���ŵǸ� //ó���� #���� �����ϴ� ���ڰ� ����
	{
			if(RxBuffer2_sms[1]=='L'&& RxBuffer2_sms[2]=='G'&&RxBuffer2_sms[3]=='T'&&RxBuffer2_sms[4]=='R'&&RxBuffer2_sms[5]=='M'&&
				
			RxBuffer2_sms[47]=='5'&&RxBuffer2_sms[48]=='3'&&RxBuffer2_sms[51]=='5'&&RxBuffer2_sms[52]=='4'
			)//���ڸ޼����� ó���� ���������� �޾�����
			{
			
				
				
				//cdma reset ����
			//	cdma_send_cmd("AT$LGTRESET", 11);	//2014.10.27
				
				
				
				
		/*********  ���ں�����ȣ�� ���乮�� ������**********************************/
				USART3_putchar('A');
				USART3_putchar('T');
				USART3_putchar('$');
				USART3_putchar('L');
				USART3_putchar('G');
				USART3_putchar('T');
				USART3_putchar('S');
				USART3_putchar('N');
				USART3_putchar('D');
				USART3_putchar('S');
				USART3_putchar('M');
			  USART3_putchar('=');
			
      // ���Ź��� ��� ��ȭ��ȣ			
				USART3_putchar(RxBuffer2_sms[7]);
				USART3_putchar(RxBuffer2_sms[8]);
				USART3_putchar(RxBuffer2_sms[9]);
				USART3_putchar(RxBuffer2_sms[10]);
				USART3_putchar(RxBuffer2_sms[11]);
				USART3_putchar(RxBuffer2_sms[12]);
				USART3_putchar(RxBuffer2_sms[13]);
				USART3_putchar(RxBuffer2_sms[14]);
				USART3_putchar(RxBuffer2_sms[15]);
				USART3_putchar(RxBuffer2_sms[16]);
				USART3_putchar(RxBuffer2_sms[17]);
				
				
				USART3_putchar(',');
				USART3_putchar('0'); // short message
				USART3_putchar(',');
				USART3_putchar('0'); // 0: �ƽ�Ű�ڵ�ǥ  1: utf-8
				USART3_putchar(',');
				
				/******** �۽Ÿ޼���*****************/
				USART3_putchar('"');
				
				sprintf(sT0,"House Number=%2d ,               ",gnlMyAddress);
				USART3_print(sT0);
				sprintf(sT0,"GPI-8530 ID=M%u  Remote Control Start!",gnlSerialNo);
				USART3_print(sT0);
				
				
				
				USART3_putchar('"');
				/******** �۽Ÿ޼���*****************/
			  USART3_putchar(0x0d);
				USART3_putchar(0x0a);
		/**************���ں�����ȣ�� ���乮�� ������*****************************/
		
		
				 // strcpy(szMsg, "AT$LGTACK"); // SMS ���������� �߹޾Ҵٰ�  ��⿡ ������ �Ѵ�. // �׷��� ������ �޼����� �����ʴ���.
			  //	cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
			
				 beep(100);
   			

//Delay_ms(500);
				 //beep(100);
				 
				
				
				
			  Usart3_sms_received_flag=0;
			  RxCounter2_sms=0;
					
				//GLCD_string(0,2, "  ó������");	
			 sprintf(sT0, "TEL=%c%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[7],RxBuffer2_sms[8],RxBuffer2_sms[9],RxBuffer2_sms[10],RxBuffer2_sms[11],RxBuffer2_sms[12],RxBuffer2_sms[13],RxBuffer2_sms[14],RxBuffer2_sms[15],RxBuffer2_sms[16],RxBuffer2_sms[17]);
       //GLCD_string(0,2, sT0);	 
			 USART1_puts(sT0);
   
			sprintf(sT0, "%c%c%c%c%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[19],RxBuffer2_sms[20],RxBuffer2_sms[21],RxBuffer2_sms[22],RxBuffer2_sms[23],RxBuffer2_sms[24],RxBuffer2_sms[25],
                                                                                    RxBuffer2_sms[26],RxBuffer2_sms[27],RxBuffer2_sms[28],RxBuffer2_sms[29],RxBuffer2_sms[30],RxBuffer2_sms[31],RxBuffer2_sms[32]);
			 //GLCD_string(0,4, sT0); 
			   USART1_puts(sT0);
				  
			sprintf(sT0, "%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[47],RxBuffer2_sms[48],RxBuffer2_sms[51],RxBuffer2_sms[52],RxBuffer2_sms[55],RxBuffer2_sms[56],RxBuffer2_sms[59],
                                                                                    RxBuffer2_sms[60],RxBuffer2_sms[63],RxBuffer2_sms[64]);
			 //GLCD_string(0,6, sT0); 
			  USART1_puts(sT0);
					
				
				  strcpy(szMsg, "AT$LGTACK"); // SMS ���������� �߹޾Ҵٰ�  ��⿡ ������ �Ѵ�. // �׷��� ������ �޼����� �����ʴ���.
			  	cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
					
					//	strcpy(szMsg, "AT$LGTDELRM=*"); // SMS �޼��� ��ü����� 
		      //  cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
			    //  Delay_ms(2000);
					
       /*				
				//�ڵ���½�ȣ  on 
					     Gpi8510_Relay_On(SILO_TWO);
									  beep(1500);
									  Gpi8510_Relay_Off(SILO_TWO);
				*/	
					
          for(i=0;i<100;i++)
	        RxBuffer2_sms[i]=0xff; //�ʱ�ȯ

        // goto END_FUNCTION;
				
				
				 strcpy(szMsg, "AT$LGTDELSM=*"); // SMS �۽� �޼��� ��ü����� 
	   cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
		

				}
			
				#ifdef dpfdpfdpf
     if(RxBuffer2_sms[1]=='L'&& RxBuffer2_sms[2]=='G'&&RxBuffer2_sms[3]=='T'&&RxBuffer2_sms[4]=='R'&&RxBuffer2_sms[5]=='S')//���ڸ޼����� ó���� 2,3 ��° �޾�����  ���������� �޾�����
			{
				//$LGTRSM:01034431529,20201123122847,4098,20,2,"00530054004100520054"
   
				
				
				/*********  ���ں�����ȣ�� ���乮�� ������**********************************/
				USART3_putchar('A');
				USART3_putchar('T');
				USART3_putchar('$');
				USART3_putchar('L');
				USART3_putchar('G');
				USART3_putchar('T');
				USART3_putchar('S');
				USART3_putchar('N');
				USART3_putchar('D');
				USART3_putchar('S');
				USART3_putchar('M');
			  USART3_putchar('=');
			
      // ���Ź��� ��� ��ȭ��ȣ			
				USART3_putchar(RxBuffer2_sms[8]);
				USART3_putchar(RxBuffer2_sms[9]);
				USART3_putchar(RxBuffer2_sms[10]);
				USART3_putchar(RxBuffer2_sms[11]);
				USART3_putchar(RxBuffer2_sms[12]);
				USART3_putchar(RxBuffer2_sms[13]);
				USART3_putchar(RxBuffer2_sms[14]);
				USART3_putchar(RxBuffer2_sms[15]);
				USART3_putchar(RxBuffer2_sms[16]);
				USART3_putchar(RxBuffer2_sms[17]);
				USART3_putchar(RxBuffer2_sms[18]);
				
				
				USART3_putchar(',');
				USART3_putchar('0'); // short message
				USART3_putchar(',');
				USART3_putchar('0'); // 0: �ƽ�Ű�ڵ�ǥ
				USART3_putchar(',');
				
				/******** �۽Ÿ޼���*****************/
				USART3_putchar('"');
				sprintf(sT0,"ID=N%u Start!",gnlSerialNo);
				USART3_print(sT0);
				USART3_putchar('"');
				/******** �۽Ÿ޼���*****************/
			  USART3_putchar(0x0d);
				USART3_putchar(0x0a);
		/**************���ں�����ȣ�� ���乮�� ������*****************************/
			
				 beep(100);
				 //Delay_ms(500);
				 //beep(100);
				 
				 strcpy(szMsg, "AT$LGTACK"); // SMS ���������� �߹޾Ҵٰ�  ��⿡ ������ �Ѵ�. // �׷��� ������ �޼����� �����ʴ���.
			  	cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
				
				
			  Usart3_sms_received_flag=0;
			  RxCounter2_sms=0;
					
				GLCD_string(0,2, "  �ι�����");	
			 sprintf(sT0, "TEL=%c%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[8],RxBuffer2_sms[9],RxBuffer2_sms[10],RxBuffer2_sms[11],RxBuffer2_sms[12],RxBuffer2_sms[13],RxBuffer2_sms[14],RxBuffer2_sms[15],RxBuffer2_sms[16],RxBuffer2_sms[17],RxBuffer2_sms[18]);
       //GLCD_string(0,2, sT0);	 
			 USART1_puts(sT0);
   
			sprintf(sT0, "%c%c%c%c%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[20],RxBuffer2_sms[21],RxBuffer2_sms[22],RxBuffer2_sms[23],RxBuffer2_sms[24],RxBuffer2_sms[25],RxBuffer2_sms[26],
                                                                                    RxBuffer2_sms[27],RxBuffer2_sms[28],RxBuffer2_sms[29],RxBuffer2_sms[30],RxBuffer2_sms[31],RxBuffer2_sms[32],RxBuffer2_sms[33]);
			 //GLCD_string(0,4, sT0); 
			   USART1_puts(sT0);
				  
			sprintf(sT0, "%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[48],RxBuffer2_sms[49],RxBuffer2_sms[52],RxBuffer2_sms[53],RxBuffer2_sms[56],RxBuffer2_sms[57],RxBuffer2_sms[60],
                                                                                    RxBuffer2_sms[61],RxBuffer2_sms[64],RxBuffer2_sms[65]);
			 //GLCD_string(0,6, sT0); 
			  USART1_puts(sT0);
					
				
				  strcpy(szMsg, "AT$LGTACK"); // SMS ���������� �߹޾Ҵٰ�  ��⿡ ������ �Ѵ�. // �׷��� ������ �޼����� �����ʴ���.
			  	cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
				//strcpy(szMsg, "AT$LGTDELRM=*"); // SMS �޼��� ��ü����� 
		     //cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
				 //Delay_ms(2000);
			 
          for(i=0;i<100;i++)
	        RxBuffer2_sms[i]=0xff; //�ʱ�ȯ

				
				
       /*			
				for(i=0;i<RxCounter2_sms;i++)
			    {
						USART1_putchar(RxBuffer2_sms[i]);
					}	
			   USART1_putchar(0x0d);
				 USART1_putchar(0x0a);
					
			  Usart3_sms_received_flag=0;
			  RxCounter2_sms=0;
		    	GLCD_string(0,2, "  �ι�����");	
			 sprintf(sT0, "TEL=%c%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[8],RxBuffer2_sms[9],RxBuffer2_sms[10],RxBuffer2_sms[11],RxBuffer2_sms[12],RxBuffer2_sms[13],RxBuffer2_sms[14],RxBuffer2_sms[15],RxBuffer2_sms[16],RxBuffer2_sms[17],RxBuffer2_sms[18]);
       //GLCD_string(0,2, sT0);	 
					USART1_puts(sT0);
   
			sprintf(sT0, "%c%c%c%c%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[20],RxBuffer2_sms[21],RxBuffer2_sms[22],RxBuffer2_sms[23],RxBuffer2_sms[24],RxBuffer2_sms[25],RxBuffer2_sms[26],
                                                                                    RxBuffer2_sms[27],RxBuffer2_sms[28],RxBuffer2_sms[29],RxBuffer2_sms[30],RxBuffer2_sms[31],RxBuffer2_sms[32],RxBuffer2_sms[33]);
			 //GLCD_string(0,4, sT0); 
					USART1_puts(sT0);
				  
			sprintf(sT0, "%c%c%c%c%c%c%c%c%c%c",RxBuffer2_sms[48],RxBuffer2_sms[49],RxBuffer2_sms[52],RxBuffer2_sms[53],RxBuffer2_sms[56],RxBuffer2_sms[57],RxBuffer2_sms[60],
                                                                                    RxBuffer2_sms[61],RxBuffer2_sms[64],RxBuffer2_sms[65]);
			 //GLCD_string(0,6, sT0); 
					USART1_puts(sT0);
			



					
      	  strcpy(szMsg, "AT$LGTACK"); // SMS ���������� �߹޾Ҵٰ�  ��⿡ ������ �Ѵ�. // �׷��� ������ �޼����� �����ʴ���.
			  	cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
			 
          for(i=0;i<100;i++)
	        RxBuffer2_sms[i]=0xff; //�ʱ�ȯ
         */
				
				
				}
			
				#endif
			/*	
			 else	
			 {	
				  for(i=0;i<RxCounter2_sms;i++)
			    {
						USART1_putchar(RxBuffer2_sms[i]);
						
					}	
			   USART1_putchar(0x0d);
				 USART1_putchar(0x0a);
				 
					 Usart3_sms_received_flag=0;
			    RxCounter2_sms=0;
					for(i=0;i<100;i++)
	        RxBuffer2_sms[i]=0xff; //�ʱ�ȯ
			 }
			*/	
				END_FUNCTION:			
				
					
				  for(i=0;i<RxCounter2_sms;i++)
			    {
						USART1_putchar(RxBuffer2_sms[i]);
						
					}	
			   USART1_putchar(0x0d);
				 USART1_putchar(0x0a);
				 
					 Usart3_sms_received_flag=0;
			    RxCounter2_sms=0;
					for(i=0;i<100;i++)
	        RxBuffer2_sms[i]=0xff; //�ʱ�ȯ
					
					
		// strcpy(szMsg, "AT$LGTDELSM=*"); // SMS �۽� �޼��� ��ü����� 
	  // cdma_send_cmd_with_buffer_clear(szMsg, strlen(szMsg));
					
					
				
		}	// of if(Usart3_sms_received_flag==1) // �ܺ���ȭ�� ���� sms �� ���ŵǸ� //ó���� #���� �����ϴ� ���ڰ� ����

	  //for(i=0;i<100;i++)
	 //RxBuffer2_sms[i]=0xff; //�ʱ�ȯ
   } // of funciton







//Silo1_Error_led_On();


//void  Silo_2_Led_Operation();
//void  Error_1_Led_Operation();
//void  Error_2_Led_Operation();


/************** function of gpi-8510 ***********************/








/* end of file */
